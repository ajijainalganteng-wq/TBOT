RIPZZ STORE UNIFIED — XRAY + RESTORE + USER TRIAL FIX

Perbaikan utama:
1. VMess/VLESS/Trojan kembali memakai marker konfigurasi LUNAVPN:
   #vmess / #vmessgrpc
   #vless / #vlessgrpc
   #trojanws / #trojangrpc
   sehingga config dengan komentar/marker tidak dipaksa dibaca jq.
2. Setiap create/delete/renew/trial melakukan backup konfigurasi dan xray run -test.
   Jika test/restart gagal, konfigurasi dikembalikan.
3. Restore DB dikembalikan ke implementasi sql.js yang benar-benar membaca backup
   SQLite sebagai database terpisah di memory, lalu menyalin data ke database aktif.
4. Backup DB melakukan flush database sql.js sebelum file disalin.
5. Metadata transaksi duration_days, price_per_day, refunded_at, refund_amount dipertahankan.
6. User biasa mendapatkan menu CREATE TRIAL. Menu admin tidak diubah.
7. Refund hapus akun menghitung sisa hari berdasarkan expired_at, dikalikan harga/hari
   yang sedang diset admin, dan dibatasi maksimum nominal transaksi asli.

Catatan pemasangan:
- Backup folder bot + yanbot.db sebelum replace.
- Setelah install/sync scripts, restart service bot.
- Pastikan VPS target memiliki xray dan marker config LUNAVPN yang sama.
- Untuk trial auto-expire, jika command `at` tersedia maka job penghapusan dijadwalkan.
