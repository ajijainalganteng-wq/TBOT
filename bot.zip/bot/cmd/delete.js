// cmd/delete.js — delete VPN account + automatic remaining-day refund
'use strict';
const db = require('../data/db');
const path = require('path');
const fs = require('fs');
const { executeScriptRemote } = require('../services/ssh-exec');
const { friendlyError } = require('../services/error-messages');
const PRICES_PATH = path.join(__dirname, '../data/prices.js');
function prices(){ try { const p=require.resolve(PRICES_PATH); delete require.cache[p]; return require(p); } catch { return {members:{},reseller:{}}; } }
function rolePrice(role,type){ const p=prices(); const key={SSH:'ssh',VMESS:'vmess',VLESS:'vless',TROJAN:'trojan',ZIVPN:'udpzivpn'}[type]||'ssh'; const r=role==='reseller'||role==='admin'?'reseller':'members'; return Number(p[r]?.[key]?.perDay||0); }
function rp(n){ return 'Rp '+Number(n||0).toLocaleString('id-ID'); }
const MAP={SSH:'hapusSSH',VMESS:'hapusVME',VLESS:'hapusVLE',TROJAN:'hapusTRO',ZIVPN:'hapusZIVPN'};
const LABEL={SSH:'⚪ SSH / OpenVPN',VMESS:'🔵 xRay VMess',VLESS:'🟡 xRay VLess',TROJAN:'🟠 xRay Trojan',ZIVPN:'🟢 UDP ZivPN'};
function daysLeft(exp){ if(!exp) return 0; const raw=String(exp).trim(); const normalized=/[zZ]|[+-]\d{2}:?\d{2}$/.test(raw)?raw:raw.replace(' ','T'); const t=Date.parse(normalized); return Number.isFinite(t)?Math.max(0,Math.ceil((t-Date.now())/86400000)):0; }
function showAccountList(bot,chatId,msgId,userStates){
 bot.editMessageText('⏳ <i>Memuat daftar akun...</i>',{chat_id:chatId,message_id:msgId,parse_mode:'HTML'}).catch(()=>{});
 db.all("SELECT id,order_id,product_type,username,expired_at,server_ip,amount,duration_days,price_per_day,status FROM transactions WHERE chat_id=? AND status='completed' AND product_type IN ('SSH','VMESS','VLESS','TROJAN','ZIVPN') AND (refunded_at IS NULL OR refunded_at='') ORDER BY expired_at DESC",[chatId],(err,rows)=>{
  if(err||!rows?.length) return bot.editMessageText('❌ Tidak ada akun VPN yang dapat dihapus.',{chat_id:chatId,message_id:msgId,reply_markup:{inline_keyboard:[[{text:'🔃 Kembali',callback_data:'menu_back'}]]}}).catch(()=>{});
  const active=rows.filter(r=>daysLeft(r.expired_at)>0); if(!active.length) return bot.editMessageText('❌ Tidak ada akun VPN yang masih aktif.',{chat_id:chatId,message_id:msgId,reply_markup:{inline_keyboard:[[{text:'🔃 Kembali',callback_data:'menu_back'}]]}}).catch(()=>{});
  let text='┌─────────────────────┐\n│  🗑 HAPUS AKUN VPN\n└─────────────────────┘\n\n';
  active.forEach((r,i)=>text+=`${i+1}. ${LABEL[r.product_type]||r.product_type}\n   👤 ${r.username||'-'}  ⏳ ${daysLeft(r.expired_at)} hari\n   📅 Exp: ${(r.expired_at||'-').slice(0,10)}\n\n`);
  text+=`Pilih nomor akun yang ingin dihapus:`;
  userStates.set(chatId,{state:'delete_pick',accounts:active,msgId});
  bot.editMessageText(text,{chat_id:chatId,message_id:msgId,reply_markup:{inline_keyboard:[[...active.slice(0,8).map((r,i)=>({text:String(i+1),callback_data:`delete_pick_${i}`}))],[{text:'❌ Batal',callback_data:'menu_back'}]]}}).catch(()=>{});
 });
}
async function execute(bot,chatId,st){
 const a=st.account; const role=st.role||'members'; const left=daysLeft(a.expired_at); const price=rolePrice(role,a.product_type); const original=Number(a.amount||0); const refund=Math.min(original, Math.max(0,left*price));
 const script=MAP[a.product_type]; if(!script) return bot.sendMessage(chatId,'❌ Tipe akun tidak didukung.');
 await bot.editMessageText('⏳ <i>Menghapus akun dan menghitung pengembalian saldo...</i>',{chat_id:chatId,message_id:st.msgId,parse_mode:'HTML'}).catch(()=>{});
 executeScriptRemote(a.server_ip,script,[a.username],(err,raw)=>{
  if(err){ const e=friendlyError(err.message)||err.message; return bot.editMessageText(`❌ <b>Gagal menghapus akun</b>\n\n${e}\n\nSaldo tidak dikembalikan.`,{chat_id:chatId,message_id:st.msgId,parse_mode:'HTML'}).catch(()=>{}); }
  if(!/STATUS:DELETED/.test(String(raw))){ return bot.editMessageText(`❌ <b>Akun belum berhasil dihapus.</b>\n\nSaldo tidak dikembalikan.\n\n<pre>${String(raw).slice(-1500)}</pre>`,{chat_id:chatId,message_id:st.msgId,parse_mode:'HTML'}).catch(()=>{}); }
  db.run('UPDATE users SET saldo=saldo+? WHERE chat_id=?',[refund,chatId]);
  db.run("UPDATE transactions SET status='refunded', refunded_at=datetime('now','localtime'), refund_amount=? WHERE id=?",[refund,a.id]);
  bot.editMessageText(`✅ <b>AKUN BERHASIL DIHAPUS</b>\n\n📦 Produk : ${LABEL[a.product_type]||a.product_type}\n👤 Username : <code>${a.username}</code>\n⏳ Sisa hari : <b>${left} hari</b>\n💰 Harga admin : <b>${rp(price)}/hari</b>\n↩️ Saldo kembali : <b>${rp(refund)}</b>\n\nPengembalian saldo otomatis mengikuti harga yang sedang diset admin.`,{chat_id:chatId,message_id:st.msgId,parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔃 Menu Utama',callback_data:'menu_back'}]]}}).catch(()=>{});
 });
}
function start(bot,chatId,msgId,userStates){ db.get('SELECT role FROM users WHERE chat_id=?',[chatId],(e,u)=>{ if(e||!u) return; showAccountList(bot,chatId,msgId,userStates); }); }
function handlePick(bot,chatId,index,userStates){ const st=userStates.get(chatId); if(!st||st.state!=='delete_pick') return; const a=st.accounts[Number(index)]; if(!a) return; db.get('SELECT role FROM users WHERE chat_id=?',[chatId],(e,u)=>{ st.account=a; st.role=u?.role||'members'; st.state='delete_confirm'; st.msgId=st.msgId; userStates.set(chatId,st); const left=daysLeft(a.expired_at), price=rolePrice(st.role,a.product_type), refund=Math.min(Number(a.amount||0),Math.max(0,left*price)); bot.editMessageText(`┌─────────────────────┐\n│  ⚠️ KONFIRMASI HAPUS\n└─────────────────────┘\n\n${LABEL[a.product_type]||a.product_type}\n👤 <code>${a.username}</code>\n⏳ Sisa : <b>${left} hari</b>\n💰 Harga admin : <b>${rp(price)}/hari</b>\n↩️ Estimasi kembali : <b>${rp(refund)}</b>\n\nLanjutkan?`,{chat_id:chatId,message_id:st.msgId,parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✅ Hapus & Kembalikan Saldo',callback_data:'confirm_delete'},{text:'❌ Batal',callback_data:'menu_back'}]]}}).catch(()=>{}); }); }
module.exports={showAccountList,start,handlePick,execute};
