RIPZZ STORE UNIFIED VPN + PPOB
================================

FITUR PERBAIKAN:
1. Installer sekarang meminta:
   - Telegram Bot Token
   - Owner ID
   - Pakasir Slug + API Key (PAYMENT VPN)
   - Channel notif VPN
   - Digiflazz Username + API Key
   - Channel notif PPOB
   - AustinPay API Key + Secret (PAYMENT PPOB)
   - Channel wajib join (opsional)
2. /start langsung membuka MENU UTAMA VPN.
3. PPOB -> tombol "Menu Utama VPN" selalu kembali ke menu VPN.
4. Admin dipisah:
   /admin -> pilih ADMIN VPN atau ADMIN PPOB.
5. Payment dipisah:
   VPN = Pakasir
   PPOB = AustinPay
6. Notifikasi transaksi akun VPN dikirim ke channel.
7. Notifikasi topup VPN dikirim ke channel.
8. Notifikasi topup PPOB diperbarui dan tetap memakai AustinPay.
9. Tetap satu polling Telegram; PPOB tidak membuat bot polling kedua.

INSTALL:
   chmod +x install.sh
   ./install.sh

LOG:
   journalctl -u ripzz-store-bot -f
