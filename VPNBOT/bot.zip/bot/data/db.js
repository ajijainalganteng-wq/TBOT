'use strict';

const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, 'yanbot.db');

let SQL;
let betterDb;
let attachedBackupDb = null;
let saveTimer = null;
let transactionDepth = 0;

function getDb() {
  if (!betterDb) throw new Error('Database belum siap');
  return betterDb;
}

function ensureDir() {
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
}

/**
 * Save the current in-memory sql.js database atomically.
 * This is important because sql.js does not use the normal SQLite WAL
 * file on disk. The real database lives in memory until export() is called.
 */
function saveDb() {
  try {
    if (!betterDb || transactionDepth > 0) return false;
    ensureDir();

    const data = betterDb.export();
    const buffer = Buffer.from(data);
    const tmpPath = `${dbPath}.tmp-${process.pid}`;

    fs.writeFileSync(tmpPath, buffer);
    fs.renameSync(tmpPath, dbPath);
    return true;
  } catch (e) {
    console.error('[DB] ❌ Gagal save:', e.message);
    return false;
  }
}

function debounceSave() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    saveTimer = null;
    saveDb();
  }, 500);
}

function closeAttachedBackup() {
  if (attachedBackupDb) {
    try { attachedBackupDb.close(); } catch (_) {}
    attachedBackupDb = null;
  }
}

function openBackup(filePath) {
  if (!SQL) throw new Error('SQL engine belum siap');
  if (!filePath || !fs.existsSync(filePath)) {
    throw new Error('File backup tidak ditemukan');
  }

  const stat = fs.statSync(filePath);
  if (!stat.isFile() || stat.size < 100) {
    throw new Error('File backup kosong atau tidak valid');
  }

  const buffer = fs.readFileSync(filePath);
  const backup = new SQL.Database(buffer);

  // Validate that this is one of our bot databases.
  const tables = backup.exec(
    "SELECT name FROM sqlite_master WHERE type='table' AND name IN ('users','transactions')"
  );
  const found = tables?.[0]?.values?.map(row => row[0]) || [];

  if (!found.includes('users') || !found.includes('transactions')) {
    backup.close();
    throw new Error('Backup VPN wajib memiliki tabel users dan transactions');
  }
  const check = backup.exec('PRAGMA quick_check');
  const integrity = check?.[0]?.values?.[0]?.[0];
  if (integrity && String(integrity).toLowerCase() !== 'ok') {
    backup.close();
    throw new Error('Database backup rusak: ' + integrity);
  }

  return backup;
}

function attachBackup(filePath) {
  closeAttachedBackup();
  attachedBackupDb = openBackup(filePath);
}

function normalizeBackupSql(sql) {
  return String(sql || '').replace(/\bbk\./gi, '');
}

function isBackupQuery(sql) {
  return /\b(?:FROM|JOIN|UPDATE|INTO)\s+bk\./i.test(String(sql || ''));
}

function queryDb(targetDb, sql, params = []) {
  const stmt = targetDb.prepare(sql);
  try {
    stmt.bind(params);
    const rows = [];
    while (stmt.step()) {
      const cols = stmt.getColumnNames();
      const vals = stmt.get();
      const row = {};
      cols.forEach((c, i) => { row[c] = vals[i]; });
      rows.push(row);
    }
    return rows;
  } finally {
    stmt.free();
  }
}

function queryOne(targetDb, sql, params = []) {
  const stmt = targetDb.prepare(sql);
  try {
    stmt.bind(params);
    if (!stmt.step()) return null;
    const cols = stmt.getColumnNames();
    const vals = stmt.get();
    const row = {};
    cols.forEach((c, i) => { row[c] = vals[i]; });
    return row;
  } finally {
    stmt.free();
  }
}

function handleTransactionSql(sql) {
  const normalized = String(sql || '').trim().replace(/;\s*$/, '').toUpperCase();
  if (/^BEGIN(?:\s+TRANSACTION)?(?:\s+.*)?$/.test(normalized)) {
    transactionDepth++;
    return;
  }
  if (/^COMMIT$/.test(normalized)) {
    transactionDepth = Math.max(0, transactionDepth - 1);
    saveDb();
    return;
  }
  if (/^ROLLBACK$/.test(normalized)) {
    transactionDepth = 0;
    saveDb();
  }
}

async function initDb() {
  SQL = await initSqlJs();

  try {
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      betterDb = new SQL.Database(fileBuffer);
      console.log('[DB] ✅ Database loaded:', dbPath);
    } else {
      betterDb = new SQL.Database();
      console.log('[DB] ✅ Database created:', dbPath);
    }
  } catch (err) {
    console.error('[DB] ⚠️ DB file corrupt, creating new:', err.message);
    betterDb = new SQL.Database();
  }

  // sql.js is in-memory; these PRAGMA values are harmless where unsupported.
  try { betterDb.run('PRAGMA journal_mode = WAL'); } catch (_) {}
  try { betterDb.run('PRAGMA synchronous = NORMAL'); } catch (_) {}
  try { betterDb.run('PRAGMA cache_size = 4000'); } catch (_) {}
  try { betterDb.run('PRAGMA temp_store = MEMORY'); } catch (_) {}
  try { betterDb.run('PRAGMA busy_timeout = 5000'); } catch (_) {}

  betterDb.run(`CREATE TABLE IF NOT EXISTS users (
    chat_id INTEGER PRIMARY KEY,
    saldo INTEGER DEFAULT 0,
    role TEXT DEFAULT 'members',
    created_at TEXT
  )`);

  betterDb.run(`CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    amount INTEGER,
    status TEXT DEFAULT 'pending',
    created_at TEXT,
    product_type TEXT DEFAULT ''
  )`);

  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN username TEXT DEFAULT ''`); } catch (_) {}
  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN expired_at TEXT DEFAULT ''`); } catch (_) {}
  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN server_ip TEXT DEFAULT ''`); } catch (_) {}
  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN duration_days INTEGER DEFAULT 0`); } catch (_) {}
  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN price_per_day INTEGER DEFAULT 0`); } catch (_) {}
  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN refunded_at TEXT DEFAULT ''`); } catch (_) {}
  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN refund_amount INTEGER DEFAULT 0`); } catch (_) {}

  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_chat_id ON transactions(chat_id)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_status ON transactions(status)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_created_at ON transactions(created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_status_created ON transactions(status, created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_chatid_status ON transactions(chat_id, status, created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_users_role ON users(role)`);

  betterDb.run(`CREATE TABLE IF NOT EXISTS notif_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    days_before INTEGER,
    sent_at TEXT,
    UNIQUE(order_id, days_before)
  )`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_notif_order ON notif_log(order_id, days_before)`);

  saveDb();
  setInterval(saveDb, 30000);
}

const db = {
  run(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    const rawSql = String(sql || '').trim();
    const normalized = rawSql.toUpperCase();

    try {
      // sql.js does not support filesystem ATTACH/DETACH the same way
      // native sqlite3 does. Emulate the two operations in memory so the
      // existing admin restore code can continue to work unchanged.
      if (/^ATTACH\s+DATABASE\s+\?\s+AS\s+BK$/i.test(rawSql)) {
        attachBackup(params[0]);
        if (callback) callback.call({ lastID: 0, changes: 0 }, null);
        return;
      }

      if (/^DETACH\s+DATABASE\s+BK$/i.test(rawSql)) {
        closeAttachedBackup();
        if (callback) callback.call({ lastID: 0, changes: 0 }, null);
        return;
      }

      getDb().run(rawSql, params);
      handleTransactionSql(rawSql);

      const info = { lastID: 0, changes: getDb().getRowsModified() };

      // Persist immediately for normal writes so a Telegram backup always
      // contains the latest users/saldo/transactions. During an explicit
      // transaction we wait for COMMIT.
      if (transactionDepth === 0 && !/^PRAGMA\b/i.test(rawSql)) {
        saveDb();
      } else if (transactionDepth === 0) {
        debounceSave();
      }

      if (callback) callback.call(info, null);
    } catch (err) {
      if (callback) callback.call({}, err);
    }
  },

  get(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    try {
      let target = getDb();
      let query = String(sql || '');
      if (isBackupQuery(query)) {
        if (!attachedBackupDb) throw new Error('Backup database belum di-attach');
        target = attachedBackupDb;
        query = normalizeBackupSql(query);
      }

      const row = queryOne(target, query, params);
      if (callback) callback(null, row);
    } catch (err) {
      if (callback) callback(err, null);
    }
  },

  all(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    try {
      let target = getDb();
      let query = String(sql || '');
      if (isBackupQuery(query)) {
        if (!attachedBackupDb) throw new Error('Backup database belum di-attach');
        target = attachedBackupDb;
        query = normalizeBackupSql(query);
      }

      const rows = queryDb(target, query, params);
      if (callback) callback(null, rows);
    } catch (err) {
      if (callback) callback(err, []);
    }
  },

  exec(sql, callback) {
    try {
      const rawSql = String(sql || '');
      getDb().exec(rawSql);
      handleTransactionSql(rawSql);
      if (transactionDepth === 0) saveDb();
      if (callback) callback(null);
    } catch (err) {
      if (callback) callback(err);
    }
  },

  serialize(fn) {
    if (fn) fn();
  },

  // Explicit flush helper for backup code.
  flush() {
    return saveDb();
  },

  // Write an immutable SQLite .db snapshot from the in-memory VPN database.
  // Never copy the live file while sql.js still has newer in-memory changes.
  backupToFile(filePath) {
    if (!betterDb) throw new Error('Database VPN belum siap');
    if (!saveDb()) throw new Error('Database VPN gagal disimpan sebelum backup');
    const target = path.resolve(filePath);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const tmp = `${target}.tmp-${process.pid}`;
    try {
      fs.writeFileSync(tmp, Buffer.from(betterDb.export()));
      fs.renameSync(tmp, target);
      const check = openBackup(target);
      check.close();
      return target;
    } catch (err) {
      try { fs.unlinkSync(tmp); } catch (_) {}
      throw err;
    }
  },

  // Restore the complete SQLite database, including every table and column.
  restoreFromBackup(filePath) {
    // Persist the current live database first so rollback always has a valid baseline.
    if (!saveDb()) throw new Error('Database VPN aktif gagal disimpan sebelum restore');
    const restored = openBackup(filePath);
    const previous = betterDb;
    const previousFile = fs.existsSync(dbPath) ? fs.readFileSync(dbPath) : null;
    let committed = false;
    try {
      const tableRows = restored.exec("SELECT name FROM sqlite_master WHERE type='table'");
      const tableNames = tableRows?.[0]?.values?.map(row => row[0]) || [];
      if (!tableNames.includes('users') || !tableNames.includes('transactions')) {
        throw new Error('Backup database tidak memiliki tabel users/transactions lengkap');
      }
      restored.run(`CREATE TABLE IF NOT EXISTS users (chat_id INTEGER PRIMARY KEY, saldo INTEGER DEFAULT 0, role TEXT DEFAULT 'members', created_at TEXT)`);
      restored.run(`CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER, order_id TEXT, amount INTEGER, status TEXT DEFAULT 'pending', created_at TEXT, product_type TEXT DEFAULT '')`);
      for (const [table, column] of [
        ['transactions', "username TEXT DEFAULT ''"], ['transactions', "expired_at TEXT DEFAULT ''"],
        ['transactions', "server_ip TEXT DEFAULT ''"], ['transactions', 'duration_days INTEGER DEFAULT 0'],
        ['transactions', 'price_per_day INTEGER DEFAULT 0'], ['transactions', "refunded_at TEXT DEFAULT ''"],
        ['transactions', 'refund_amount INTEGER DEFAULT 0']
      ]) {
        const cols = restored.exec(`PRAGMA table_info(${table})`)[0]?.values || [];
        if (!cols.some(row => row[1] === column.split(/\s+/)[0])) restored.run(`ALTER TABLE ${table} ADD COLUMN ${column}`);
      }
      restored.run('CREATE INDEX IF NOT EXISTS idx_trx_chat_id ON transactions(chat_id)');
      restored.run('CREATE INDEX IF NOT EXISTS idx_trx_status ON transactions(status)');
      restored.run('CREATE INDEX IF NOT EXISTS idx_users_role ON users(role)');
      const integrity = restored.exec('PRAGMA quick_check')?.[0]?.values?.[0]?.[0];
      if (integrity && String(integrity).toLowerCase() !== 'ok') {
        throw new Error('Database hasil restore tidak lolos pemeriksaan integritas: ' + integrity);
      }
      betterDb = restored;
      transactionDepth = 0;
      if (!saveDb()) throw new Error('Gagal menyimpan database hasil restore ke disk');
      committed = true;
      try { previous?.close(); } catch (_) {}
      return {
        users: queryDb(betterDb, 'SELECT * FROM users').length,
        transactions: queryDb(betterDb, 'SELECT * FROM transactions').length,
        tables: tableNames.length
      };
    } catch (err) {
      betterDb = previous;
      transactionDepth = 0;
      try {
        if (previousFile) {
          const rollbackTmp = `${dbPath}.rollback-${process.pid}`;
          fs.writeFileSync(rollbackTmp, previousFile);
          fs.renameSync(rollbackTmp, dbPath);
        } else saveDb();
      } catch (rollbackErr) {
        console.error('[DB] ❌ Rollback restore gagal:', rollbackErr.message);
      }
      if (!committed) { try { restored.close(); } catch (_) {} }
      throw err;
    }
  },

  // Validate a backup without modifying the live database.
  inspectBackup(filePath) {
    const backup = openBackup(filePath);
    try {
      const users = queryDb(backup, 'SELECT * FROM users');
      let transactions = [];
      try { transactions = queryDb(backup, 'SELECT * FROM transactions'); } catch (_) {}
      return { users: users.length, transactions: transactions.length };
    } finally {
      try { backup.close(); } catch (_) {}
    }
  },

  close(callback) {
    try {
      if (saveTimer) clearTimeout(saveTimer);
      saveTimer = null;
      saveDb();
      closeAttachedBackup();
      getDb().close();
      if (callback) callback(null);
    } catch (err) {
      if (callback) callback(err);
    }
  },

  ready: initDb()
};

module.exports = db;
