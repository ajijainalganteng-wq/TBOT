const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, 'yanbot.db');

let SQL;
let betterDb;
let attachedBackupDb = null;

function getDb() {
  if (!betterDb) throw new Error('Database belum siap');
  return betterDb;
}

function saveDb() {
  try {
    const data = betterDb.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
  } catch (e) {
    console.error('[DB] ❌ Gagal save:', e.message);
  }
}

let saveTimer = null;
function debounceSave() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(saveDb, 500);
}

async function initDb() {
  SQL = await initSqlJs();
  try {
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      betterDb = new SQL.Database(fileBuffer);
      console.log('[DB] ✅ Database loaded:', dbPath);
    } else {
      betterDb = new SQL.Database();
      console.log('[DB] ✅ Database created:', dbPath);
    }
  } catch (err) {
    console.error('[DB] ⚠️ DB file corrupt, creating new:', err.message);
    betterDb = new SQL.Database();
  }

  betterDb.run('PRAGMA journal_mode = WAL');
  betterDb.run('PRAGMA synchronous = NORMAL');
  betterDb.run('PRAGMA cache_size = 4000');
  betterDb.run('PRAGMA temp_store = MEMORY');
  betterDb.run('PRAGMA busy_timeout = 5000');

  betterDb.run(`CREATE TABLE IF NOT EXISTS users (
    chat_id INTEGER PRIMARY KEY,
    saldo INTEGER DEFAULT 0,
    role TEXT DEFAULT 'members',
    created_at TEXT
  )`);

  betterDb.run(`CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    amount INTEGER,
    status TEXT DEFAULT 'pending',
    created_at TEXT,
    product_type TEXT DEFAULT ''
  )`);

  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN username TEXT DEFAULT ''`); } catch {}
  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN expired_at TEXT DEFAULT ''`); } catch {}
  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN server_ip TEXT DEFAULT ''`); } catch {}

  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_chat_id ON transactions(chat_id)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_status ON transactions(status)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_created_at ON transactions(created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_status_created ON transactions(status, created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_chatid_status ON transactions(chat_id, status, created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_users_role ON users(role)`);

  betterDb.run(`CREATE TABLE IF NOT EXISTS notif_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    days_before INTEGER,
    sent_at TEXT,
    UNIQUE(order_id, days_before)
  )`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_notif_order ON notif_log(order_id, days_before)`);

  saveDb();

  setInterval(saveDb, 30000);
}

const db = {
  run(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    try {
      const normalized = String(sql || '').trim().replace(/\s+/g, ' ');

      // sql.js berjalan in-memory dan tidak mendukung ATTACH DATABASE
      // seperti SQLite native. Restore lama memakai ATTACH DATABASE ? AS bk.
      // Tangani sintaks itu di wrapper tanpa mengubah admin.js.
      const attachMatch = normalized.match(/^ATTACH DATABASE \? AS bk$/i);
      if (attachMatch) {
        const backupPath = params[0];
        if (!backupPath || !fs.existsSync(backupPath)) {
          throw new Error('File backup database tidak ditemukan');
        }
        const backupBuffer = fs.readFileSync(backupPath);
        if (!backupBuffer.length) throw new Error('File backup database kosong');
        const backupDb = new SQL.Database(backupBuffer);
        // Validasi minimal agar file bukan database acak/corrupt.
        const tables = backupDb.exec("SELECT name FROM sqlite_master WHERE type='table'");
        const names = (tables[0]?.values || []).map(r => r[0]);
        if (!names.includes('users')) {
          backupDb.close();
          throw new Error('Backup database tidak memiliki tabel users');
        }
        attachedBackupDb = backupDb;
        if (callback) callback.call({ lastID: 0, changes: 0 }, null);
        return;
      }

      if (/^DETACH DATABASE bk$/i.test(normalized)) {
        if (attachedBackupDb) {
          try { attachedBackupDb.close(); } catch (_) {}
          attachedBackupDb = null;
        }
        if (callback) callback.call({ lastID: 0, changes: 0 }, null);
        return;
      }

      getDb().run(sql, params);
      const info = { lastID: 0, changes: getDb().getRowsModified() };
      debounceSave();
      if (callback) callback.call(info, null);
    } catch (err) {
      if (callback) callback.call({}, err);
    }
  },

  get(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    try {
      const normalized = String(sql || '').trim().replace(/\s+/g, ' ');
      if (/\bFROM bk\.users\b/i.test(normalized) || /\bFROM bk\.transactions\b/i.test(normalized)) {
        if (!attachedBackupDb) throw new Error('Backup database belum di-attach');
        const stmt = attachedBackupDb.prepare(sql.replace(/\bbk\./gi, ''));
        stmt.bind(params);
        const rows = [];
        while (stmt.step()) {
          const cols = stmt.getColumnNames();
          const vals = stmt.get();
          const row = {};
          cols.forEach((c, i) => { row[c] = vals[i]; });
          rows.push(row);
        }
        stmt.free();
        if (callback) callback(null, rows);
        return;
      }

      const stmt = getDb().prepare(sql);
      stmt.bind(params);
      let row = null;
      if (stmt.step()) {
        const cols = stmt.getColumnNames();
        const vals = stmt.get();
        row = {};
        cols.forEach((c, i) => { row[c] = vals[i]; });
      }
      stmt.free();
      if (callback) callback(null, row);
    } catch (err) {
      if (callback) callback(err, null);
    }
  },

  all(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    try {
      const normalized = String(sql || '').trim().replace(/\s+/g, ' ');
      if (/\bFROM bk\./i.test(normalized)) {
        if (!attachedBackupDb) throw new Error('Backup database belum di-attach');
        const stmt = attachedBackupDb.prepare(sql.replace(/\bbk\./gi, ''));
        stmt.bind(params);
        let row = null;
        if (stmt.step()) {
          const cols = stmt.getColumnNames();
          const vals = stmt.get();
          row = {};
          cols.forEach((c, i) => { row[c] = vals[i]; });
        }
        stmt.free();
        if (callback) callback(null, row);
        return;
      }

      const stmt = getDb().prepare(sql);
      stmt.bind(params);
      const rows = [];
      while (stmt.step()) {
        const cols = stmt.getColumnNames();
        const vals = stmt.get();
        const row = {};
        cols.forEach((c, i) => { row[c] = vals[i]; });
        rows.push(row);
      }
      stmt.free();
      if (callback) callback(null, rows);
    } catch (err) {
      if (callback) callback(err, []);
    }
  },

  exec(sql, callback) {
    try {
      getDb().exec(sql);
      debounceSave();
      if (callback) callback(null);
    } catch (err) {
      if (callback) callback(err);
    }
  },

  serialize(fn) {
    if (fn) fn();
  },

  close(callback) {
    try {
      if (attachedBackupDb) { try { attachedBackupDb.close(); } catch (_) {} attachedBackupDb = null; }
      saveDb();
      getDb().close();
      if (callback) callback(null);
    } catch (err) {
      if (callback) callback(err);
    }
  },

  // Helper opsional: memuat file backup sebagai database terpisah.
  // Dipakai internal oleh kompatibilitas ATTACH di atas.
  restoreFile(filePath) {
    if (!fs.existsSync(filePath)) throw new Error('File backup database tidak ditemukan');
    const backupBuffer = fs.readFileSync(filePath);
    const backupDb = new SQL.Database(backupBuffer);
    const tables = backupDb.exec("SELECT name FROM sqlite_master WHERE type='table'");
    const names = (tables[0]?.values || []).map(r => r[0]);
    if (!names.includes('users')) { backupDb.close(); throw new Error('Backup database tidak valid'); }
    return backupDb;
  },

  ready: initDb()
};

module.exports = db;
