'use strict';

const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, 'yanbot.db');

let SQL;
let betterDb;
let attachedBackupDb = null;
let saveTimer = null;
let transactionDepth = 0;

function getDb() {
  if (!betterDb) throw new Error('Database belum siap');
  return betterDb;
}

function ensureDir() {
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
}

/**
 * Save the current in-memory sql.js database atomically.
 * This is important because sql.js does not use the normal SQLite WAL
 * file on disk. The real database lives in memory until export() is called.
 */
function saveDb() {
  try {
    if (!betterDb || transactionDepth > 0) return false;
    ensureDir();

    const data = betterDb.export();
    const buffer = Buffer.from(data);
    const tmpPath = `${dbPath}.tmp-${process.pid}`;

    fs.writeFileSync(tmpPath, buffer);
    fs.renameSync(tmpPath, dbPath);
    return true;
  } catch (e) {
    console.error('[DB] ❌ Gagal save:', e.message);
    return false;
  }
}

function debounceSave() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    saveTimer = null;
    saveDb();
  }, 500);
}

function closeAttachedBackup() {
  if (attachedBackupDb) {
    try { attachedBackupDb.close(); } catch (_) {}
    attachedBackupDb = null;
  }
}

function openBackup(filePath) {
  if (!SQL) throw new Error('SQL engine belum siap');
  if (!filePath || !fs.existsSync(filePath)) {
    throw new Error('File backup tidak ditemukan');
  }

  const stat = fs.statSync(filePath);
  if (!stat.isFile() || stat.size < 100) {
    throw new Error('File backup kosong atau tidak valid');
  }

  const buffer = fs.readFileSync(filePath);
  const backup = new SQL.Database(buffer);

  // Validate that this is one of our bot databases.
  const tables = backup.exec(
    "SELECT name FROM sqlite_master WHERE type='table' AND name IN ('users','transactions')"
  );
  const found = tables?.[0]?.values?.map(row => row[0]) || [];

  if (!found.includes('users')) {
    backup.close();
    throw new Error('Backup tidak memiliki tabel users');
  }

  return backup;
}

function attachBackup(filePath) {
  closeAttachedBackup();
  attachedBackupDb = openBackup(filePath);
}

function normalizeBackupSql(sql) {
  return String(sql || '').replace(/\bbk\./gi, '');
}

function isBackupQuery(sql) {
  return /\b(?:FROM|JOIN|UPDATE|INTO)\s+bk\./i.test(String(sql || ''));
}

function queryDb(targetDb, sql, params = []) {
  const stmt = targetDb.prepare(sql);
  try {
    stmt.bind(params);
    const rows = [];
    while (stmt.step()) {
      const cols = stmt.getColumnNames();
      const vals = stmt.get();
      const row = {};
      cols.forEach((c, i) => { row[c] = vals[i]; });
      rows.push(row);
    }
    return rows;
  } finally {
    stmt.free();
  }
}

function queryOne(targetDb, sql, params = []) {
  const stmt = targetDb.prepare(sql);
  try {
    stmt.bind(params);
    if (!stmt.step()) return null;
    const cols = stmt.getColumnNames();
    const vals = stmt.get();
    const row = {};
    cols.forEach((c, i) => { row[c] = vals[i]; });
    return row;
  } finally {
    stmt.free();
  }
}

function handleTransactionSql(sql) {
  const normalized = String(sql || '').trim().replace(/;\s*$/, '').toUpperCase();
  if (/^BEGIN(?:\s+TRANSACTION)?(?:\s+.*)?$/.test(normalized)) {
    transactionDepth++;
    return;
  }
  if (/^COMMIT$/.test(normalized)) {
    transactionDepth = Math.max(0, transactionDepth - 1);
    saveDb();
    return;
  }
  if (/^ROLLBACK$/.test(normalized)) {
    transactionDepth = 0;
    saveDb();
  }
}

async function initDb() {
  SQL = await initSqlJs();

  try {
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      betterDb = new SQL.Database(fileBuffer);
      console.log('[DB] ✅ Database loaded:', dbPath);
    } else {
      betterDb = new SQL.Database();
      console.log('[DB] ✅ Database created:', dbPath);
    }
  } catch (err) {
    console.error('[DB] ⚠️ DB file corrupt, creating new:', err.message);
    betterDb = new SQL.Database();
  }

  // sql.js is in-memory; these PRAGMA values are harmless where unsupported.
  try { betterDb.run('PRAGMA journal_mode = WAL'); } catch (_) {}
  try { betterDb.run('PRAGMA synchronous = NORMAL'); } catch (_) {}
  try { betterDb.run('PRAGMA cache_size = 4000'); } catch (_) {}
  try { betterDb.run('PRAGMA temp_store = MEMORY'); } catch (_) {}
  try { betterDb.run('PRAGMA busy_timeout = 5000'); } catch (_) {}

  betterDb.run(`CREATE TABLE IF NOT EXISTS users (
    chat_id INTEGER PRIMARY KEY,
    saldo INTEGER DEFAULT 0,
    role TEXT DEFAULT 'members',
    created_at TEXT
  )`);

  betterDb.run(`CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    amount INTEGER,
    status TEXT DEFAULT 'pending',
    created_at TEXT,
    product_type TEXT DEFAULT ''
  )`);

  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN username TEXT DEFAULT ''`); } catch (_) {}
  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN expired_at TEXT DEFAULT ''`); } catch (_) {}
  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN server_ip TEXT DEFAULT ''`); } catch (_) {}

  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_chat_id ON transactions(chat_id)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_status ON transactions(status)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_created_at ON transactions(created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_status_created ON transactions(status, created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_chatid_status ON transactions(chat_id, status, created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_users_role ON users(role)`);

  betterDb.run(`CREATE TABLE IF NOT EXISTS notif_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    days_before INTEGER,
    sent_at TEXT,
    UNIQUE(order_id, days_before)
  )`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_notif_order ON notif_log(order_id, days_before)`);

  saveDb();
  setInterval(saveDb, 30000);
}

const db = {
  run(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    const rawSql = String(sql || '').trim();
    const normalized = rawSql.toUpperCase();

    try {
      // sql.js does not support filesystem ATTACH/DETACH the same way
      // native sqlite3 does. Emulate the two operations in memory so the
      // existing admin restore code can continue to work unchanged.
      if (/^ATTACH\s+DATABASE\s+\?\s+AS\s+BK$/i.test(rawSql)) {
        attachBackup(params[0]);
        if (callback) callback.call({ lastID: 0, changes: 0 }, null);
        return;
      }

      if (/^DETACH\s+DATABASE\s+BK$/i.test(rawSql)) {
        closeAttachedBackup();
        if (callback) callback.call({ lastID: 0, changes: 0 }, null);
        return;
      }

      getDb().run(rawSql, params);
      handleTransactionSql(rawSql);

      const info = { lastID: 0, changes: getDb().getRowsModified() };

      // Persist immediately for normal writes so a Telegram backup always
      // contains the latest users/saldo/transactions. During an explicit
      // transaction we wait for COMMIT.
      if (transactionDepth === 0 && !/^PRAGMA\b/i.test(rawSql)) {
        saveDb();
      } else if (transactionDepth === 0) {
        debounceSave();
      }

      if (callback) callback.call(info, null);
    } catch (err) {
      if (callback) callback.call({}, err);
    }
  },

  get(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    try {
      let target = getDb();
      let query = String(sql || '');
      if (isBackupQuery(query)) {
        if (!attachedBackupDb) throw new Error('Backup database belum di-attach');
        target = attachedBackupDb;
        query = normalizeBackupSql(query);
      }

      const row = queryOne(target, query, params);
      if (callback) callback(null, row);
    } catch (err) {
      if (callback) callback(err, null);
    }
  },

  all(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    try {
      let target = getDb();
      let query = String(sql || '');
      if (isBackupQuery(query)) {
        if (!attachedBackupDb) throw new Error('Backup database belum di-attach');
        target = attachedBackupDb;
        query = normalizeBackupSql(query);
      }

      const rows = queryDb(target, query, params);
      if (callback) callback(null, rows);
    } catch (err) {
      if (callback) callback(err, []);
    }
  },

  exec(sql, callback) {
    try {
      const rawSql = String(sql || '');
      getDb().exec(rawSql);
      handleTransactionSql(rawSql);
      if (transactionDepth === 0) saveDb();
      if (callback) callback(null);
    } catch (err) {
      if (callback) callback(err);
    }
  },

  serialize(fn) {
    if (fn) fn();
  },

  // Explicit flush helper for future backup code.
  flush() {
    return saveDb();
  },

  // Validate a backup without modifying the live database.
  inspectBackup(filePath) {
    const backup = openBackup(filePath);
    try {
      const users = queryDb(backup, 'SELECT * FROM users');
      let transactions = [];
      try { transactions = queryDb(backup, 'SELECT * FROM transactions'); } catch (_) {}
      return { users: users.length, transactions: transactions.length };
    } finally {
      try { backup.close(); } catch (_) {}
    }
  },

  close(callback) {
    try {
      if (saveTimer) clearTimeout(saveTimer);
      saveTimer = null;
      saveDb();
      closeAttachedBackup();
      getDb().close();
      if (callback) callback(null);
    } catch (err) {
      if (callback) callback(err);
    }
  },

  ready: initDb()
};

module.exports = db;
