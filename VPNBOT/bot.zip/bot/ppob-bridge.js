'use strict';
const fs=require('fs');
const path=require('path');

const avarsPath=path.join(__dirname,'data','.avars.json');
let avars={};
try{avars=JSON.parse(fs.readFileSync(avarsPath,'utf8'))}catch{}

if(avars.token && !process.env.TELEGRAM_BOT_TOKEN)process.env.TELEGRAM_BOT_TOKEN=avars.token;
if(!process.env.BOT_TOKEN && process.env.TELEGRAM_BOT_TOKEN)process.env.BOT_TOKEN=process.env.TELEGRAM_BOT_TOKEN;

const ppob=require('./ppob');
const PREFIX='ppob:';
let attached=false;

function normalizeUpdateFromMessage(msg){
  return {update_id:Date.now(),message:msg};
}

/*
 * PPOB ADMIN AUTHORIZATION
 * ------------------------
 * The VPN installer stores the owner ID in data/.avars.json, while
 * the PPOB module normally reads ADMIN_IDS from ppob.env.
 *
 * If ADMIN_IDS is empty/missing, the PPOB admin button used to appear
 * clickable but did nothing. Use both sources as the authority.
 */
function isPpobAdmin(userId){
  const id=String(userId||'');
  if(!id)return false;

  const configured=[
    ...(Array.isArray(ppob.config?.admins)?ppob.config.admins:[]),
    ...(String(process.env.ADMIN_IDS||'').split(',').map(x=>x.trim()).filter(Boolean))
  ].map(String);

  if(configured.includes(id))return true;
  if(String(avars.owner_id||'')===id)return true;

  return false;
}

async function answerCallback(bot,q,text='',showAlert=false){
  try{
    await bot.answerCallbackQuery(q.id,text?{text,show_alert:showAlert}:undefined);
  }catch{}
}

async function openPpobAdmin(bot,q){
  const userId=String(q?.from?.id||'');

  if(!isPpobAdmin(userId)){
    await answerCallback(bot,q,'Menu khusus admin PPOB.',true);
    return;
  }

  await answerCallback(bot,q);

  try{
    /*
     * Telegraf expects a real Telegram update. Keep the original
     * callback_query intact and only replace callback data with the
     * action name registered by ppob.js: bot.action('admin', ...).
     */
    const update={
      update_id:Date.now(),
      callback_query:{
        ...q,
        data:'admin'
      }
    };

    await ppob.handleUpdate(update);
  }catch(e){
    console.error('[PPOB bridge admin]',e.stack||e.message);

    // Give the admin visible feedback instead of leaving the button
    // apparently dead.
    try{
      await bot.editMessageText(
        '❌ <b>Menu Admin PPOB gagal dibuka.</b>\n\n' +
        `<code>${String(e.message||e).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</code>`,
        {
          chat_id:q.message?.chat?.id,
          message_id:q.message?.message_id,
          parse_mode:'HTML'
        }
      );
    }catch{}
  }
}

async function start(bot){
  if(attached)return;
  attached=true;

  await ppob.startPpobServices();

  bot.on('callback_query',async q=>{
    const data=String(q?.data||'');

    /*
     * Admin PPOB is intentionally handled here so it does not depend
     * on the VPN admin callback handler.
     *
     * Both callback formats are accepted for compatibility:
     *   ppob_admin
     *   ppob:ppob_admin
     */
    if(data==='ppob_admin' || data==='ppob:ppob_admin'){
      await openPpobAdmin(bot,q);
      return;
    }

    if(!data.startsWith(PREFIX))return;

    const clean=data.slice(PREFIX.length);

    if(clean==='vpn_home' || clean==='vpn_admin'){
      await answerCallback(bot,q);
      try{
        bot.emit('callback_query',{
          ...q,
          data:clean==='vpn_admin'?'adm_back':'menu_back'
        });
      }catch(e){
        console.error('[PPOB bridge navigation]',e.message);
      }
      return;
    }

    try{
      const update={...q};
      update.data=clean;
      await ppob.handleUpdate({
        update_id:Date.now(),
        callback_query:update
      });
    }catch(e){
      console.error('[PPOB bridge callback]',e.stack||e.message);
      await answerCallback(bot,q,'Terjadi kesalahan.',true);
    }
  });

  bot.on('message',async msg=>{
    const text=String(msg?.text||'');
    const chatId=msg?.chat?.id;
    if(!chatId)return;

    if(/^\/ppob(?:@\w+)?$/i.test(text)){
      try{
        await ppob.openMenu(chatId,msg.from||{});
      }catch(e){
        console.error('[PPOB bridge open]',e.message);
      }
      return;
    }

    if(ppob.isActiveSession(chatId)){
      try{
        await ppob.handleUpdate(normalizeUpdateFromMessage(msg));
      }catch(e){
        console.error('[PPOB bridge message]',e.message);
      }
    }
  });

  console.log('[PPOB] ✅ Bridge aktif — satu polling dengan bot VPN');
}

module.exports={
  start,
  isActiveSession:ppob.isActiveSession,
  openMenu:ppob.openMenu
};
