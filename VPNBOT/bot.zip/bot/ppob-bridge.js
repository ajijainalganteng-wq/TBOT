'use strict';
const fs=require('fs');
const path=require('path');
const TelegramBot=require('node-telegram-bot-api');
const avarsPath=path.join(__dirname,'data','.avars.json');
let avars={};
try{avars=JSON.parse(fs.readFileSync(avarsPath,'utf8'))}catch{}
if(avars.token && !process.env.TELEGRAM_BOT_TOKEN)process.env.TELEGRAM_BOT_TOKEN=avars.token;
if(!process.env.BOT_TOKEN && process.env.TELEGRAM_BOT_TOKEN)process.env.BOT_TOKEN=process.env.TELEGRAM_BOT_TOKEN;
const ppob=require('./ppob');
const PREFIX='ppob:';
let attached=false;
function normalizeUpdateFromMessage(msg){return {update_id:Date.now(),message:msg}}
async function start(bot){
  if(attached)return;
  attached=true;
  await ppob.startPpobServices();
  bot.on('callback_query',async q=>{
    const data=String(q?.data||'');
    if(!data.startsWith(PREFIX))return;
    const clean=data.slice(PREFIX.length);
    if(clean==='vpn_home' || clean==='vpn_admin'){
      bot.answerCallbackQuery(q.id).catch(()=>{});
      try{
        // Kembali ke modul VPN melalui callback handler yang sudah aktif.
        // vpn_home  -> menu utama VPN
        // vpn_admin -> panel admin VPN
        bot.emit('callback_query',{
          ...q,
          data: clean==='vpn_admin' ? 'adm_back' : 'menu_back'
        });
      }catch(e){console.error('[PPOB bridge navigation]',e.message)}
      return;
    }
    if(clean==='ppob_admin'){
      bot.answerCallbackQuery(q.id).catch(()=>{});
      try{
        // Buka panel admin PPOB tanpa membuat bot/polling Telegram kedua.
        const adminIds = (ppob.config.admins || []);
        if(!adminIds.includes(String(q.from?.id))) return;
        await ppob.handleUpdate({
          update_id: Date.now(),
          callback_query: {...q, data:'admin'}
        });
      }catch(e){console.error('[PPOB bridge admin]',e.message)}
      return;
    }
    try{
      const update={...q};
      update.data=clean;
      await ppob.handleUpdate({update_id:Date.now(),callback_query:update});
    }catch(e){console.error('[PPOB bridge callback]',e.message)}
  });
  bot.on('message',async msg=>{
    const text=String(msg?.text||'');
    const chatId=msg?.chat?.id;
    if(!chatId)return;
    // Only /ppob is explicitly routed from the unified VPN bot.
    if(/^\/ppob(?:@\w+)?$/i.test(text)){
      try{await ppob.openMenu(chatId,msg.from||{})}catch(e){console.error('[PPOB bridge open]',e.message)}
      return;
    }
    // Active PPOB sessions receive normal text input.
    if(ppob.isActiveSession(chatId)){
      try{await ppob.handleUpdate(normalizeUpdateFromMessage(msg))}catch(e){console.error('[PPOB bridge message]',e.message)}
    }
  });
  console.log('[PPOB] ✅ Bridge aktif — satu polling dengan bot VPN');
}
module.exports={start,isActiveSession:ppob.isActiveSession,openMenu:ppob.openMenu};
