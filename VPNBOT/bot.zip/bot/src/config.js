require('dotenv').config({path:process.env.PPOB_ENV_FILE || require('path').join(__dirname,'..','ppob.env')});
const csv=s=>String(s||'').split(',').map(x=>x.trim()).filter(Boolean);
const num=(v,d)=>Number.isFinite(Number(v))?Number(v):d;
module.exports={
 botToken:process.env.BOT_TOKEN||process.env.TELEGRAM_BOT_TOKEN,admins:csv(process.env.ADMIN_IDS),requiredChannelId:process.env.REQUIRED_CHANNEL_ID||process.env.PPOB_TRX_CHANNEL_ID||process.env.TRX_CHANNEL_ID||'',requiredChannelUrl:process.env.REQUIRED_CHANNEL_URL||process.env.TRX_CHANNEL_URL||'',botName:process.env.BOT_NAME||'RIPZZ STORE',ownerName:process.env.OWNER_NAME||'Owner',channelId:process.env.PPOB_TRX_CHANNEL_ID||process.env.TRX_CHANNEL_ID||'',tz:process.env.TZ||'Asia/Jakarta',
 digiflazz:{username:process.env.DIGIFLAZZ_USERNAME,apiKey:process.env.DIGIFLAZZ_API_KEY},
 austin:{baseUrl:(process.env.AUSTIN_BASE_URL||'https://austinstore.id').replace(/\/$/,''),apiKey:process.env.AUSTIN_API_KEY,apiSecret:process.env.AUSTIN_API_SECRET||''},
 roles:{default:process.env.DEFAULT_ROLE||'bronze',margin:{bronze:num(process.env.MARGIN_BRONZE,6),silver:num(process.env.MARGIN_SILVER,3),gold:num(process.env.MARGIN_GOLD,1)},price:{silver:num(process.env.ROLE_PRICE_SILVER,0),gold:num(process.env.ROLE_PRICE_GOLD,0)}},
 qrisExpireMinutes:num(process.env.QRIS_EXPIRE_MINUTES,15),syncMinutes:num(process.env.SYNC_INTERVAL_MINUTES,30),paymentPollMs:num(process.env.PAYMENT_POLL_MS,8000),trxPollMs:num(process.env.TRX_POLL_MS,30000),trxMaxPolls:num(process.env.TRX_MAX_POLLS,40),pageSize:num(process.env.PAGE_SIZE,8),storePhoto:process.env.STORE_PHOTO||'assets/store.jpg'
};
