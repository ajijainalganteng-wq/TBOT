'use strict';

const outletku = require('../services/outletku');

async function create(amount, reference) {
  const q = await outletku.createQris(Number(amount), String(reference || `ppob_${Date.now()}`));
  return {
    depositId: q.qrisId,
    id: q.qrisId,
    reference: q.reference,
    amount: q.amount,
    totalAmount: q.amount,
    baseAmount: q.baseAmount,
    uniqueCode: q.uniqueCode,
    qrImage: q.qrImageUrl || null,
    qrCode: q.qrisCode || null,
    expiredAt: q.expiresAt,
    verificationMode: q.verificationMode,
    raw: q.raw
  };
}

async function status(id) {
  const result = await outletku.checkQris(id);
  return { status: result.status, data: result.data };
}

function paid(value) {
  return outletku.parseStatus(value) === 'completed';
}

module.exports = { create, status, paid };
