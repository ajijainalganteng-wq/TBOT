const axios=require('axios'),crypto=require('crypto'),config=require('./config');

function authHeaders(method,path,body=''){
  const h={'X-API-Key':config.austin.apiKey};
  if(body)h['Content-Type']='application/json';
  if(config.austin.apiSecret){
    const timestamp=Date.now().toString();
    const signature=crypto.createHmac('sha256',config.austin.apiSecret)
      .update(`${method}\n${path}\n${body}\n${timestamp}`).digest('hex');
    h['X-Timestamp']=timestamp;
    h['X-Signature']=signature;
  }
  return h;
}

async function create(amount){
  if(!config.austin.apiKey)throw new Error('AUSTIN_API_KEY belum diisi');
  const path='/api/deposit/create';
  const body=JSON.stringify({amount:Number(amount)});
  const r=await axios.post(`${config.austin.baseUrl}${path}`,body,{
    headers:{...authHeaders('POST',path,body),'Content-Type':'application/json'},
    timeout:30000
  });
  if(!r.data?.success||!r.data?.deposit)throw new Error(r.data?.message||'Gagal membuat QRIS AustinPay');
  const d=r.data.deposit;
  return {
    depositId:d.transaction_id||d.id,
    id:d.transaction_id||d.id,
    amount:d.amount,
    totalAmount:d.amount,
    uniqueCode:d.unique_code||0,
    qrImage:d.qr_image||null,
    expiredAt:d.expired_at||null,
    status:d.status
  };
}

async function status(id){
  if(!config.austin.apiKey)throw new Error('AUSTIN_API_KEY belum diisi');
  const path=`/api/deposit/check/${encodeURIComponent(id)}`;
  const r=await axios.get(`${config.austin.baseUrl}${path}`,{
    headers:authHeaders('GET',path,''),
    timeout:30000
  });
  return r.data;
}

function paid(x){
  const layers=[x,x?.data,x?.transaction,x?.payment,x?.result];
  const yes=['success','paid','settlement','settled','completed','complete','done','sukses','berhasil','lunas','capture','accepted','confirmed','terbayar','1','true'];
  for(const l of layers){
    if(!l||typeof l!=='object')continue;
    if(l.paid===true||l.isPaid===true||l.is_paid===true||l.paid===1||l.paid==='1')return true;
    for(const k of ['status','paymentStatus','payment_status','transactionStatus','transaction_status','settlementStatus','settlement_status','statusCode','status_code'])
      if(yes.includes(String(l[k]??'').toLowerCase().trim()))return true;
  }
  return false;
}

module.exports={create,status,paid};
