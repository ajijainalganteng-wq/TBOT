// ============================================================
// RIPZZSTORE PPOB — LAYOUT MENU KATEGORI
// ============================================================
// Telegram tidak menyediakan ukuran button dalam pixel.
// Tata letak di bawah mengatur jumlah tombol per baris secara eksplisit.
// Cukup ubah CATEGORY_LAYOUT untuk memindahkan posisi tombol.
// ============================================================
module.exports = {

  // Urutan baris menu kategori PPOB.
  // Setiap array = satu baris.
  CATEGORY_LAYOUT: [
    ['Data', 'Pulsa'],
    ['Games'],
    ['Masa Aktif', 'E-Money'],
    ['PLN', 'Paket SMS & Telpon']
  ],

  // Tombol bagian bawah menu kategori.
  // Setiap array = satu baris.
  BOTTOM_LAYOUT: [
    ['SEARCH'],
    ['POPULAR'],
    ['HOME']
  ],

  // Dipertahankan untuk kompatibilitas dengan konfigurasi lama.
  CATEGORY_COLUMNS: 3,

  // Nama yang tampil di tombol. Jumlah produk sengaja tidak ditampilkan.
  LABELS: {
    Data: 'Kuota',
    DATA: 'Kuota',
    data: 'Kuota',
    Games: 'Game',
    Game: 'Game',
    games: 'Game',
    'Aktivasi Perdana': 'Perdana',
    'Aktivasi Voucher': 'Voucher',
    'Paket SMS & Telpon': 'SMS & TELPON',
    'Masa Aktif': 'Masa Aktif',
    'E-Money': 'E-Money',
    PLN: 'PLN',
    Pulsa: 'Pulsa',
    Voucher: 'Voucher',
    TV: 'TV',
    Gas: 'Gas'
  }
};
