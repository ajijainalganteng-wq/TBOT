// services/qris.js - Outletku GoPay QRIS H2H — 5min countdown, cancel button
'use strict';

const outletku = require('./outletku');
const db     = require('../data/db');

const QRIS_EXPIRY_MS  = 5 * 60 * 1000;  // Outletku QRIS berlaku 5 menit
const UPDATE_INTERVAL = 10 * 1000;        // update tiap 10 detik (countdown terlihat berjalan)

/* Map untuk menyimpan countdown intervals agar bisa di-cancel saat bayar */
const countdownIntervals = new Map();

function clearCountdown(orderId) {
  const iv = countdownIntervals.get(orderId);
  if (iv) { clearInterval(iv); countdownIntervals.delete(orderId); }
}

module.exports.clearQrisCountdown = clearCountdown;

async function generateQRIS(bot, chatId, amount, pendingInfo = {}) {
  const orderId = `${chatId}_${Date.now()}`;

  try {
    const gateway = await outletku.createQris(Number(amount), orderId);
    const qrValue = gateway.qrisCode;
    if (!qrValue && !gateway.qrImageUrl) throw new Error('Outletku tidak mengembalikan qris_code atau gambar QRIS.');
    const qrBuffer = qrValue ? await require('qrcode').toBuffer(qrValue, { width: 350 }) : null;
    const productType = pendingInfo.productType || '';
    db.run(
      "INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type) VALUES (?, ?, ?, 'pending', datetime('now','localtime'), ?)",
      [chatId, orderId, amount, productType]
    );

    const isCreate = !!pendingInfo.accountCreate;
    const isRenew  = !!pendingInfo.accountRenew;

    function buildCaption(remainingMs) {
      const totalSecs = Math.max(0, Math.floor(remainingMs / 1000));
      const mm  = String(Math.floor(totalSecs / 60)).padStart(2, '0');
      const ss  = String(totalSecs % 60).padStart(2, '0');
      const pct = Math.max(0, remainingMs / expiryMs);  // 1.0 → 0.0

      const bar = pct >= 0.80 ? '🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩'
        : pct >= 0.60 ? '🟩🟩🟩🟩🟩🟩🟩🟩⬜⬜'
        : pct >= 0.40 ? '🟩🟩🟩🟩🟩🟩⬜⬜⬜⬜'
        : pct >= 0.20 ? '🟨🟨🟨🟨⬜⬜⬜⬜⬜⬜'
        : '🟥🟥⬜⬜⬜⬜⬜⬜⬜⬜';

      let typeLabel = '';
      if (isCreate)     typeLabel = `💳 <b>PEMBAYARAN AKUN ${pendingInfo.productName || ''}</b>`;
      else if (isRenew) typeLabel = `💳 <b>PEMBAYARAN EXTEND ${pendingInfo.productName || ''}</b>`;
      else              typeLabel = `💳 <b>TOP UP SALDO</b>`;

      return `${typeLabel}\n\n` +
        `💰 Nominal  : <b>Rp ${amount.toLocaleString('id-ID')}</b>\n` +
        `🧾 Order ID : <code>${orderId}</code>\n\n` +
        `⏰ Kadaluarsa : <b>${mm}:${ss}</b>\n` +
        `${bar}\n\n` +
        `⚡ ${isCreate ? 'Akun <b>otomatis dibuat</b>' : isRenew ? 'Akun <b>otomatis di-extend</b>' : 'Saldo <b>otomatis masuk</b>'} setelah lunas!\n\n` +
        `<i>Scan QR di atas dengan aplikasi dompet digital Anda.</i>`;
    }

    const cancelKeyboard = {
      inline_keyboard: [
        [{ text: '🔄 Cek Status Bayar', callback_data: `refresh_${orderId}` }],
        [{ text: '❌ Batalkan QRIS',    callback_data: `cancel_qris_${orderId}` }]
      ]
    };

    const startTime = Date.now();
    const expiryMs = gateway.expiresAt ? Math.max(1000, new Date(gateway.expiresAt).getTime() - Date.now()) : QRIS_EXPIRY_MS;
    const photoMsg  = await bot.sendPhoto(chatId, qrBuffer || gateway.qrImageUrl, {
      caption:    buildCaption(expiryMs),
      parse_mode: 'HTML',
      reply_markup: cancelKeyboard
    });

    const qrMsgId = photoMsg?.message_id;

    /* ── COUNTDOWN setiap 10 detik ── */
    const iv = setInterval(() => {
      const elapsed   = Date.now() - startTime;
      const remaining = expiryMs - elapsed;

      if (remaining <= 0) {
        clearInterval(iv);
        countdownIntervals.delete(orderId);
        bot.editMessageCaption(`❌ <b>QRIS Kadaluarsa</b>\n\nOrder ID: <code>${orderId}</code>\n\nBuat order baru melalui /menu.`, {
          chat_id: chatId, message_id: qrMsgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
        }).catch(() => {});
        return;
      }

      bot.editMessageCaption(buildCaption(remaining), {
        chat_id: chatId, message_id: qrMsgId, parse_mode: 'HTML',
        reply_markup: cancelKeyboard
      }).catch(() => {});
    }, UPDATE_INTERVAL);

    countdownIntervals.set(orderId, iv);

    const { addPendingOrder } = require('./paymentChecker');
    addPendingOrder(orderId, {
      chatId,
      amount,
      qrisId: gateway.qrisId,
      gatewayAmount: gateway.amount,
      expiresAt: gateway.expiresAt ? new Date(gateway.expiresAt).getTime() : Date.now() + QRIS_EXPIRY_MS,
      qrMsgId,
      productName:   pendingInfo.productName   || 'Topup Saldo',
      productType,
      accountCreate: pendingInfo.accountCreate || null,
      accountRenew:  pendingInfo.accountRenew  || null
    });

  } catch (err) {
    console.error('[generateQRIS] ❌', err.message);
    bot.sendMessage(chatId, '❌ Gagal membuat QRIS: ' + err.message);
  }
}

module.exports.generateQRIS = generateQRIS;
