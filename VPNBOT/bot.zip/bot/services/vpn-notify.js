'use strict';

const fs = require('fs');
const path = require('path');

function loadAvars() {
  try {
    return JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8'));
  } catch (_) {
    return {};
  }
}

function esc(v) {
  return String(v ?? '-')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function rp(v) {
  return `Rp.${Number(v || 0).toLocaleString('id-ID')}`;
}

function dateTime() {
  const d = new Date();
  const date = new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Jakarta', day:'2-digit', month:'2-digit', year:'numeric'
  }).format(d).replace(/\//g,'.');
  const time = new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Jakarta', hour:'2-digit', minute:'2-digit', hour12:false
  }).format(d);
  return { date, time };
}

function getChannelId() {
  const a = loadAvars();
  return String(
    process.env.VPN_TRX_CHANNEL_ID ||
    process.env.TRX_CHANNEL_ID ||
    a.vpn_trx_channel_id ||
    a.trx_channel_id ||
    ''
  ).trim();
}

async function getServer(serverIp) {
  try {
    const servers = require('../data/server');
    return servers.find(s => String(s.ip) === String(serverIp)) || {};
  } catch (_) {
    return {};
  }
}

async function getTelegramUser(bot, chatId) {
  try {
    const u = await bot.getChat(chatId);
    return {
      username: u.username ? `@${u.username}` : '-',
      name: u.first_name || u.title || '-',
      id: chatId
    };
  } catch (_) {
    return { username:'-', name:'-', id:chatId };
  }
}

function roleLabel(role) {
  if (role === 'admin') return 'Admin 👑';
  if (role === 'reseller') return 'Reseller 🏆';
  return 'Member';
}

async function notifyVpnAccount(bot, {
  chatId, type, parsed = {}, data = {}, role = 'members',
  totalHarga = 0, pricePerDay = 0, balance = 0, serverIp = '', trxNo = ''
}) {
  const channelId = getChannelId();
  if (!channelId || !bot) return false;

  const [user, server] = await Promise.all([
    getTelegramUser(bot, chatId),
    getServer(serverIp)
  ]);

  const { date, time } = dateTime();
  const username = parsed.USERNAME || data.username || '-';
  const name = parsed.NAME || parsed.NAMA || '-';
  const limitIp = parsed.LIMIT_IP || data.limitIp || '-';
  const quota = parsed.QUOTA !== undefined
    ? (String(parsed.QUOTA) === '0' ? 'Unlimited' : `${parsed.QUOTA} GB`)
    : (data.quota === 0 ? 'Unlimited' : `${data.quota ?? '-'} GB`);

  const product = String(type || 'VPN').toUpperCase();
  const domain = parsed.DOMAIN || server.domain || server.hostname || server.ip || serverIp || '-';
  const isp = parsed.ISP || server.isp || server.ISP || '-';
  const serverName = server.name || parsed.SERVER || parsed.SERVER_NAME || serverIp || '-';

  const text =
`╭──────────────╮
   📦 TRANSAKSI BERHASIL 📦
╰──────────────╯

📒 No Trx       : #${esc(trxNo || String(Date.now()).slice(-6))}
🌀 Status       : ${esc(roleLabel(role))}
👤 Username     : ${esc(user.username)}
🆔 ID           : ${esc(user.id)}

🌐 Server       : ${esc(serverName)}
📡 ISP          : ${esc(isp)}
🔗 Domain/IP    : ${esc(domain)}
🙍 Nama         : ${esc(name)}

📦 Produk       : ${esc(product)}
📊 Limit Quota  : ${esc(quota)}
📱 Limit Login  : ${esc(limitIp)} HP
⚙️ Tipe         : Buat Akun
⏳ Durasi Akun  : ${esc(data.days || '-')} Hari — ${rp(totalHarga)}
💲 Normal/Hari  : ${rp(pricePerDay)}

💳 Saldo Keluar : ${rp(totalHarga)}
💰 Saldo Now    : ${rp(balance)}

📅 Tanggal      : ${date}
⏰ Waktu        : ${time} WIB

━━━━━━━━━━━━━━
📝 Catatan: Simpan nomor transaksi untuk support
━━━━━━━━━━━━━━`;

  try {
    // Saldo Now diambil ulang oleh caller bila diperlukan; pesan tetap dikirim
    // jika channel sedang aktif.
    await bot.sendMessage(channelId, text, { parse_mode:'HTML' });
    return true;
  } catch (e) {
    console.error('[VPN NOTIF] gagal kirim channel:', e.message);
    return false;
  }
}

async function notifyVpnTopup(bot, {
  chatId, amount, bonus = 0, balance = 0, role = 'members',
  payment = 'Pakasir', trxNo = ''
}) {
  const channelId = getChannelId();
  if (!channelId || !bot) return false;
  const user = await getTelegramUser(bot, chatId);
  const { date, time } = dateTime();

  const text =
`╭──────────────╮
   💳 TOP UP BERHASIL 💳
╰──────────────╯

📒 No Trx       : #${esc(trxNo || String(Date.now()).slice(-6))}
🌀 Status       : Pembayaran Lunas ✅
👤 Username     : ${esc(user.username)}
🆔 ID           : ${esc(user.id)}

💳 Payment      : ${esc(payment)}
💵 Nominal      : ${rp(amount)}
🎁 Bonus        : ${rp(bonus)}
💰 Saldo Masuk  : ${rp(Number(amount) + Number(bonus))}
💳 Saldo Now    : ${rp(balance)}
🎖️ Role         : ${esc(roleLabel(role))}

📅 Tanggal      : ${date}
⏰ Waktu        : ${time} WIB

━━━━━━━━━━━━━━
📝 Catatan: Simpan nomor transaksi untuk support
━━━━━━━━━━━━━━`;

  try {
    await bot.sendMessage(channelId, text, { parse_mode:'HTML' });
    return true;
  } catch (e) {
    console.error('[VPN NOTIF] gagal kirim channel:', e.message);
    return false;
  }
}

module.exports = { notifyVpnAccount, notifyVpnTopup, getChannelId };
