'use strict';

// Outletku GoPay QRIS H2H adapter.
// Configuration: OUTLETKU_GATEWAY_URL / P2P_GATEWAY_URL and
// OUTLETKU_API_KEY / P2P_API_KEY. Legacy .avars.json keys are also supported.
const fs = require('fs');
const path = require('path');
const axios = require('axios');

function readAvars() {
  try {
    return JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8'));
  } catch (_) {
    return {};
  }
}
function settings() {
  const a = readAvars();
  const gatewayUrl = String(
    process.env.OUTLETKU_GATEWAY_URL ||
    process.env.P2P_GATEWAY_URL ||
    a.outletku_gateway_url ||
    a.p2p_gateway_url ||
    'https://payment-gateway.outletku.ai.id'
  ).trim().replace(/\/+$/, '');
  const apiKey = String(
    process.env.OUTLETKU_API_KEY ||
    process.env.P2P_API_KEY ||
    a.outletku_api_key ||
    a.p2p_api_key ||
    ''
  ).trim();
  return { gatewayUrl, apiKey };
}
function apiUrl(suffix) {
  const { gatewayUrl } = settings();
  return `${gatewayUrl}/api/h2h/v1${suffix}`;
}
function headers() {
  const { apiKey } = settings();
  if (!apiKey) throw new Error('OUTLETKU_API_KEY / P2P_API_KEY belum diisi (kunci gk_).');
  return { 'x-api-key': apiKey, 'Content-Type': 'application/json' };
}
function normalizeExpiry(value) {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value === 'number' || /^\d+(\.\d+)?$/.test(String(value))) {
    const n = Number(value);
    return new Date(n < 1e12 ? n * 1000 : n).toISOString();
  }
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}
function parseStatus(payload) {
  const layers = [payload, payload?.data, payload?.transaction, payload?.payment, payload?.result];
  for (const obj of layers) {
    if (!obj || typeof obj !== 'object') continue;
    const raw = obj.status ?? obj.payment_status ?? obj.paymentStatus ??
      obj.transaction_status ?? obj.transactionStatus ?? obj.state;
    if (raw === undefined || raw === null) continue;
    const s = String(raw).trim().toLowerCase();
    if (['paid','success','successful','completed','complete','settlement','settled','lunas','berhasil','terbayar','confirmed'].includes(s)) return 'completed';
    if (['expired','expire','kadaluarsa','kadaluwarsa'].includes(s)) return 'expired';
    if (['cancelled','canceled','cancel','dibatalkan','failed','failure','gagal','rejected'].includes(s)) return 'canceled';
    if (['pending','waiting','unpaid','created','processing','menunggu','belum_bayar'].includes(s)) return 'pending';
  }
  return 'unknown';
}
async function createQris(amount, reference) {
  const n = Number(amount);
  if (!Number.isSafeInteger(n) || n <= 0) throw new Error('Nominal QRIS tidak valid.');
  if (!reference || typeof reference !== 'string') throw new Error('Reference transaksi tidak valid.');
  let response;
  try {
    response = await axios.post(apiUrl('/gopay/qris'), {
      amount: n,
      reference,
      use_unique_code: true
    }, { headers: headers(), timeout: 20000 });
  } catch (e) {
    const status = e.response?.status;
    const body = e.response?.data || {};
    if (status === 409) throw new Error('Nominal bentrok dengan QRIS aktif lain (409). Coba nominal lain atau tunggu QRIS lama kedaluwarsa.');
    if (status === 410) throw new Error('QRIS kedaluwarsa (410). Buat QRIS baru.');
    if (status === 503) throw new Error('Layanan akun gateway tidak berjalan (503). Coba lagi nanti.');
    if (status === 401 || status === 403) throw new Error(`API Key Outletku tidak valid atau lisensi tidak aktif (HTTP ${status}).`);
    throw new Error(body.message || body.error || e.message || `Gagal membuat QRIS (HTTP ${status || 'network'}).`);
  }
  const json = response.data || {};
  const d = json.data;
  if (!response.data || !json.success || !d) throw new Error(json.message || json.error || 'Respons pembuatan QRIS Outletku tidak valid.');
  const qrisId = d.qris_id || d.trx_id;
  if (!qrisId) throw new Error('Respons Outletku tidak memiliki qris_id/trx_id.');
  let detail = {};
  try {
    const r = await axios.get(apiUrl(`/gopay/qris/${encodeURIComponent(d.qris_id || qrisId)}`), {
      headers: headers(), timeout: 12000
    });
    detail = r.data?.data || {};
  } catch (_) {}
  const qrisCode = d.qris_code || detail.qris_code || '';
  let qrImageUrl = d.qr_image_url || detail.qr_image_url || '';
  // qris_url may be an internal loopback URL and cannot be displayed to customers.
  if (!qrImageUrl && qrisCode) {
    qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=350x350&data=${encodeURIComponent(qrisCode)}`;
  }
  return {
    qrisId: d.qris_id || qrisId,
    trxId: d.trx_id || qrisId,
    reference: d.reference || reference,
    qrisUrl: d.qris_url || '',
    qrisCode,
    qrImageUrl,
    baseAmount: Number(d.base_amount ?? n),
    uniqueCode: Number(d.unique_code || 0),
    amount: Number(d.amount ?? n),
    expiresAt: normalizeExpiry(d.expires_at || detail.expires_at),
    verificationMode: d.verification_mode || detail.verification_mode || '',
    raw: d
  };
}
async function getQris(qrisId) {
  if (!qrisId) throw new Error('qris_id tidak tersedia.');
  try {
    const r = await axios.get(apiUrl(`/gopay/qris/${encodeURIComponent(qrisId)}`), {
      headers: headers(), timeout: 12000
    });
    return r.data?.data || r.data || {};
  } catch (e) {
    const status = e.response?.status;
    if (status === 410) return { status: 'expired' };
    if (status === 401 || status === 403) throw new Error(`API Key Outletku tidak valid (HTTP ${status}).`);
    if (status === 503) throw new Error('Layanan akun Outletku sedang tidak berjalan (503).');
    throw e;
  }
}
async function checkQris(qrisId) {
  const detail = await getQris(qrisId);
  return { status: parseStatus(detail), data: detail };
}
module.exports = { settings, createQris, getQris, checkQris, parseStatus, normalizeExpiry };
