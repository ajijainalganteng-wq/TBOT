#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/root/ripzz-store-unified}"
BOT_DIR="$APP_DIR/bot"
SERVICE_NAME="ripzz-store-bot"

c_green='\033[1;32m'; c_cyan='\033[1;36m'; c_yellow='\033[1;33m'; c_red='\033[1;31m'; c_reset='\033[0m'
info(){ echo -e "${c_cyan}$*${c_reset}"; }
ok(){ echo -e "${c_green}✓ $*${c_reset}"; }
warn(){ echo -e "${c_yellow}⚠ $*${c_reset}"; }

if [ "$(id -u)" -ne 0 ]; then echo "Jalankan sebagai root."; exit 1; fi

echo
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "      RIPZZ STORE UNIFIED INSTALLER"
echo "       VPN + PPOB • ONE TELEGRAM BOT"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo

read -rp "Bot Token Telegram                  : " BOT_TOKEN
read -rp "Owner ID Telegram                   : " OWNER_ID
read -rp "Nama Bot                            : " BOT_NAME
BOT_NAME="${BOT_NAME:-RIPZZ STORE}"

echo
info "━━ PAYMENT VPN (PAKASIR) ━━"
read -rp "Pakasir Project/Slug                : " PAKASIR_SLUG
read -rp "Pakasir API Key                     : " PAKASIR_API_KEY
read -rp "Channel notif transaksi VPN (@.../-100...) : " VPN_TRX_CHANNEL_ID

echo
info "━━ PPOB DIGIFLAZZ ━━"
read -rp "Digiflazz Username                   : " DIGIFLAZZ_USERNAME
read -rp "Digiflazz API Key                    : " DIGIFLAZZ_API_KEY
read -rp "Channel notif PPOB (@.../-100...)    : " PPOB_TRX_CHANNEL_ID

echo
info "━━ PAYMENT PPOB (AUSTINPAY) ━━"
read -rp "AustinPay API Key                    : " AUSTIN_API_KEY
read -rp "AustinPay API Secret (opsional)      : " AUSTIN_API_SECRET
read -rp "AustinPay Base URL [https://austinstore.id] : " AUSTIN_BASE_URL
AUSTIN_BASE_URL="${AUSTIN_BASE_URL:-https://austinstore.id}"

echo
info "━━ CHANNEL WAJIB (OPSIONAL) ━━"
read -rp "Channel wajib join (@username/-100...; kosong=nonaktif) : " REQUIRED_CHANNEL_ID
if [ -n "$REQUIRED_CHANNEL_ID" ]; then
  read -rp "Link channel wajib (https://t.me/...) : " REQUIRED_CHANNEL_URL
else
  REQUIRED_CHANNEL_URL=""
fi

read -rp "Owner Name (opsional)                : " OWNER_NAME
read -rp "Default role PPOB [bronze]           : " DEFAULT_ROLE
DEFAULT_ROLE="${DEFAULT_ROLE:-bronze}"

echo
warn "Bot token/API key jangan dibagikan di chat atau screenshot."
echo

apt-get update -y
apt-get install -y curl unzip ca-certificates build-essential

if ! command -v node >/dev/null 2>&1; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi

mkdir -p "$APP_DIR"
# Jika script dijalankan dari folder paket, gunakan folder bot yang ada.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ "$SCRIPT_DIR" != "$APP_DIR" ]; then
  rm -rf "$APP_DIR/bot"
  cp -a "$SCRIPT_DIR/bot" "$APP_DIR/bot"
fi

mkdir -p "$BOT_DIR/data"
cat > "$BOT_DIR/data/.avars.json" <<EOF
{
  "token": $(printf '%s' "$BOT_TOKEN" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'),
  "owner_id": $(printf '%s' "$OWNER_ID" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'),
  "bot_name": $(printf '%s' "$BOT_NAME" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'),
  "owner_name": $(printf '%s' "$OWNER_NAME" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'),
  "pakasir_slug": $(printf '%s' "$PAKASIR_SLUG" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'),
  "pakasir_api_key": $(printf '%s' "$PAKASIR_API_KEY" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'),
  "vpn_trx_channel_id": $(printf '%s' "$VPN_TRX_CHANNEL_ID" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))')
}
EOF

cat > "$BOT_DIR/ppob.env" <<EOF
BOT_TOKEN=$BOT_TOKEN
ADMIN_IDS=$OWNER_ID
BOT_NAME=$BOT_NAME
OWNER_NAME=$OWNER_NAME
PPOB_TRX_CHANNEL_ID=$PPOB_TRX_CHANNEL_ID
TRX_CHANNEL_ID=$PPOB_TRX_CHANNEL_ID
REQUIRED_CHANNEL_ID=$REQUIRED_CHANNEL_ID
REQUIRED_CHANNEL_URL=$REQUIRED_CHANNEL_URL
DIGIFLAZZ_USERNAME=$DIGIFLAZZ_USERNAME
DIGIFLAZZ_API_KEY=$DIGIFLAZZ_API_KEY
AUSTIN_BASE_URL=$AUSTIN_BASE_URL
AUSTIN_API_KEY=$AUSTIN_API_KEY
AUSTIN_API_SECRET=$AUSTIN_API_SECRET
DEFAULT_ROLE=$DEFAULT_ROLE
MARGIN_BRONZE=12
MARGIN_SILVER=6
MARGIN_GOLD=3
ROLE_PRICE_SILVER=0
ROLE_PRICE_GOLD=0
QRIS_EXPIRE_MINUTES=15
SYNC_INTERVAL_MINUTES=30
PAYMENT_POLL_MS=8000
TRX_POLL_MS=30000
TRX_MAX_POLLS=40
PAGE_SIZE=8
TZ=Asia/Jakarta
STORE_PHOTO=assets/store.jpg
EOF

chmod 600 "$BOT_DIR/data/.avars.json" "$BOT_DIR/ppob.env"
chmod +x "$BOT_DIR"/shell_script/* 2>/dev/null || true

cd "$BOT_DIR"
npm install --omit=dev

cat > "/etc/systemd/system/$SERVICE_NAME.service" <<EOF
[Unit]
Description=RIPZZ STORE Unified VPN + PPOB Telegram Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$BOT_DIR
ExecStart=/usr/bin/node index.js
Restart=always
RestartSec=5
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"

sleep 2
if systemctl is-active --quiet "$SERVICE_NAME"; then
  ok "RIPZZ STORE Unified berhasil aktif."
  echo "Service : $SERVICE_NAME"
  echo "Folder  : $BOT_DIR"
  echo
  echo "Log:"
  echo "  journalctl -u $SERVICE_NAME -f"
else
  echo -e "${c_red}Bot gagal start. Jalankan:${c_reset}"
  echo "  journalctl -u $SERVICE_NAME -n 100 --no-pager"
  exit 1
fi
