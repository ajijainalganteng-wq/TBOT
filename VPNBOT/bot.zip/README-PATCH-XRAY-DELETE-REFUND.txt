RIPZZ STORE UNIFIED — XRAY + DELETE REFUND PATCH

1. VMESS/VLESS/TROJAN create scripts were replaced with non-interactive scripts based on the supplied bot(1) shell logic. They accept the Telegram bot positional arguments and support legacy #vmess/#vmessgrpc, #vless/#vlessgrpc and #trojanws/#trojangrpc markers, with tag/protocol fallback.
2. Delete scripts remove the account safely and validate xray before applying.
3. Renew scripts are non-interactive and update the same marker databases.
4. Normal users see only BUAT AKUN, HAPUS AKUN, PERPANJANG AKUN for VPN operations. Admin keeps the complete VPN controls.
5. Delete refund: remaining calendar days x current admin price/day, capped at the original transaction amount. Refund is credited only after remote deletion returns STATUS:DELETED.
6. Transaction metadata stores duration_days, price_per_day, refunded_at, refund_amount for safe accounting.
