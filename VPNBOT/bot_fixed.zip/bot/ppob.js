const {Telegraf,Markup}=require('telegraf');
const fs=require('fs'),path=require('path'),os=require('os'),{execFileSync}=require('child_process'),axios=require('axios');
const config=require('./src/config'),db=require('./src/db'),digi=require('./src/digiflazz'),payment=require('./src/payment'),ppobLayout=require('./src/ppob-layout');
if(!config.botToken)throw new Error('BOT_TOKEN belum diisi');
const bot=new Telegraf(config.botToken),sessions=new Map(),locks=new Set(),loading=new Map();
const BRIDGE_PREFIX='ppob:';
const rawTelegramSendMessage=bot.telegram.sendMessage.bind(bot.telegram);
bot.telegram.sendMessage=async(...args)=>{
  const m=await rawTelegramSendMessage(...args);
  const chatId=typeof args[0]==='object'?args[0]?.chat_id:args[0];
  // Hanya pesan yang memang bersifat sementara yang diberi timer global.
  // Pesan hasil transaksi, menu utama, dan QR ditangani secara eksplisit.
  if(String(chatId)!==String(config.channelId||'') && m?.message_id){
    scheduleDelete(chatId,m.message_id);
  }
  return m;
};
const rp=n=>'Rp'+Number(n||0).toLocaleString('id-ID');
const esc=s=>String(s??'-').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const roleLabel=r=>({bronze:'🥉 BRONZE',silver:'🥈 SILVER',gold:'🥇 GOLD'}[r]||'🥉 BRONZE');
const idgen=()=>`RZ${Date.now().toString(36).toUpperCase()}${Math.random().toString(36).slice(2,7).toUpperCase()}`;
const admin=ctx=>config.admins.includes(String(ctx.from.id));
// ============================================================
// RIPZZSTORE — TELEGRAM COLORED BUTTONS
// Telegram supports only 3 predefined inline-button styles:
// primary (blue), success (green), danger (red).
// Edit these rules here if you want to change the color scheme.
// ============================================================
// ============================================================
// BUTTON STYLE ENGINE — Telegram hanya mendukung:
// primary (biru), success (hijau), danger (merah).
// Aturan dibuat terpusat agar seluruh keyboard mudah diedit.
// ============================================================
function buttonStyle(text, style, callbackData='') {
  if (style) return style;

  const t = String(text || '').toUpperCase();
  const c = String(callbackData || '').toLowerCase();

  // 🔴 MERAH — pembatalan / penghapusan / pengurangan saldo / tindakan berisiko.
  if (
    /❌|BATAL|CANCEL|HAPUS|DELETE|KURANGI|REMOVE|TOLAK|RESET|MIN SALDO|KELUAR/.test(t) ||
    /^(cancel|cancelbuy|adm:minsaldo|delete|remove)(:|$)/.test(c)
  ) return 'danger';

  // 🟢 HIJAU — transaksi / konfirmasi / uang masuk / sinkronisasi / aksi utama.
  if (
    /BELI|KONFIRMASI|DEPOSIT|TAMBAH|\+SALDO|RESTORE|SYNC|CEK PEMBAYARAN|DOWNLOAD|UPGRADE|LANJUT|BUY LAGI/.test(t) ||
    /^(buy|confirmbuy|deposit|buyrole|repeat|paycheck|adm:addsaldo|adm:restore|adm:sync|adm:backup)(:|$)/.test(c)
  ) return 'success';

  // 🟢 HIJAU — beberapa menu layanan utama.
  if (/^(ppob|saldo|popular:|adm:digisaldo)(:|$)/.test(c)) return 'success';

  // 🔴 MERAH — tipe pascabayar/populer agar keyboard tidak didominasi biru.
  if (/^type:pasca(:|$)/.test(c) || /^popular:/.test(c)) return 'danger';

  // 🔵 BIRU — navigasi, pencarian, informasi, profil, riwayat, dll.
  return 'primary';
}

function productCategoryStyle(category) {
  const c = String(category || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

  if (/(^| )(data|kuota|internet)( |$)/.test(c)) return 'success';
  if (/(^| )pulsa( |$)/.test(c)) return 'primary';
  if (/(^| )games?( |$)/.test(c)) return 'danger';
  if (/(^| )pln|listrik/.test(c)) return 'success';
  if (/masa ?aktif/.test(c)) return 'success';
  if (/e ?money|emoney|uang elektronik/.test(c)) return 'primary';
  if (/vouchers?/.test(c)) return 'danger';
  if (/sms|telp|telepon/.test(c)) return 'primary';

  // Kategori tambahan yang umum di Digiflazz.
  if (/perdana|aktivasi/.test(c)) return 'success';
  if (/tv|streaming/.test(c)) return 'primary';
  if (/gas/.test(c)) return 'success';

  return 'primary';
}

function productButton(text, callbackData, category) {
  return btn(text, callbackData, productCategoryStyle(category));
}

function btn(text, callbackData, style) {
  return {
    text: String(text),
    callback_data: BRIDGE_PREFIX + String(callbackData),
    style: buttonStyle(text, style, callbackData)
  };
}
const photoPath=()=>path.isAbsolute(config.storePhoto)?config.storePhoto:path.join(__dirname,config.storePhoto);
function user(ctx){return db.getUser(String(ctx.from.id),ctx.from.username?`@${ctx.from.username}`:(ctx.from.first_name||'User'))}
function menu(ctx){const rows=[[btn('🛒 PPOB','ppob'),btn('💰 SALDO','saldo'),btn('➕ DEPOSIT','deposit')],[btn('📜 RIWAYAT','history'),btn('🎖️ ROLE','role')],[btn('👤 PROFIL','profile')]];if(ctx&&admin(ctx))rows.push([btn('🛠 ADMIN','admin')]);return Markup.inlineKeyboard(rows)}
function nav(...buttons){return Markup.inlineKeyboard([...buttons,[btn('🏠 MENU UTAMA VPN','vpn_home')]])}
const AUTO_DELETE_INCOMING_MS=1500;
const AUTO_DELETE_BOT_MS=60000;

// Pesan yang harus tetap tampil (menu utama & QRIS) disimpan di sini
// agar timer auto-delete global tidak ikut menghapusnya.
const protectedMessages=new Set();
const deleteTimers=new Map();

async function deleteMessage(chatId,messageId,force=false){
  if(!chatId||!messageId)return false;
  const key=`${chatId}:${messageId}`;
  if(protectedMessages.has(key) && !force)return false;
  const timer=deleteTimers.get(key);
  if(timer){clearTimeout(timer);deleteTimers.delete(key)}
  try{await bot.telegram.deleteMessage(chatId,messageId);return true}catch{return false}
}
async function deleteCtxMessage(ctx){return deleteMessage(ctx.chat?.id,ctx.message?.message_id)}
function protectMessage(chatId,messageId){
  if(!chatId||!messageId)return;
  const key=`${chatId}:${messageId}`;
  protectedMessages.add(key);
  const timer=deleteTimers.get(key);
  if(timer){clearTimeout(timer);deleteTimers.delete(key)}
}
function unprotectMessage(chatId,messageId){
  if(!chatId||!messageId)return;
  protectedMessages.delete(`${chatId}:${messageId}`);
}
function scheduleDelete(chatId,messageId,ms=AUTO_DELETE_BOT_MS){
  if(!chatId||!messageId)return;
  const key=`${chatId}:${messageId}`;
  if(protectedMessages.has(key))return;
  const old=deleteTimers.get(key);
  if(old)clearTimeout(old);
  const timer=setTimeout(async()=>{
    deleteTimers.delete(key);
    if(!protectedMessages.has(key))await deleteMessage(chatId,messageId);
  },ms);
  deleteTimers.set(key,timer);
}
async function tempReply(ctx,text,extra={},ms=7000){
  try{const m=await ctx.reply(text,extra);setTimeout(()=>deleteMessage(ctx.chat.id,m.message_id),ms);return m}catch{return null}
}
async function tempSend(chatId,text,extra={},ms=7000){
  try{const m=await bot.telegram.sendMessage(chatId,text,extra);setTimeout(()=>deleteMessage(chatId,m.message_id),ms);return m}catch{return null}
}
async function sendPersistent(chatId,text,extra={}){
  try{return await bot.telegram.sendMessage(chatId,text,extra)}catch{return null}
}
async function safeEdit(ctx,text,extra={}){try{return await ctx.editMessageText(text,{parse_mode:'HTML',...extra})}catch{if(ctx.callbackQuery?.message?.message_id){unprotectMessage(ctx.chat?.id,ctx.callbackQuery.message.message_id);await deleteMessage(ctx.chat?.id,ctx.callbackQuery.message.message_id,true)}return ctx.reply(text,{parse_mode:'HTML',...extra})}}
async function notify(text){
  if(!config.channelId)return;
  try{
    const me=await bot.telegram.getMe().catch(()=>null);
    const url=me?.username?`https://t.me/${me.username}?start=order`:'';
    const extra={parse_mode:'HTML'};
    if(url)extra.reply_markup={inline_keyboard:[[{text:'🛒 ORDER DI BOT',url}]]};
    await bot.telegram.sendMessage(config.channelId,`<blockquote>❝\n${text}\n❞</blockquote>`,extra);
  }catch(e){console.error('channel:',e.message)}
}
function specText(p){const s=digi.destinationSpec(p.category,p.brand);return `${esc(s.label)} — contoh: <code>${esc(s.placeholder)}</code>`}
function price(p,type,role){return digi.sellPrice(p,role,type)}
function homeText(){return `<b>🔥 RIPZZ STORE</b>\n\n<b>PPOB • DIGITAL • 24 JAM</b>\n\nSolusi pembelian otomatis\n• Cepat\n• Aman\n• Tanpa menunggu admin\n\n📶 Kuota  •  📱 Pulsa  •  🎮 Game\n⚡ PLN  •  💳 E-Money  •  🎟️ Voucher\n\n💳 Deposit QRIS otomatis\n🎖️ Harga menyesuaikan role member\n\nSilakan pilih menu:`}

async function sendHome(ctx){
  // Menu utama WAJIB permanen. Jangan gunakan ctx.reply wrapper yang
  // memiliki auto-delete; kirim langsung lalu tandai protected.
  if(ctx.callbackQuery?.message?.message_id){unprotectMessage(ctx.chat?.id,ctx.callbackQuery.message.message_id);await deleteMessage(ctx.chat?.id,ctx.callbackQuery.message.message_id,true)}
  const photo=photoPath();
  let m=null;
  try{
    if(fs.existsSync(photo)){
      m=await ctx.telegram.sendPhoto(ctx.chat.id,{source:photo},{
        caption:homeText(),
        parse_mode:'HTML',
        ...menu(ctx)
      });
    }else{
      m=await rawTelegramSendMessage(ctx.chat.id,homeText(),{
        parse_mode:'HTML',
        ...menu(ctx)
      });
    }
  }catch(e){
    console.error('store photo:',e.message);
    try{
      m=await rawTelegramSendMessage(ctx.chat.id,homeText(),{
        parse_mode:'HTML',
        ...menu(ctx)
      });
    }catch{}
  }
  if(m?.message_id){
    // Batalkan timer global yang mungkin sudah dibuat oleh wrapper.
    protectMessage(ctx.chat?.id,m.message_id);
  }
  return m;
}
function prettyCategory(c){return ppobLayout.LABELS[c]||c}
function normalizeSearch(s){return String(s||'').toLowerCase().normalize('NFKD').replace(/[^a-z0-9\s]/g,' ').replace(/\s+/g,' ').trim()}
function searchProducts(type,q){const needle=normalizeSearch(q);if(!needle)return [];const words=needle.split(' ').filter(Boolean);const all=type==='prepaid'?db.products().list_prepaid:db.products().list_pasca;return all.filter(p=>digi.active(p)).map(p=>{const hay=normalizeSearch([p.product_name,p.brand,p.category,p.buyer_sku_code].join(' '));const score=words.reduce((n,w)=>n+(hay.includes(w)?1:0),0);return {p,score}}).filter(x=>x.score===words.length).sort((a,b)=>b.score-a.score||String(a.p.product_name||'').length-String(b.p.product_name||'').length||Number(a.p.price||0)-Number(b.p.price||0)).slice(0,20).map(x=>x.p)}
async function showSearch(ctx,type='prepaid'){if(ctx.callbackQuery)await deleteMessage(ctx.chat?.id,ctx.callbackQuery.message?.message_id);const m=await ctx.reply(`🔎 <b>CARI PRODUK</b>\n\nKetik nama produk, operator, atau kata kunci.\nContoh: <code>xl 10gb</code> atau <code>telkomsel</code>\n\nKetik /batal untuk membatalkan.`,{parse_mode:'HTML',...Markup.inlineKeyboard([[btn('🏠 Menu Utama VPN','vpn_home')]])});sessions.set(String(ctx.from.id),{type:'search',productType:type,promptMessageId:m.message_id});return m}
async function showSearchResults(ctx,type,q){const u=user(ctx),items=searchProducts(type,q);if(!items.length)return tempReply(ctx,`❌ Produk untuk <b>${esc(q)}</b> tidak ditemukan.\n\nCoba kata kunci yang lebih singkat, misalnya <code>xl</code>, <code>10gb</code>, atau <code>mobile legend</code>.`,{parse_mode:'HTML'},9000);let text=`<b>🔎 HASIL PENCARIAN</b>\n<i>${esc(q)}</i>\n\n`;const rows=[];items.forEach((p,i)=>{text+=`<blockquote><b>${i+1}. ${esc(p.product_name)}</b>\n🏷️ ${esc(p.brand||prettyCategory(p.category))}\n💰 <b>${rp(price(p,type,u.role))}</b></blockquote>\n`;rows.push(productButton(String(i+1),`prod:${type}:${encodeURIComponent(p.buyer_sku_code)}`,p.category))});const kb=[];for(let i=0;i<rows.length;i+=5)kb.push(rows.slice(i,i+5));kb.push([btn('🔎 Cari Lagi',`search:${type}`),btn('🛒 PPOB','ppob')]);return ctx.reply(text,{parse_mode:'HTML',...Markup.inlineKeyboard(kb)})}
async function showPopular(ctx,type='prepaid'){const u=user(ctx),all=type==='prepaid'?db.products().list_prepaid:db.products().list_pasca,txs=db.txs().filter(x=>x.purpose==='ppob'&&['SUCCESS','SUKSES'].includes(String(x.status).toUpperCase()));const count=new Map();txs.forEach(x=>count.set(String(x.sku),(count.get(String(x.sku))||0)+1));let items=all.filter(p=>digi.active(p)).sort((a,b)=>(count.get(String(b.buyer_sku_code))||0)-(count.get(String(a.buyer_sku_code))||0)).slice(0,8);if(!items.length)return tempReply(ctx,'❌ Produk belum tersedia.');let text='<b>🔥 PRODUK POPULER</b>\n\n';const rows=[];items.forEach((p,i)=>{text+=`<blockquote><b>${i+1}. ${esc(p.product_name)}</b>\n💰 <b>${rp(price(p,type,u.role))}</b></blockquote>\n`;rows.push(productButton(String(i+1),`prod:${type}:${encodeURIComponent(p.buyer_sku_code)}`,p.category))});const kb=[];for(let i=0;i<rows.length;i+=4)kb.push(rows.slice(i,i+4));kb.push([btn('🛒 PPOB','ppob'),btn('🏠 Menu Utama VPN','vpn_home')]);return safeEdit(ctx,text,Markup.inlineKeyboard(kb))}
function findCategoryEntry(rows,key){const wanted=String(key||'').trim().toLowerCase();const aliases={games:['games','game'],data:['data'],pulsa:['pulsa'],'masa aktif':['masa aktif'],'e-money':['e-money','emoney'],'pln':['pln'],'paket sms & telpon':['paket sms & telpon','sms & telpon']};const candidates=aliases[wanted]||[wanted];return rows.find(([c])=>candidates.includes(String(c||'').trim().toLowerCase()))||null}
async function showCats(ctx,type='prepaid'){const rows=digi.cats(type);if(!rows.length)return safeEdit(ctx,`❌ Produk ${type==='prepaid'?'prabayar':'pascabayar'} belum tersedia.\n\nAdmin: lakukan /syncproduk`,nav([btn('🔄 Sync','sync')]));const u=user(ctx),totalTx=db.txs().filter(x=>String(x.userId)===String(u.id)).length,b=[];for(const row of (ppobLayout.CATEGORY_LAYOUT||[])){const line=row.map(key=>{const hit=findCategoryEntry(rows,key);if(!hit)return null;const c=hit[0];return btn(ppobLayout.LABELS[c]||ppobLayout.LABELS[key]||c,`cat:${type}:${encodeURIComponent(c)}`,productCategoryStyle(c))}).filter(Boolean);if(line.length)b.push(line)}const bottom=ppobLayout.BOTTOM_LAYOUT||[['SEARCH'],['POPULAR'],['HOME']];for(const row of bottom){const buttons=[];for(const item of row){if(item==='SEARCH')buttons.push(btn('CARI PRODUK',`search:${type}`));else if(item==='POPULAR')buttons.push(btn('POPULER',`popular:${type}`));else if(item==='HOME')buttons.push(btn('MENU UTAMA','home'));}if(buttons.length)b.push(buttons)}const text=`<b>🛒 PPOB RIPZZSTORE</b>\n\n<i>Belanja kebutuhan digital otomatis — cepat, aman & 24 jam.</i>\n\n👤 Role: <b>${roleLabel(u.role)}</b>\n💰 Saldo: <b>${rp(u.balance)}</b>\n📊 Total transaksi: <b>${totalTx}</b>\n\n⚡ Harga mengikuti role kamu.\n💳 Bayar dengan saldo atau QRIS otomatis.\n\n<b>Pilih kategori layanan:</b>`;return safeEdit(ctx,text,Markup.inlineKeyboard(b))}
async function showBrands(ctx,type,cat){const rows=digi.brands(type,cat);if(!rows.length)return safeEdit(ctx,'❌ Brand tidak ditemukan.',nav([btn('⬅️ Kategori','ppob')]));const b=[];for(let i=0;i<rows.length;i+=2)b.push(rows.slice(i,i+2).map(([x])=>btn(x,`brand:${type}:${encodeURIComponent(cat)}:${encodeURIComponent(x)}`,productCategoryStyle(cat))));b.push([btn('🔎 Cari Produk',`search:${type}`)]);b.push([btn('⬅️ Kategori',`type:${type}`),btn('🏠 Menu Utama VPN','vpn_home')]);return safeEdit(ctx,`<b>🏷️ ${esc(ppobLayout.LABELS[cat]||cat)}</b>\n\nPilih provider:`,Markup.inlineKeyboard(b))}
async function showProducts(ctx,type,cat,brand,page=0){const all=digi.list(type,cat,brand),size=config.pageSize,start=page*size,items=all.slice(start,start+size);if(!items.length)return safeEdit(ctx,'❌ Produk tidak ditemukan.',nav([btn('⬅️ Brand',`cat:${type}:${encodeURIComponent(cat)}`)]));const u=user(ctx);let text=`<b>📦 ${esc(cat)} — ${esc(brand)}</b>\n<i>Halaman ${page+1}/${Math.max(1,Math.ceil(all.length/size))}</i>\n\n`;const b=[];items.forEach((p,i)=>{const no=i+1,pr=price(p,type,u.role);text+=`<blockquote><b>${no}. ✓ ${esc(p.product_name)}</b>\nHarga : <b>${rp(pr)}</b></blockquote>\n`;b.push(productButton(String(no),`prod:${type}:${encodeURIComponent(p.buyer_sku_code)}`,p.category))});const buttons=[];for(let i=0;i<b.length;i+=5)buttons.push(b.slice(i,i+5));const navb=[];if(page>0)navb.push(btn('⬅️ Prev','page:'+type+':'+encodeURIComponent(cat)+':'+encodeURIComponent(brand)+':'+(page-1)));if(start+size<all.length)navb.push(btn('Next ➡️','page:'+type+':'+encodeURIComponent(cat)+':'+encodeURIComponent(brand)+':'+(page+1)));if(navb.length)buttons.push(navb);buttons.push([btn('⬅️ Brand',`cat:${type}:${encodeURIComponent(cat)}`),btn('🏠 Menu Utama VPN','vpn_home')]);return safeEdit(ctx,text,Markup.inlineKeyboard(buttons))}
function productPhotoKey(category){const c=normalizeSearch(category);if(/data|kuota|internet/.test(c))return 'kuota';if(/game/.test(c))return 'game';if(/pulsa/.test(c))return 'pulsa';if(/masa aktif/.test(c))return 'masaktif';if(/pln|listrik/.test(c))return 'pln';if(/e money|emoney|uang elektronik/.test(c))return 'emoney';if(/voucher/.test(c))return 'voucher';if(/perdana|aktivasi perdana/.test(c))return 'perdana';if(/sms|telp|telepon/.test(c))return 'sms-telp';if(/tv/.test(c))return 'tv';if(/gas/.test(c))return 'gas';return 'default'}
function productPhotoPath(category){return path.join(__dirname,'assets','products',productPhotoKey(category)+'.jpg')}
async function showProduct(ctx,type,sku){const p=digi.find(sku,type);if(!p)return safeEdit(ctx,'❌ Produk tidak ditemukan.',nav());const u=user(ctx),pr=price(p,type,u.role),text=`<b>🛍️ DETAIL PRODUK</b>\n\n<b>${esc(p.product_name)}</b>\n\n🏷️ Kategori: <b>${esc(prettyCategory(p.category))}</b>\n🏪 Provider: <b>RIPZZSTORE</b>\n💰 Harga: <b>${rp(pr)}</b>\n📊 Status: ${p.buyer_product_status?'🟢 Tersedia':'🔴 Tidak tersedia'}\n\n${specText(p)}\n\nTekan <b>BELI SEKARANG</b> untuk melanjutkan.`;const kb=Markup.inlineKeyboard([[btn('🛒 BELI SEKARANG',`buy:${type}:${encodeURIComponent(sku)}`)],[btn('⬅️ Produk',`backprod:${type}:${encodeURIComponent(p.category)}:${encodeURIComponent(p.brand)}:0`),btn('🏠 Menu Utama VPN','vpn_home')]]);if(ctx.callbackQuery?.message?.message_id)await deleteMessage(ctx.chat?.id,ctx.callbackQuery.message.message_id);const photo=productPhotoPath(p.category);if(fs.existsSync(photo)){try{return await ctx.replyWithPhoto({source:photo},{caption:text,parse_mode:'HTML',...kb})}catch(e){console.error('product photo:',e.message)}}return ctx.reply(text,{parse_mode:'HTML',...kb})}
function makeTx(ctx,extra){return {id:idgen(),userId:String(ctx.from.id),userName:ctx.from.username?`@${ctx.from.username}`:(ctx.from.first_name||'User'),chatId:ctx.chat.id,...extra}}
async function createQR(ctx,tx){
  if(ctx.callbackQuery?.message?.message_id)await deleteMessage(ctx.chat?.id,ctx.callbackQuery.message.message_id);
  const q=await payment.create(tx.amount,tx.id);
  const paymentId=q.depositId||q.id||q.paymentId;
  if(!paymentId)throw new Error('Provider QRIS tidak mengembalikan depositId');
  tx.paymentId=paymentId;
  tx.qrImage=q.qrImage||q.qr_url||q.qrUrl||q.image||null;
  tx.qrData=q;
  tx.expiresAt=q.expiredAt?new Date(q.expiredAt).getTime():Date.now()+5*60*1000;
  db.updateTx(tx.id,tx);
  const cap=`<b>💳 PEMBAYARAN QRIS</b>\n\nOrder: <code>${tx.id}</code>\n${tx.productName?`Produk: <b>${esc(tx.productName)}</b>\n`:''}${tx.customerNo?`Tujuan: <code>${esc(tx.customerNo)}</code>\n`:''}Nominal: <b>${rp(tx.amount)}</b>\nTotal QRIS: <b>${rp(q.totalAmount||q.amount||tx.amount)}</b>\nKode unik: <b>${rp(q.uniqueCode||0)}</b>\n\n⏳ Berlaku 5 menit. QR otomatis dihapus setelah lunas atau kedaluwarsa.`;
  const kb=Markup.inlineKeyboard([[btn('🔄 Cek Pembayaran',`paycheck:${tx.id}`)],[btn('❌ Batalkan',`cancel:${tx.id}`)]]);
  let m=null;
  // QRIS juga permanen selama transaksi masih WAITING_PAYMENT.
  // Penghapusan hanya dilakukan oleh removeQr() saat PAID/CANCELLED/EXPIRED.
  ctx.__keepNextReply=true;
  if(tx.qrImage){
    try{
      const photo=/^data:image\/[^;]+;base64,/i.test(String(tx.qrImage))
        ? {source:Buffer.from(String(tx.qrImage).split(',')[1],'base64')}
        : tx.qrImage;
      m=await ctx.replyWithPhoto(photo,{caption:cap,parse_mode:'HTML',...kb})
    }catch(e){console.error('qr photo',e.message)}
  }
  if(!m){
    ctx.__keepNextReply=true;
    m=await ctx.reply(cap,{parse_mode:'HTML',...kb});
  }
  tx.qrMessageId=m.message_id;
  db.updateTx(tx.id,{qrMessageId:m.message_id});
  protectMessage(tx.chatId,m.message_id);
  return m;
}
async function removeQr(tx){
  if(tx?.qrMessageId){
    unprotectMessage(tx.chatId,tx.qrMessageId);
    await deleteMessage(tx.chatId,tx.qrMessageId);
  }
}
async function startBuy(ctx,type,sku){const p=digi.find(sku,type);if(!p||!digi.active(p))return tempReply(ctx,'❌ Produk tidak aktif.');const u=user(ctx),pr=price(p,type,u.role);if(ctx.callbackQuery)await deleteMessage(ctx.chat?.id,ctx.callbackQuery.message?.message_id);const s=digi.destinationSpec(p.category,p.brand);const prompt=await ctx.reply(`🛒 <b>${esc(p.product_name)}</b>\n\n💰 Harga: <b>${rp(pr)}</b>\n\nKirim <b>${esc(s.label)}</b>.\nContoh: <code>${esc(s.placeholder)}</code>\n\nKetik /batal untuk membatalkan.`,{parse_mode:'HTML'});sessions.set(String(ctx.from.id),{type,sku,step:'destination',promptMessageId:prompt.message_id});return prompt}
async function showBuyConfirm(ctx,s,customerNo){const p=digi.find(s.sku,s.type);if(!p||!digi.active(p))return tempReply(ctx,'❌ Produk sudah tidak tersedia.');const u=user(ctx),pr=price(p,s.type,u.role);sessions.set(String(ctx.from.id),{type:s.type,sku:s.sku,step:'confirm',customerNo});return ctx.reply(`<b>⚠️ KONFIRMASI PEMBELIAN</b>\n\n📦 Produk: <b>${esc(p.product_name)}</b>\n📱 Tujuan: <code>${esc(customerNo)}</code>\n💰 Harga: <b>${rp(pr)}</b>\n💳 Saldo: <b>${rp(u.balance)}</b>\n\nPastikan produk dan tujuan sudah benar sebelum melanjutkan.`,{parse_mode:'HTML',...Markup.inlineKeyboard([[btn('✅ KONFIRMASI',`confirmbuy:${s.type}:${encodeURIComponent(s.sku)}`),btn('❌ BATAL','cancelbuy')]])})}
async function startLoading(chatId,text,txId){const frames=['⏳','⌛','⏳','⌛'];const m=await bot.telegram.sendMessage(chatId,`⏳ <b>${esc(text)}</b>`,{parse_mode:'HTML'});let i=0;const state={chatId,messageId:m.message_id,interval:null};state.interval=setInterval(async()=>{i=(i+1)%frames.length;try{await bot.telegram.editMessageText(chatId,m.message_id,undefined,`${frames[i]} <b>${esc(text)}</b>`,{parse_mode:'HTML'})}catch{}},650);if(txId)loading.set(txId,state);return state}
async function stopLoading(txId){const s=loading.get(txId);if(!s)return;clearInterval(s.interval);await deleteMessage(s.chatId,s.messageId);loading.delete(txId)}
async function ensureLoading(tx,text){if(loading.has(tx.id))return loading.get(tx.id);return startLoading(tx.chatId,text,tx.id)}
async function submitOrder(ctx,s,val){const p=digi.find(s.sku,s.type);if(!p||!digi.active(p))return tempReply(ctx,'❌ Produk sudah tidak aktif.');const u=user(ctx),pr=price(p,s.type,u.role),tx=makeTx(ctx,{purpose:'ppob',type:s.type,sku:p.buyer_sku_code,customerNo:val,productName:p.product_name,category:p.category,brand:p.brand,amount:pr,role:u.role,status:'WAITING_PAYMENT',paymentMethod:'QRIS'});db.addTx(tx);sessions.delete(String(ctx.from.id));if(Number(u.balance)>=pr){if(!db.deductBalance(u.id,pr))return tempReply(ctx,'❌ Saldo berubah dan tidak mencukupi.');db.updateTx(tx.id,{status:'PAID',paymentMethod:'SALDO',paidAt:Date.now()});return processProduct(tx)}try{return await createQR(ctx,tx)}catch(e){db.updateTx(tx.id,{status:'ERROR',error:e.message});return tempReply(ctx,'❌ Gagal membuat pembayaran: '+esc(e.message),{parse_mode:'HTML'})}}
async function processProduct(tx){const lock=`trx:${tx.id}`;if(locks.has(lock))return;locks.add(lock);let spinner=null;try{const fresh=db.getTx(tx.id);if(!fresh||['SUCCESS','REFUNDED','FAILED'].includes(fresh.status))return;spinner=await ensureLoading(fresh,'Memproses pesanan');db.updateTx(fresh.id,{status:'PROCESSING'});const r=await digi.transaction({sku:fresh.sku,customerNo:fresh.customerNo,refId:fresh.id,type:fresh.type});const status=String(r?.status||'PENDING').trim().toUpperCase();db.updateTx(fresh.id,{digiflazz:r,status:['PENDING','PROCESSING'].includes(status)?'PENDING':status,submittedAt:fresh.submittedAt||Date.now(),lastPollAt:Date.now(),sn:r?.sn||fresh.sn||''});if(['SUKSES','SUCCESS'].includes(status)){await stopLoading(fresh.id);await finishSuccess(db.getTx(fresh.id));spinner=null}else if(['GAGAL','FAILED','FAILURE','ERROR','REJECTED'].includes(status)){await stopLoading(fresh.id);await refundFailed(db.getTx(fresh.id),r?.message||r?.rc||'Transaksi ditolak/gagal oleh Digiflazz');spinner=null}else { /* status belum final: lanjutkan pemeriksaan dengan ref_id yang sama */ }}catch(e){console.error('processProduct',tx.id,e.message);await stopLoading(tx.id);db.updateTx(tx.id,{status:'PROCESSING',error:e.message,lastPollError:e.message,lastPollAt:Date.now(),retryRequired:true});await tempSend(tx.chatId,'⚠️ Supplier belum memberikan kepastian transaksi. Sistem akan memeriksa ulang otomatis. Saldo belum dianggap hangus. Order ID: '+tx.id)}finally{locks.delete(lock)}}
async function finishSuccess(tx){const r=tx.digiflazz||{};db.updateTx(tx.id,{status:'SUCCESS',completedAt:Date.now(),sn:r.sn||tx.sn||''});const text=`<b>🎉 PEMBELIAN BERHASIL</b>\n\n<b>🧾 Detail Pesanan</b>\n├ Order : <code>${tx.id}</code>\n├ Produk : <b>${esc(tx.productName)}</b>\n├ Tujuan : <code>${esc(tx.customerNo)}</code>\n├ Harga : <b>${rp(tx.amount)}</b>\n└ Status : <b>BERHASIL ✅</b>\n\n<b>🔐 Serial Number</b>\n<code>${esc(r.sn||'-')}</code>${r.message?`\n\n💬 ${esc(r.message)}`:''}\n\nTerima kasih telah berbelanja di <b>RIPZZ STORE</b> 💜`;await sendPersistent(tx.chatId,text,{parse_mode:'HTML'});await notify(
`<b>╭━━━ 🧾 RIPZZ STORE ━━━╮</b>
<b>┃ ✅ TRANSAKSI BERHASIL</b>
<b>╰━━━━━━━━━━━━━━━━━━━━╯</b>

<b>📦 Produk</b> : ${esc(tx.productName)}
<b>📱 Tujuan</b> : <code>${esc(tx.customerNo)}</code>
<b>💰 Nominal</b> : <b>${rp(tx.amount)}</b>
<b>👤 User</b> : ${esc(tx.userName)}
<b>🆔 Order ID</b> : <code>${esc(tx.id)}</code>
<b>📌 Status</b> : <b>SUCCESS</b>
<b>🔐 SN</b> : <code>${esc(r.sn||'-')}</code>

<i>Terima kasih telah menggunakan layanan RIPZZ STORE.</i>`)}
async function refundFailed(tx,msg){if(!tx)return;const result=db.refundTx(tx.id,msg||'Transaksi gagal');if(!result)return;const t=db.getTx(tx.id);if(!t||t.status==='SUCCESS')return;await sendPersistent(t.chatId,`<b>⚠️ TRANSAKSI GAGAL</b>\n\nOrder: <code>${t.id}</code>\nProduk: <b>${esc(t.productName)}</b>\nPesan: ${esc(msg||'-')}\n\n${t.refunded?`Dana sebesar <b>${rp(t.refundAmount||t.amount)}</b> telah dikembalikan sepenuhnya ke saldo PPOB kamu. Saldo sekarang: <b>${rp(t.refundBalance)}</b>`:'Transaksi gagal.'}`,{parse_mode:'HTML'}).catch(()=>{});await notify(
`<b>╭━━━ 🧾 RIPZZ STORE ━━━╮</b>
<b>┃ ❌ TRANSAKSI GAGAL</b>
<b>╰━━━━━━━━━━━━━━━━━━━━╯</b>

<b>📦 Produk</b> : ${esc(t.productName)}
<b>📱 Tujuan</b> : <code>${esc(t.customerNo||'-')}</code>
<b>💰 Nominal</b> : <b>${rp(t.amount)}</b>
<b>👤 User</b> : ${esc(t.userName)}
<b>🆔 Order ID</b> : <code>${esc(t.id)}</code>
<b>📌 Status</b> : <b>GAGAL</b>

<i>Silakan hubungi admin jika diperlukan.</i>`)}
async function checkPayment(tx){if(!tx||tx.status!=='WAITING_PAYMENT'||!tx.paymentId)return false;try{const r=await payment.status(tx.paymentId);if(payment.paid(r)){await removeQr(tx);if(tx.purpose==='saldotopup'){db.updateTx(tx.id,{paidAt:Date.now(),paymentData:r});const credited=db.completeTopup(tx.id);if(!credited)return false;const bal=credited.balance;await sendPersistent(tx.chatId,`<b>✅ DEPOSIT BERHASIL</b>\n\nNominal: <b>${rp(tx.amount)}</b>\nSaldo sekarang: <b>${rp(bal)}</b>`,{parse_mode:'HTML'});await notify(
`<b>╭──────────────╮</b>
<b>   💳 TOP UP BERHASIL 💳</b>
<b>╰──────────────╯</b>

📒 No Trx       : <code>#${esc(String(tx.id).slice(-6))}</code>
🌀 Status       : Pembayaran Lunas ✅
👤 Username     : ${esc(tx.userName || '-')}
🆔 ID           : <code>${esc(tx.userId)}</code>

💳 Payment      : Outletku GoPay QRIS
💵 Nominal      : <b>${rp(tx.amount)}</b>
🎁 Bonus        : <b>Rp0</b>
💰 Saldo Masuk  : <b>${rp(tx.amount)}</b>
💳 Saldo Now    : <b>${rp(bal)}</b>

📅 Tanggal      : ${new Date().toLocaleDateString('id-ID',{timeZone:config.tz}).replace(/\//g,'.')}
⏰ Waktu        : ${new Date().toLocaleTimeString('id-ID',{timeZone:config.tz,hour:'2-digit',minute:'2-digit',hour12:false})} WIB

━━━━━━━━━━━━━━
📝 Catatan: Simpan nomor transaksi untuk support
━━━━━━━━━━━━━━`);return true}db.updateTx(tx.id,{status:'PAID',paidAt:Date.now(),paymentData:r});if(tx.purpose==='role_upgrade'){const u=db.getUser(tx.userId);db.setUser(tx.userId,{role:tx.targetRole});db.updateTx(tx.id,{status:'SUCCESS',completedAt:Date.now()});await sendPersistent(tx.chatId,`<b>🎖️ UPGRADE ROLE BERHASIL</b>\n\nRole lama: ${roleLabel(u.role)}\nRole baru: ${roleLabel(tx.targetRole)}\nBiaya: <b>${rp(tx.amount)}</b>`,{parse_mode:'HTML'},15000);return true}await processProduct(db.getTx(tx.id));return true}return false}catch(e){console.error('payment check',tx.id,e.message);return false}}
async function paymentLoop(){for(const tx of db.pendingPayments()){if(tx.expiresAt&&Date.now()>tx.expiresAt){await checkPayment(tx);const latest=db.getTx(tx.id);if(latest&&latest.status!=='WAITING_PAYMENT')continue;await removeQr(tx);db.updateTx(tx.id,{status:'EXPIRED'});await tempSend(tx.chatId,`⏰ Pembayaran QRIS <code>${tx.id}</code> telah kedaluwarsa.`,{parse_mode:'HTML'});continue}await checkPayment(tx)}}
async function trxLoop(){for(const tx of db.pendingProducts()){if(['GAGAL','FAILED','FAILURE','ERROR','REJECTED'].includes(String(tx.status||'').toUpperCase())){await refundFailed(tx,tx.digiflazz?.message||tx.failureMessage||'Transaksi dinyatakan gagal oleh Digiflazz');continue;}if(tx.status==='PAID'){await processProduct(tx);continue;}if(['PROCESSING','PROCESSING_ERROR','PENDING'].includes(tx.status)){const lock=`trx:${tx.id}`;if(locks.has(lock))continue;locks.add(lock);const polls=Number(tx.polls||0);try{const latest=db.getTx(tx.id);if(!latest||['SUCCESS','REFUNDED','FAILED'].includes(latest.status))continue;const r=await digi.transaction({sku:tx.sku,customerNo:tx.customerNo,refId:tx.id,type:tx.type});const st=String(r?.status||'PENDING').trim().toUpperCase();db.updateTx(tx.id,{digiflazz:r,status:['PENDING','PROCESSING'].includes(st)?'PENDING':st,polls:polls+1,lastPollAt:Date.now(),lastPollError:'',sn:r?.sn||tx.sn||''});if(['SUKSES','SUCCESS'].includes(st)){await stopLoading(tx.id);await finishSuccess(db.getTx(tx.id));}else if(['GAGAL','FAILED','FAILURE','ERROR','REJECTED'].includes(st)){await stopLoading(tx.id);await refundFailed(db.getTx(tx.id),r?.message||r?.rc||'Transaksi ditolak/gagal oleh Digiflazz');}else if(polls+1>=config.trxMaxPolls&&!tx.timeoutNotified){db.updateTx(tx.id,{timeoutNotified:true});await stopLoading(tx.id);await sendPersistent(tx.chatId,`⚠️ <b>TRANSAKSI MASIH DIPERIKSA</b>\n\nOrder: <code>${tx.id}</code>\nSupplier belum memberikan status akhir. Sistem tetap memeriksa otomatis. Saldo tidak akan dianggap hangus dan akan dikembalikan penuh jika supplier menyatakan GAGAL.`,{parse_mode:'HTML'});}}catch(e){console.error('trx poll',tx.id,e.message);db.updateTx(tx.id,{status:'PROCESSING',polls:polls+1,lastPollError:e.message,lastPollAt:Date.now()});}finally{locks.delete(lock);}}}}
function adminMenu(){return Markup.inlineKeyboard([[btn('🗄 Backup PPOB','adm:backup'),btn('♻️ Restore PPOB','adm:restore')],[btn('📣 Broadcast','adm:broadcast'),btn('💰 +Saldo','adm:addsaldo')],[btn('💸 -Saldo','adm:minsaldo'),btn('👥 User','adm:users')],[btn('📊 Statistik','adm:stats'),btn('📋 Log','adm:log')],[btn('🔄 Sync Produk','adm:sync'),btn('💳 Saldo Supplier','adm:digisaldo')],[btn('🛠 ADMIN VPN','vpn_admin')],[btn('⬅️ MENU UTAMA VPN','vpn_home')]])}
function adminGuard(ctx){if(!admin(ctx)){tempReply(ctx,'❌ Menu ini khusus admin.');return false}return true}
function dataFiles(){const dir=path.dirname(db.files.users);return ['users.json','transactions.json','digiflazz-cache.json','settings.json'].map(x=>path.join(dir,x))}
function makeBackup(){
  const out=path.join(os.tmpdir(),`ripzz-ppob-backup-${Date.now()}.tar.gz`);
  const files=dataFiles().filter(x=>fs.existsSync(x)&&fs.statSync(x).isFile()).map(x=>path.basename(x));
  if(!files.includes('users.json')||!files.includes('transactions.json'))throw new Error('Data utama PPOB users.json/transactions.json tidak ditemukan.');
  execFileSync('tar',['-czf',out,'-C',path.dirname(dataFiles()[0]),'--',...files],{stdio:'ignore'});
  return out;
}
async function restoreBackupFromTelegram(ctx){
  const doc=ctx.message.document;
  if(!doc)return false;
  if(!/\\.tar\\.gz$|\\.tgz$/i.test(doc.file_name||'')){await tempReply(ctx,'❌ File restore harus .tar.gz atau .tgz.');return true}
  const tmp=path.join(os.tmpdir(),`ripzz-restore-${Date.now()}.tar.gz`);
  const stage=fs.mkdtempSync(path.join(os.tmpdir(),'ripzz-ppob-stage-'));
  const allowed=new Set(['users.json','transactions.json','digiflazz-cache.json','settings.json']);
  try{
    const link=await ctx.telegram.getFileLink(doc.file_id);
    const res=await axios.get(String(link),{responseType:'arraybuffer',timeout:60000});
    fs.writeFileSync(tmp,res.data);
    const listing=execFileSync('tar',['-tzf',tmp],{encoding:'utf8'}).split(/\\r?\\n/).filter(Boolean);
    if(!listing.length||listing.some(x=>x.includes('/')||!allowed.has(x.trim()))||
       !listing.includes('users.json')||!listing.includes('transactions.json'))throw new Error('Arsip bukan backup PPOB yang valid.');
    execFileSync('tar',['-xzf',tmp,'-C',stage,'--no-same-owner'],{stdio:'ignore'});
    for(const name of listing){
      const f=path.join(stage,name),st=fs.lstatSync(f);
      if(!st.isFile()||st.isSymbolicLink())throw new Error('Isi arsip PPOB tidak valid.');
      const parsed=JSON.parse(fs.readFileSync(f,'utf8'));
      if(!parsed||typeof parsed!=='object')throw new Error(`Format ${name} tidak valid.`);
    }
    const dir=path.dirname(db.files.users),previous=new Map();
    for(const name of listing){const dest=path.join(dir,name);previous.set(name,fs.existsSync(dest)?fs.readFileSync(dest):null)}
    try{
      for(const name of listing){const dest=path.join(dir,name),tmpDest=`${dest}.restore.tmp`;fs.copyFileSync(path.join(stage,name),tmpDest);fs.renameSync(tmpDest,dest)}
    }catch(e){
      for(const [name,data] of previous){const dest=path.join(dir,name);try{if(data===null)fs.rmSync(dest,{force:true});else fs.writeFileSync(dest,data)}catch{}}
      throw e;
    }
    await tempReply(ctx,'✅ <b>RESTORE PPOB BERHASIL</b>\\nData user PPOB, transaksi, cache produk, dan settings yang ada di arsip telah dipulihkan. Data VPN tidak diubah.',{parse_mode:'HTML'});
    return true;
  }catch(e){
    await tempReply(ctx,'❌ Restore PPOB gagal: '+esc(e.message),{parse_mode:'HTML'});
    return true;
  }finally{try{fs.unlinkSync(tmp)}catch{};try{fs.rmSync(stage,{recursive:true,force:true})}catch{}}
}
async function adminPanel(ctx,edit=false){const text=`<b>🛠 ADMIN RIPZZSTORE</b>\n\nPilih fungsi administrasi:`;return edit?safeEdit(ctx,text,adminMenu()):ctx.reply(text,{parse_mode:'HTML',...adminMenu()})}
async function adminUsers(ctx){const us=db.users(),arr=Object.values(us);if(!arr.length)return tempReply(ctx,'👥 Belum ada user.');arr.sort((a,b)=>Number(b.updatedAt||0)-Number(a.updatedAt||0));let text=`<b>👥 DATA USER</b>\nTotal: <b>${arr.length}</b>\n\n`;arr.slice(0,30).forEach((u,i)=>{text+=`${i+1}. <code>${esc(u.id)}</code> ${esc(u.name||'User')}\n   ${roleLabel(u.role)} • ${rp(u.balance)}\n\n`});if(arr.length>30)text+='<i>Menampilkan 30 user terbaru.</i>';return ctx.reply(text,{parse_mode:'HTML',...Markup.inlineKeyboard([[btn('⬅️ Admin','admin')]])})}
async function adminStats(ctx){const us=Object.values(db.users()),tx=db.txs(),success=tx.filter(x=>x.status==='SUCCESS'),pending=tx.filter(x=>['WAITING_PAYMENT','PAID','PROCESSING','PENDING'].includes(x.status)),omzet=success.filter(x=>x.purpose==='ppob').reduce((n,x)=>n+Number(x.amount||0),0);return ctx.reply(`<b>📊 STATISTIK</b>\n\n👥 User: <b>${us.length}</b>\n📦 Transaksi: <b>${tx.length}</b>\n✅ Sukses: <b>${success.length}</b>\n⏳ Pending: <b>${pending.length}</b>\n💰 Omzet PPOB: <b>${rp(omzet)}</b>`,{parse_mode:'HTML',...Markup.inlineKeyboard([[btn('⬅️ Admin','admin')]])})}
async function adminLog(ctx){const tx=db.txs().slice(0,20);if(!tx.length)return tempReply(ctx,'📋 Log transaksi kosong.');let text='<b>📋 LOG TRANSAKSI</b>\n\n';tx.forEach(x=>{text+=`<code>${esc(x.id)}</code> • ${esc(x.productName||x.purpose||'-')}\n${rp(x.amount)} • <b>${esc(x.status||'-')}</b>\n\n`});return ctx.reply(text,{parse_mode:'HTML',...Markup.inlineKeyboard([[btn('⬅️ Admin','admin')]])})}
async function broadcast(ctx,text){const us=Object.values(db.users());let ok=0,fail=0;for(const u of us){if(!u.id)continue;try{await rawTelegramSendMessage(String(u.id),text,{parse_mode:'HTML'});ok++}catch{try{await rawTelegramSendMessage(String(u.id),text);ok++}catch{fail++}}await new Promise(r=>setTimeout(r,40))}return {total:us.length,ok,fail}}
async function roleMenu(ctx){const u=user(ctx);let text=`<b>🎖️ ROLE PPOB</b>\n\nRole: ${roleLabel(u.role)}\n\n🥉 Bronze: +${config.roles.margin.bronze}%\n🥈 Silver: +${config.roles.margin.silver}%\n🥇 Gold: +${config.roles.margin.gold}%`;const b=[];if(u.role==='bronze'&&config.roles.price.silver>0)b.push([btn(`🥈 Silver · ${rp(config.roles.price.silver)}`,'buyrole:silver')]);if(['bronze','silver'].includes(u.role)&&config.roles.price.gold>0)b.push([btn(`🥇 Gold · ${rp(config.roles.price.gold)}`,'buyrole:gold')]);b.push([btn('🏠 Menu Utama VPN','vpn_home')]);return safeEdit(ctx,text,Markup.inlineKeyboard(b))}
// ============================================================
// WAJIB GABUNG CHANNEL — hanya diverifikasi sampai user pertama
// kali berhasil bergabung. User yang sudah terverifikasi tidak
// akan diminta bergabung lagi pada interaksi berikutnya.
// ============================================================
function requiredChannelId(){
  return String(config.requiredChannelId||'').trim();
}
function requiredChannelUrl(){
  const id=requiredChannelId();
  if(config.requiredChannelUrl)return String(config.requiredChannelUrl).trim();
  if(/^@[A-Za-z0-9_]{5,}$/.test(id))return `https://t.me/${id.slice(1)}`;
  return '';
}
function channelJoinedFlag(id){
  const d=db.users();
  return Boolean(d[String(id)]?.channelJoinedAt);
}
async function verifyRequiredChannel(ctx){
  if(!config.requiredChannelId||!ctx.from?.id)return true;
  if(admin(ctx))return true;
  if(channelJoinedFlag(ctx.from.id))return true;

  try{
    const member=await bot.telegram.getChatMember(config.requiredChannelId,ctx.from.id);
    const status=String(member?.status||'').toLowerCase();
    const joined=['creator','administrator','member'].includes(status) ||
      (status==='restricted' && member?.is_member===true);

    if(joined){
      db.setUser(String(ctx.from.id),{
        channelJoinedAt:Date.now(),
        channelJoinedId:String(config.requiredChannelId)
      });
      return true;
    }
  }catch(e){
    console.error('channel membership check:',e.message);
    // Jangan memblokir bot bila channel requirement belum dikonfigurasi
    // dengan benar; admin dapat memperbaikinya tanpa mematikan bot.
    if(!config.requiredChannelUrl && !/^@[A-Za-z0-9_]{5,}$/.test(requiredChannelId()))return true;
  }

  const url=requiredChannelUrl();
  const rows=[];
  if(url)rows.push([Markup.button.url('📢 GABUNG CHANNEL',url)]);
  rows.push([btn('🔄 SAYA SUDAH GABUNG','checkjoin')]);
  const m=await ctx.reply(
    '<b>🔒 AKSES TERBATAS</b>\n\nSebelum menggunakan <b>RIPZZ STORE</b>, silakan bergabung terlebih dahulu ke channel resmi kami.\n\nSetelah bergabung, tekan <b>🔄 SAYA SUDAH GABUNG</b>.\n\n<i>Jika kamu sudah pernah diverifikasi, pesan ini tidak akan muncul lagi.</i>',
    {parse_mode:'HTML',...Markup.inlineKeyboard(rows)}
  );
  if(m?.message_id)protectMessage(ctx.chat?.id,m.message_id);
  return false;
}

// AUTO DELETE V11: pesan user dihapus setelah diproses; pesan bot non-hasil dihapus otomatis.
bot.use(async (ctx,next)=>{
  const r=ctx.reply, rp=ctx.replyWithPhoto, rd=ctx.replyWithDocument;
  if(ctx.callbackQuery?.data==='checkjoin'){
    // handled by dedicated action below
  }else if(!(await verifyRequiredChannel(ctx))){
    if(ctx.callbackQuery)await ctx.answerCbQuery('Silakan gabung channel terlebih dahulu.',{show_alert:true}).catch(()=>{});
    return;
  }
  ctx.reply=async(...args)=>{
    const keep=ctx.__keepNextReply===true;
    ctx.__keepNextReply=false;
    const m=await r.apply(ctx,args);
    if(!keep)scheduleDelete(ctx.chat?.id,m?.message_id);
    return m;
  };
  ctx.replyWithPhoto=async(...args)=>{
    const keep=ctx.__keepNextReply===true;
    ctx.__keepNextReply=false;
    const m=await rp.apply(ctx,args);
    if(!keep)scheduleDelete(ctx.chat?.id,m?.message_id);
    return m;
  };
  ctx.replyWithDocument=async(...args)=>{
    const keep=ctx.__keepNextReply===true;
    ctx.__keepNextReply=false;
    const m=await rd.apply(ctx,args);
    if(!keep)scheduleDelete(ctx.chat?.id,m?.message_id);
    return m;
  };
  try{return await next()}finally{if(ctx.message?.message_id)setTimeout(()=>deleteCtxMessage(ctx),AUTO_DELETE_INCOMING_MS)}
});

bot.start(ctx=>sendHome(ctx));
bot.command('menu',ctx=>sendHome(ctx));
bot.command('batal',async ctx=>{await deleteCtxMessage(ctx);const s=sessions.get(String(ctx.from.id));if(s?.promptMessageId)await deleteMessage(ctx.chat.id,s.promptMessageId);sessions.delete(String(ctx.from.id));return tempReply(ctx,'✅ Proses dibatalkan.')});
bot.command('saldo',async ctx=>{await deleteCtxMessage(ctx);const u=user(ctx);return ctx.reply(`<b>💰 SALDO</b>\nSaldo: <b>${rp(u.balance)}</b>\nRole: ${roleLabel(u.role)}`,{parse_mode:'HTML',...Markup.inlineKeyboard([[btn('➕ Deposit','deposit'),btn('🛒 PPOB','ppob')]])})});
bot.command('profile',async ctx=>{await deleteCtxMessage(ctx);const u=user(ctx);return ctx.reply(`<b>👤 PROFIL</b>\nRole: ${roleLabel(u.role)}\nSaldo: <b>${rp(u.balance)}</b>`,{parse_mode:'HTML',...nav()})});
bot.command('ppob',async ctx=>{await deleteCtxMessage(ctx);return ctx.reply('<b>🛒 PPOB RIPZZSTORE</b>\n\nPilih kategori:',{parse_mode:'HTML',...Markup.inlineKeyboard([[btn('🔵 Prabayar','type:prepaid'),btn('🟣 Pascabayar','type:pasca')],[btn('🏠 Menu Utama VPN','vpn_home')]])})});
bot.command('depo',async ctx=>{await deleteCtxMessage(ctx);const a=Number(String(ctx.message.text).split(/\s+/)[1]||0);if(!a||a<1000)return tempReply(ctx,'Format: /depo 10000');const tx=makeTx(ctx,{purpose:'saldotopup',productName:'Deposit Saldo',amount:a,status:'WAITING_PAYMENT',paymentMethod:'QRIS'});db.addTx(tx);try{await createQR(ctx,tx)}catch(e){db.updateTx(tx.id,{status:'ERROR',error:e.message});return tempReply(ctx,'❌ '+esc(e.message),{parse_mode:'HTML'})}});
function historyData(userId){
  return db.txs().filter(x=>String(x.userId)===String(userId));
}
function historyView(ctx,page=0){
  const all=historyData(ctx.from.id);
  const size=5;
  const totalPages=Math.max(1,Math.ceil(all.length/size));
  page=Math.max(0,Math.min(Number(page)||0,totalPages-1));
  const items=all.slice(page*size,page*size+size);
  if(!items.length)return safeEdit(ctx,'📜 <b>RIWAYAT TRANSAKSI</b>\n\nBelum ada transaksi.',Markup.inlineKeyboard([[btn('🏠 Menu Utama VPN','vpn_home')]]));
  let text=`<b>📜 RIWAYAT TRANSAKSI</b>\n<i>Halaman ${page+1}/${totalPages} • ${all.length} transaksi</i>\n\n`;
  const rows=[];
  items.forEach((x,i)=>{
    const no=page*size+i+1;
    const status=String(x.status||'-').toUpperCase();
    const statusIcon=/^(SUCCESS|SUKSES)$/.test(status)?'✅':/^(FAILED|GAGAL|REFUNDED)$/.test(status)?'❌':/^(EXPIRED|TIMEOUT)$/.test(status)?'⏰':'⏳';
    text+=`<blockquote><b>${no}. ${esc(x.productName||x.purpose||'Transaksi')}</b>\n${statusIcon} ${esc(status)} • <b>${rp(x.amount)}</b>\nOrder: <code>${esc(x.id)}</code></blockquote>\n`;
    if(x.purpose==='ppob'&&x.type&&x.sku&&x.customerNo)rows.push([btn(`🔄 Beli Lagi ${no}`,`repeat:${encodeURIComponent(x.id)}`)]);
  });
  const navRow=[];
  if(page>0)navRow.push(btn('⬅️ Sebelumnya',`history:${page-1}`));
  if(page<totalPages-1)navRow.push(btn('Berikutnya ➡️',`history:${page+1}`));
  if(navRow.length)rows.push(navRow);
  rows.push([btn('🛒 PPOB','ppob'),btn('🏠 Menu Utama VPN','vpn_home')]);
  return safeEdit(ctx,text,Markup.inlineKeyboard(rows));
}
bot.command('cek',async ctx=>{await deleteCtxMessage(ctx);const id=String(ctx.message.text).split(/\s+/)[1],t=db.getTx(id);if(!t)return tempReply(ctx,'❌ Transaksi tidak ditemukan.');if(t.userId!==String(ctx.from.id)&&!admin(ctx))return tempReply(ctx,'❌ Tidak punya akses.');return ctx.reply(`<b>🔎 STATUS</b>\n\nOrder: <code>${t.id}</code>\nProduk: ${esc(t.productName)}\nStatus: <b>${esc(t.status)}</b>\nSN: <code>${esc(t.sn||'-')}</code>`,{parse_mode:'HTML'})});
bot.command('admin',async ctx=>{await deleteCtxMessage(ctx);return adminPanel(ctx)});
bot.command('backup',async ctx=>{await deleteCtxMessage(ctx);if(!adminGuard(ctx))return;let f;try{f=makeBackup();return await ctx.replyWithDocument({source:f},{caption:'🗄 <b>BACKUP DATA PPOB SAJA</b>',parse_mode:'HTML'})}catch(e){return tempReply(ctx,'❌ Backup PPOB gagal: '+esc(e.message),{parse_mode:'HTML'})}finally{if(f)try{fs.unlinkSync(f)}catch{}}});
bot.command('restore',async ctx=>{await deleteCtxMessage(ctx);if(!adminGuard(ctx))return;sessions.set(String(ctx.from.id),{type:'admin_restore'});return ctx.reply('♻️ <b>RESTORE DATA</b>\n\nUpload file backup PPOB <code>.tar.gz</code>.',{parse_mode:'HTML'})});
bot.command('broadcast',async ctx=>{await deleteCtxMessage(ctx);if(!adminGuard(ctx))return;sessions.set(String(ctx.from.id),{type:'admin_broadcast'});return ctx.reply('📣 <b>BROADCAST</b>\n\nKirim teks broadcast.',{parse_mode:'HTML'})});
bot.command('listuser',async ctx=>{await deleteCtxMessage(ctx);if(!adminGuard(ctx))return;return adminUsers(ctx)});
bot.command('stats',async ctx=>{await deleteCtxMessage(ctx);if(!adminGuard(ctx))return;return adminStats(ctx)});
bot.command('log',async ctx=>{await deleteCtxMessage(ctx);if(!adminGuard(ctx))return;return adminLog(ctx)});
bot.command('syncproduk',async ctx=>{await deleteCtxMessage(ctx);if(!admin(ctx))return tempReply(ctx,'❌ Khusus admin.');await tempReply(ctx,'⏳ Sinkronisasi produk...',{},5000);try{const p=await digi.sync();return tempReply(ctx,`✅ Sync selesai.\nPrabayar: ${p.list_prepaid.length}\nPascabayar: ${p.list_pasca.length}`)}catch(e){return tempReply(ctx,'❌ '+esc(e.message),{parse_mode:'HTML'})}});
bot.command('digisaldo',async ctx=>{await deleteCtxMessage(ctx);if(!admin(ctx))return tempReply(ctx,'❌ Khusus admin.');try{const x=await digi.balance();return tempReply(ctx,`💳 Saldo supplier: <b>${rp(x?.deposit)}</b>`,{parse_mode:'HTML'})}catch(e){return tempReply(ctx,'❌ '+esc(e.message),{parse_mode:'HTML'})}});
bot.command('addsaldo',async ctx=>{await deleteCtxMessage(ctx);if(!admin(ctx))return tempReply(ctx,'❌ Khusus admin.');const a=String(ctx.message.text).split(/\s+/),n=Number(a[2]);if(!a[1]||!n)return tempReply(ctx,'/addsaldo USER_ID NOMINAL');const b=db.addBalance(a[1],n);return tempReply(ctx,`✅ Saldo user ditambah ${rp(n)}.\nSaldo: ${rp(b)}`)});
bot.command('minsaldo',async ctx=>{await deleteCtxMessage(ctx);if(!admin(ctx))return tempReply(ctx,'❌ Khusus admin.');const a=String(ctx.message.text).split(/\s+/),n=Number(a[2]);if(!a[1]||!n)return tempReply(ctx,'/minsaldo USER_ID NOMINAL');return tempReply(ctx,db.deductBalance(a[1],n)?`✅ Saldo user dikurangi ${rp(n)}.`:'❌ Saldo tidak cukup.')});
bot.command('setrole',async ctx=>{await deleteCtxMessage(ctx);if(!admin(ctx))return tempReply(ctx,'❌ Khusus admin.');const a=String(ctx.message.text).split(/\s+/),r=String(a[2]||'').toLowerCase();if(!a[1]||!['bronze','silver','gold'].includes(r))return tempReply(ctx,'/setrole USER_ID bronze|silver|gold');db.setUser(a[1],{role:r});return tempReply(ctx,`✅ Role user diubah → ${roleLabel(r)}`)});
bot.command('setmargin',async ctx=>{await deleteCtxMessage(ctx);if(!admin(ctx))return tempReply(ctx,'❌ Khusus admin.');const a=String(ctx.message.text).split(/\s+/),r=String(a[1]||'').toLowerCase(),m=Number(a[2]);if(!['bronze','silver','gold'].includes(r)||!Number.isFinite(m)||m<0)return tempReply(ctx,'/setmargin bronze 6');process.env['MARGIN_'+r.toUpperCase()]=String(m);return tempReply(ctx,`✅ Margin ${r} diubah menjadi ${m}% untuk runtime.`)});
bot.action('checkjoin',async c=>{
  const ok=await verifyRequiredChannel({...c, from:c.from, chat:c.chat, callbackQuery:c.callbackQuery});
  if(ok){
    await c.answerCbQuery('✓ Keanggotaan terverifikasi.');
    if(c.callbackQuery?.message?.message_id)await deleteMessage(c.chat?.id,c.callbackQuery.message.message_id);
    return sendHome(c);
  }
  await c.answerCbQuery('Belum terdeteksi bergabung. Silakan gabung lalu coba lagi.',{show_alert:true});
});
bot.action('home',async c=>{await c.answerCbQuery();return sendHome(c)});
bot.action('ppob',async c=>{await c.answerCbQuery();return showCats(c,'prepaid')});
bot.action('saldo',async c=>{await c.answerCbQuery();const u=user(c);return safeEdit(c,`<b>💰 SALDO</b>\n\nSaldo: <b>${rp(u.balance)}</b>\nRole: ${roleLabel(u.role)}`,Markup.inlineKeyboard([[btn('➕ Deposit','deposit')],[btn('🛒 PPOB','ppob'),btn('🏠 Menu Utama VPN','vpn_home')]]))});
bot.action('profile',async c=>{await c.answerCbQuery();const u=user(c);return safeEdit(c,`<b>👤 PROFIL</b>\n\nRole: ${roleLabel(u.role)}\nSaldo: <b>${rp(u.balance)}</b>`,nav())});
bot.action('history',async c=>{await c.answerCbQuery();return historyView(c,0)});
bot.action(/^history:(\d+)$/,async c=>{await c.answerCbQuery();return historyView(c,Number(c.match[1]))});
bot.action('role',async c=>{await c.answerCbQuery();return roleMenu(c)});
bot.action('deposit',async c=>{await c.answerCbQuery();return safeEdit(c,'<b>💳 DEPOSIT SALDO</b>\n\nMasukkan nominal dengan perintah <code>/depo 10000</code>.\nQRIS akan otomatis dihapus setelah lunas atau kedaluwarsa.',nav())});
bot.action('sync',async c=>{await c.answerCbQuery();if(!admin(c))return tempReply(c,'❌ Khusus admin.');try{const p=await digi.sync();return tempReply(c,`✅ Sync selesai. Prabayar ${p.list_prepaid.length}, Pascabayar ${p.list_pasca.length}`)}catch(e){return tempReply(c,'❌ '+esc(e.message),{parse_mode:'HTML'})}});
bot.action('admin',async c=>{await c.answerCbQuery();if(!adminGuard(c))return;return adminPanel(c,true)});
bot.action('adm:backup',async c=>{await c.answerCbQuery();if(!adminGuard(c))return;let f;try{f=makeBackup();return await c.replyWithDocument({source:f},{caption:'🗄 <b>BACKUP DATA PPOB SAJA</b>',parse_mode:'HTML'})}catch(e){return tempReply(c,'❌ Backup PPOB gagal: '+esc(e.message),{parse_mode:'HTML'})}finally{if(f)try{fs.unlinkSync(f)}catch{}}});
bot.action('adm:restore',async c=>{await c.answerCbQuery();if(!adminGuard(c))return;sessions.set(String(c.from.id),{type:'admin_restore'});return c.reply('♻️ <b>RESTORE DATA</b>\n\nUpload file backup <code>.tar.gz</code>.',{parse_mode:'HTML'})});
bot.action('adm:broadcast',async c=>{await c.answerCbQuery();if(!adminGuard(c))return;sessions.set(String(c.from.id),{type:'admin_broadcast'});return c.reply('📣 <b>BROADCAST</b>\n\nKirim teks broadcast.',{parse_mode:'HTML'})});
bot.action('adm:addsaldo',async c=>{await c.answerCbQuery();if(!adminGuard(c))return;sessions.set(String(c.from.id),{type:'admin_addsaldo'});return c.reply('💰 <b>TAMBAH SALDO</b>\n\nKirim: <code>USER_ID NOMINAL</code>',{parse_mode:'HTML'})});
bot.action('adm:minsaldo',async c=>{await c.answerCbQuery();if(!adminGuard(c))return;sessions.set(String(c.from.id),{type:'admin_minsaldo'});return c.reply('💸 <b>KURANGI SALDO</b>\n\nKirim: <code>USER_ID NOMINAL</code>',{parse_mode:'HTML'})});
bot.action('adm:users',async c=>{await c.answerCbQuery();if(!adminGuard(c))return;return adminUsers(c)});bot.action('adm:stats',async c=>{await c.answerCbQuery();if(!adminGuard(c))return;return adminStats(c)});bot.action('adm:log',async c=>{await c.answerCbQuery();if(!adminGuard(c))return;return adminLog(c)});
bot.action('adm:sync',async c=>{await c.answerCbQuery();if(!adminGuard(c))return;try{const p=await digi.sync();return tempReply(c,`✅ Sync selesai.\nPrabayar: ${p.list_prepaid.length}\nPascabayar: ${p.list_pasca.length}`)}catch(e){return tempReply(c,'❌ '+esc(e.message),{parse_mode:'HTML'})}});
bot.action('adm:digisaldo',async c=>{await c.answerCbQuery();if(!adminGuard(c))return;try{const x=await digi.balance();return tempReply(c,`💳 Saldo supplier: <b>${rp(x?.deposit)}</b>`,{parse_mode:'HTML'})}catch(e){return tempReply(c,'❌ '+esc(e.message),{parse_mode:'HTML'})}});
bot.action(/^type:(prepaid|pasca)$/,async c=>{await c.answerCbQuery();return showCats(c,c.match[1])});
bot.action(/^search:(prepaid|pasca)$/,async c=>{await c.answerCbQuery();return showSearch(c,c.match[1])});
bot.action(/^popular:(prepaid|pasca)$/,async c=>{await c.answerCbQuery();return showPopular(c,c.match[1])});
bot.action(/^cat:(prepaid|pasca):(.+)$/,async c=>{await c.answerCbQuery();return showBrands(c,c.match[1],decodeURIComponent(c.match[2]))});
bot.action(/^brand:(prepaid|pasca):(.+):(.+)$/,async c=>{await c.answerCbQuery();return showProducts(c,c.match[1],decodeURIComponent(c.match[2]),decodeURIComponent(c.match[3]),0)});
bot.action(/^page:(prepaid|pasca):(.+):(.+):(\d+)$/,async c=>{await c.answerCbQuery();return showProducts(c,c.match[1],decodeURIComponent(c.match[2]),decodeURIComponent(c.match[3]),Number(c.match[4]))});
bot.action(/^prod:(prepaid|pasca):(.+)$/,async c=>{await c.answerCbQuery();return showProduct(c,c.match[1],decodeURIComponent(c.match[2]))});
bot.action(/^buy:(prepaid|pasca):(.+)$/,async c=>{await c.answerCbQuery();return startBuy(c,c.match[1],decodeURIComponent(c.match[2]))});
bot.action(/^backprod:(prepaid|pasca):(.+):(.+):0$/,async c=>{await c.answerCbQuery();return showProducts(c,c.match[1],decodeURIComponent(c.match[2]),decodeURIComponent(c.match[3]),0)});
bot.action('cancelbuy',async c=>{await c.answerCbQuery();sessions.delete(String(c.from.id));return safeEdit(c,'❌ <b>PEMBELIAN DIBATALKAN</b>\n\nTidak ada saldo yang dipotong.',nav())});
bot.action(/^confirmbuy:(prepaid|pasca):(.+)$/,async c=>{await c.answerCbQuery();const s=sessions.get(String(c.from.id));if(!s||s.step!=='confirm'||s.type!==c.match[1]||s.sku!==decodeURIComponent(c.match[2]))return tempReply(c,'❌ Sesi pembelian sudah berakhir.');sessions.delete(String(c.from.id));return submitOrder(c,s,s.customerNo)});
bot.action(/^repeat:(.+)$/,async c=>{await c.answerCbQuery();const tx=db.getTx(decodeURIComponent(c.match[1]));if(!tx||String(tx.userId)!==String(c.from.id)||tx.purpose!=='ppob'||!tx.type||!tx.sku||!tx.customerNo)return tempReply(c,'❌ Transaksi tidak bisa diulang.');const s={type:tx.type,sku:tx.sku,customerNo:tx.customerNo};if(c.callbackQuery?.message?.message_id)await deleteMessage(c.chat?.id,c.callbackQuery.message.message_id);return showBuyConfirm(c,s,tx.customerNo)});
bot.action(/^buyrole:(silver|gold)$/,async c=>{await c.answerCbQuery();const target=c.match[1],u=user(c),amount=config.roles.price[target];if(!amount)return tempReply(c,'ℹ️ Upgrade role belum diberi harga.');if((target==='silver'&&u.role!=='bronze')||(target==='gold'&&u.role==='gold'))return tempReply(c,'❌ Role kamu sudah sama/lebih tinggi.');const tx=makeTx(c,{purpose:'role_upgrade',productName:`Upgrade ${target.toUpperCase()}`,amount,status:'WAITING_PAYMENT',paymentMethod:'QRIS'});db.addTx(tx);try{return createQR(c,tx)}catch(e){db.updateTx(tx.id,{status:'ERROR',error:e.message});return tempReply(c,'❌ '+esc(e.message),{parse_mode:'HTML'})}});
bot.action(/^paycheck:(.+)$/,async c=>{const t=db.getTx(c.match[1]);if(!t||t.userId!==String(c.from.id)){await c.answerCbQuery('Transaksi tidak ditemukan',true);return}const ok=await checkPayment(t);const x=db.getTx(t.id);await c.answerCbQuery(ok?'Pembayaran terdeteksi':'Belum dibayar');if(!ok&&x?.status==='WAITING_PAYMENT')return;});
bot.action(/^cancel:(.+)$/,async c=>{await c.answerCbQuery();const t=db.getTx(c.match[1]);if(!t||t.userId!==String(c.from.id))return tempReply(c,'❌ Transaksi tidak ditemukan.');if(t.status!=='WAITING_PAYMENT')return tempReply(c,'❌ Transaksi sudah diproses.');await removeQr(t);db.updateTx(t.id,{status:'CANCELLED'});return tempReply(c,'✅ Pembayaran dibatalkan.')});
bot.on('document',async ctx=>{const s=sessions.get(String(ctx.from.id));if(!s||s.type!=='admin_restore')return;if(!admin(ctx))return;sessions.delete(String(ctx.from.id));await restoreBackupFromTelegram(ctx);});
bot.on('text',async ctx=>{const s=sessions.get(String(ctx.from.id));if(!s)return;const raw=ctx.message.text||'',val=raw.trim();if(!val)return;if(s.type==='search'){sessions.delete(String(ctx.from.id));if(s.promptMessageId)await deleteMessage(ctx.chat.id,s.promptMessageId);await deleteCtxMessage(ctx);return showSearchResults(ctx,s.productType,val)}if(s.type==='admin_broadcast'){if(!admin(ctx))return;sessions.delete(String(ctx.from.id));await deleteCtxMessage(ctx);await tempReply(ctx,'⏳ Broadcast sedang dikirim...',{},4000);const r=await broadcast(ctx,raw);return tempReply(ctx,`✅ <b>BROADCAST SELESAI</b>\nTotal: ${r.total}\nBerhasil: ${r.ok}\nGagal: ${r.fail}`,{parse_mode:'HTML'})}if(s.type==='admin_addsaldo'||s.type==='admin_minsaldo'){if(!admin(ctx))return;const a=val.split(/\s+/),uid=a[0],nom=Number(a[1]);if(!uid||!Number.isFinite(nom)||nom<=0)return tempReply(ctx,'❌ Format: <code>123456789 10000</code>',{parse_mode:'HTML'});sessions.delete(String(ctx.from.id));await deleteCtxMessage(ctx);if(s.type==='admin_addsaldo')return tempReply(ctx,`✅ Saldo <code>${esc(uid)}</code> ditambah <b>${rp(db.addBalance(uid,nom))}</b>.`,{parse_mode:'HTML'});return tempReply(ctx,db.deductBalance(uid,nom)?`✅ Saldo <code>${esc(uid)}</code> dikurangi <b>${rp(nom)}</b>.`:'❌ Saldo user tidak mencukupi.',{parse_mode:'HTML'})}if(s.type==='admin_restore')return;const p=digi.find(s.sku,s.type);if(!p){sessions.delete(String(ctx.from.id));return}const sp=digi.destinationSpec(p.category,p.brand),tokens=val.split(/\s+/);if(sp.tokens===2&&tokens.length<2){await deleteCtxMessage(ctx);return tempReply(ctx,`❌ Format tujuan: ${sp.placeholder}`)}if(s.promptMessageId)await deleteMessage(ctx.chat.id,s.promptMessageId);await deleteCtxMessage(ctx);const customerNo=sp.tokens===2?tokens[0]+tokens[1]:val;return showBuyConfirm(ctx,s,customerNo)});
bot.catch(e=>console.error('BOT ERROR',e));
let servicesStarted=false;
async function startPpobServices(){
  if(servicesStarted)return;
  servicesStarted=true;
  if(digi.enabled()){
    const p=db.products();
    if(!p.lastSync||Date.now()-p.lastSync>config.syncMinutes*60000){
      try{await digi.sync()}catch(e){console.error('[PPOB] initial sync:',e.message)}
    }
  }
  setInterval(paymentLoop,config.paymentPollMs);
  setInterval(trxLoop,config.trxPollMs);
}
function isActiveSession(chatId){return sessions.has(String(chatId));}
async function handleUpdate(update){return bot.handleUpdate(update);}
async function openMenu(chatId,from={}){
  return handleUpdate({update_id:Date.now(),message:{message_id:Date.now()%1000000000,date:Math.floor(Date.now()/1000),chat:{id:Number(chatId),type:'private'},from:{id:Number(from.id||chatId),is_bot:false,first_name:from.first_name||'User'},text:'/ppob',entities:[{offset:0,length:5,type:'bot_command'}]}});
}
module.exports={bot,db,config,handleUpdate,startPpobServices,isActiveSession,openMenu,BRIDGE_PREFIX};
