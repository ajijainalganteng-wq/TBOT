'use strict';
const fs = require('fs');
const path = require('path');

const avarsPath = path.join(__dirname, 'data', '.avars.json');
function readConfig() {
  let a = {};
  try { a = JSON.parse(fs.readFileSync(avarsPath, 'utf8')); } catch (_) {}
  return {
    ownerId: String(a.owner_id || ''),
    admins: Array.isArray(a.admin_ids) ? a.admin_ids.map(String) : [],
    channelId: String(a.required_channel_id || ''),
    channelUrl: String(a.required_channel_url || ''),
    groupId: String(a.required_group_id || ''),
    groupUrl: String(a.required_group_url || '')
  };
}
function linkFor(id, url) {
  if (url) return url;
  if (/^@[A-Za-z0-9_]{5,}$/.test(id)) return `https://t.me/${id.slice(1)}`;
  return '';
}
function isMember(m) {
  const s = String(m?.status || '').toLowerCase();
  return ['creator', 'administrator', 'member'].includes(s) ||
    (s === 'restricted' && m?.is_member === true);
}
async function check(bot, userId) {
  const c = readConfig();
  if (!c.channelId && !c.groupId) return { ok: true, missing: [] };
  if (String(userId) === c.ownerId || c.admins.includes(String(userId))) return { ok: true, missing: [] };
  const missing = [];
  for (const item of [
    { id: c.channelId, url: linkFor(c.channelId, c.channelUrl), label: 'Channel' },
    { id: c.groupId, url: linkFor(c.groupId, c.groupUrl), label: 'Grup' }
  ]) {
    if (!item.id) continue;
    try {
      const member = await bot.getChatMember(item.id, userId);
      if (!isMember(member)) missing.push(item);
    } catch (e) {
      console.error(`[REQUIRED JOIN] Gagal memeriksa ${item.label}:`, e.message);
      missing.push(item);
    }
  }
  return { ok: missing.length === 0, missing };
}
async function prompt(bot, chatId, missing) {
  const rows = [];
  for (const item of missing) {
    if (item.url) rows.push([{ text: item.label === 'Channel' ? '📢 GABUNG CHANNEL' : '👥 GABUNG GRUP', url: item.url }]);
  }
  rows.push([{ text: '🔄 SAYA SUDAH BERGABUNG', callback_data: 'required_join_check' }]);
  return bot.sendMessage(chatId,
    '<b>🔒 WAJIB BERGABUNG</b>\n\nUntuk menggunakan bot <b>RIPZZ STORE</b>, kamu harus bergabung terlebih dahulu ke channel dan grup resmi yang diminta di bawah ini.\n\nSetelah bergabung, tekan tombol <b>SAYA SUDAH BERGABUNG</b> untuk verifikasi.',
    { parse_mode: 'HTML', reply_markup: { inline_keyboard: rows }, disable_web_page_preview: true }
  );
}
module.exports = { check, prompt };
