// cmd/menu_deposit.js - Optimized v2.0
'use strict';

module.exports = function menuDepositCmd(bot, chatId, msgId) {
  const text =
`┌─────────────────┐
│  💰 TOPUP SALDO
└─────────────────┘

Pilih nominal top up atau masukkan jumlah kustom:

Saldo masuk otomatis setelah pembayaran QRIS lunas.`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: '💸 Rp 15.000',  callback_data: 'deposit_15000'  },
        { text: '💸 Rp 20.000',  callback_data: 'deposit_20000'  }
      ],
      [
        { text: '💸 Rp 25.000',  callback_data: 'deposit_25000'  },
        { text: '💸 Rp 50.000',  callback_data: 'deposit_50000'  }
      ],
      [
        { text: '💸 Rp 75.000',  callback_data: 'deposit_75000'  },
        { text: '💸 Rp 100.000', callback_data: 'deposit_100000' }
      ],
      [{ text: '✏️ Jumlah Kustom', callback_data: 'deposit_custom'  }],
      [{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back'     }]
    ]
  };

  bot.editMessageText(text, {
    chat_id: chatId, message_id: msgId,
    reply_markup: keyboard
  }).catch(() => {});
};
