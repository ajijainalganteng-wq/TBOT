// services/autoDelete.js — Auto hapus akun expired dari server setiap 6 jam
'use strict';

const db   = require('../data/db');
const fs   = require('fs');
const path = require('path');
const { executeScriptRemote } = require('./ssh-exec');

const serverFilePath = path.join(__dirname, '../data/server.js');

/* ── Script hapus per tipe protokol ── */
const HAPUS_SCRIPT = {
  SSH:    'hapusSSH',
  VMESS:  'hapusVME',
  VLESS:  'hapusVLE',
  TROJAN: 'hapusTRO'
};

const LABEL = {
  SSH: '⚪ SSH/OpenVPN', VMESS: '🔵 xRay VMess',
  VLESS: '🟡 xRay VLess', TROJAN: '🟠 xRay Trojan', ZIVPN: '🟢 UDP ZivPN'
};

/* ── Kurangi server.used ── */
function decreaseServerUsage(serverIp) {
  try {
    const p = require.resolve('../data/server');
    delete require.cache[p];
    const servers = require('../data/server');
    const s = servers.find(sv => sv.ip === serverIp);
    if (s && s.used > 0) {
      s.used = s.used - 1;
      fs.writeFileSync(serverFilePath,
        `const servers = ${JSON.stringify(servers, null, 2)};\n\nmodule.exports = servers;`
      );
      delete require.cache[require.resolve('../data/server')];
    }
  } catch (e) {
    console.error('[autoDelete] decreaseServerUsage:', e.message);
  }
}

/* ── Tandai sudah dihapus di DB ── */
function markDeleted(serverIp, productType, username) {
  return new Promise(resolve => {
    db.run(
      `UPDATE transactions SET is_deleted=1
       WHERE server_ip=? AND product_type=? AND username=? AND status='completed'`,
      [serverIp, productType, username],
      function(err) {
        if (err) console.error('[autoDelete] markDeleted:', err.message);
        resolve(this?.changes || 0);
      }
    );
  });
}

/* ── Kirim notif ke user ── */
function notifyUser(bot, chatId, username, productType) {
  const label = LABEL[productType] || productType;
  bot.sendMessage(chatId,
`🗑 <b>Akun Kamu Telah Dihapus</b>

${label}
👤 Username : <code>${username}</code>

Akun sudah melewati masa aktif dan otomatis dihapus dari server.

Buat akun baru melalui menu Order Account!`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🛒 Order Akun Baru', callback_data: 'create_menu' }],
          [{ text: '🔃 Menu Utama',      callback_data: 'menu_back'  }]
        ]
      }
    }
  ).catch(() => {});
}

/* ── Proses satu akun expired ── */
function processOne(bot, row) {
  return new Promise(resolve => {
    const scriptName = HAPUS_SCRIPT[row.product_type];
    if (!scriptName) {
      console.warn(`[autoDelete] Tidak ada hapus script untuk ${row.product_type}`);
      return resolve({ status: 'SKIP', reason: 'no_script' });
    }

    const args = [row.username];

    executeScriptRemote(row.server_ip, scriptName, args, async (err, rawOutput) => {
      if (err) {
        console.error(`[autoDelete] SSH error ${row.username}@${row.server_ip}:`, err.message);
        return resolve({ status: 'SSH_ERROR', error: err.message });
      }

      const output = rawOutput || '';
      const statusLine = output.split('\n').find(l => l.startsWith('STATUS:'));
      const status = statusLine ? statusLine.replace('STATUS:', '').trim() : 'UNKNOWN';

      if (status === 'DELETED' || status === 'NOT_FOUND') {
        await markDeleted(row.server_ip, row.product_type, row.username);
        decreaseServerUsage(row.server_ip);

        /* Notif ke semua chat_id yang punya akun ini */
        db.all(
          `SELECT DISTINCT chat_id FROM transactions
           WHERE server_ip=? AND product_type=? AND username=? AND status='completed'`,
          [row.server_ip, row.product_type, row.username],
          (e2, userRows) => {
            (userRows || []).forEach(u => notifyUser(bot, u.chat_id, row.username, row.product_type));
          }
        );

        console.log(`[autoDelete] ✅ ${status}: ${row.product_type} / ${row.username} @ ${row.server_ip}`);
        resolve({ status });
      } else if (status === 'ROLLBACK') {
        console.warn(`[autoDelete] ⚠️ ROLLBACK: ${row.username} @ ${row.server_ip} — xray gagal restart, config dikembalikan`);
        resolve({ status: 'ROLLBACK' });
      } else {
        console.warn(`[autoDelete] ⚠️ Unknown status: "${status}" untuk ${row.username}`);
        resolve({ status: 'UNKNOWN', output });
      }
    });
  });
}

/* ── Ambil semua akun yang perlu dihapus ── */
function getExpiredAccounts() {
  return new Promise((resolve, reject) => {
    db.all(`
      SELECT server_ip, product_type, username,
             MAX(expired_at) as latest_exp,
             MAX(chat_id)    as chat_id
      FROM transactions
      WHERE status='completed'
        AND is_deleted = 0
        AND expired_at IS NOT NULL AND expired_at != ''
        AND username IS NOT NULL AND username != ''
        AND product_type NOT IN ('', 'TOPUP')
        AND product_type NOT LIKE 'TRIAL%'
        AND product_type NOT LIKE 'RENEW%'
      GROUP BY server_ip, product_type, username
      HAVING datetime(latest_exp) < datetime('now', 'localtime')
    `, [], (err, rows) => {
      if (err) return reject(err);
      resolve(rows || []);
    });
  });
}

/* ── Jalankan satu siklus delete ── */
async function runAutoDelete(bot) {
  let rows;
  try {
    rows = await getExpiredAccounts();
  } catch (e) {
    console.error('[autoDelete] getExpiredAccounts error:', e.message);
    return;
  }

  if (!rows.length) {
    console.log('[autoDelete] Tidak ada akun expired yang perlu dihapus.');
    return;
  }

  console.log(`[autoDelete] Memproses ${rows.length} akun expired...`);

  let deleted = 0, notFound = 0, errors = 0;

  for (const row of rows) {
    const result = await processOne(bot, row);
    if (result.status === 'DELETED')   deleted++;
    else if (result.status === 'NOT_FOUND') { notFound++; await markDeleted(row.server_ip, row.product_type, row.username); }
    else errors++;
    /* Jeda antar akun agar tidak overload SSH */
    await new Promise(r => setTimeout(r, 1500));
  }

  console.log(`[autoDelete] Selesai — ✅ Dihapus: ${deleted} | ⚠️ Not Found: ${notFound} | ❌ Error: ${errors}`);
}

/* ── Tambah kolom is_deleted jika belum ada ── */
function ensureColumn() {
  db.run(`ALTER TABLE transactions ADD COLUMN is_deleted INTEGER DEFAULT 0`, () => {});
  db.run(`CREATE INDEX IF NOT EXISTS idx_trx_deleted ON transactions(is_deleted, expired_at, status)`, () => {});
}

/* ── START ── */
function startAutoDelete(bot) {
  ensureColumn();

  const INTERVAL_HOURS = 6;

  /* Jalankan pertama kali setelah 2 menit (beri waktu bot startup selesai) */
  setTimeout(() => runAutoDelete(bot), 2 * 60 * 1000);

  /* Lalu setiap 6 jam */
  setInterval(() => runAutoDelete(bot), INTERVAL_HOURS * 60 * 60 * 1000);

  console.log(`[autoDelete] ✅ Auto-delete aktif (cek tiap ${INTERVAL_HOURS} jam, pertama kali dalam 2 menit)`);
}

module.exports = { startAutoDelete };
