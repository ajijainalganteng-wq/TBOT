'use strict';

let Client;
try { Client = require('ssh2').Client; } catch { Client = null; }

const API_SERVER_CODE = `
const express = require('express');
const { execFile } = require('child_process');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(express.json({ limit: '5mb' }));

const PORT = process.env.API_PORT || 3456;
const TOKEN = process.env.API_TOKEN || '';

if (!TOKEN) { console.error('[API] API_TOKEN belum diset!'); process.exit(1); }

const SCRIPT_DIR = path.join(__dirname, 'shell_script');

function authMiddleware(req, res, next) {
  const t = req.headers['x-api-token'] || req.body.token;
  if (!t || t !== TOKEN) return res.status(401).json({ error: 'Unauthorized' });
  next();
}

app.use('/api', authMiddleware);

app.get('/api/ping', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.post('/api/exec', (req, res) => {
  const { script, args } = req.body;
  if (!script) return res.status(400).json({ error: 'BAD_REQUEST' });
  if (!/^[a-zA-Z0-9_]+$/.test(script)) return res.status(400).json({ error: 'BAD_REQUEST' });
  const sp = path.join(SCRIPT_DIR, script);
  if (!fs.existsSync(sp)) return res.status(404).json({ error: 'SCRIPT_NOT_FOUND' });
  const sa = (args || []).map(a => String(a));
  execFile('bash', [sp, ...sa], { timeout: 30000 }, (err, stdout, stderr) => {
    if (err) {
      if (err.killed) return res.status(504).json({ error: 'TIMEOUT', output: stdout || '' });
      return res.json({ success: false, exitCode: err.code, output: ((stdout||'')+(stderr||'')).trim() });
    }
    res.json({ success: true, exitCode: 0, output: ((stdout||'')+(stderr||'')).trim() });
  });
});

app.post('/api/sync', (req, res) => {
  const { scripts } = req.body;
  if (!scripts || !Array.isArray(scripts) || !scripts.length) return res.status(400).json({ error: 'BAD_REQUEST' });
  if (!fs.existsSync(SCRIPT_DIR)) fs.mkdirSync(SCRIPT_DIR, { recursive: true });
  const results = [];
  for (const item of scripts) {
    if (!item.name || !item.content) { results.push({ name: item.name||'?', status: 'skipped' }); continue; }
    if (!/^[a-zA-Z0-9_]+$/.test(item.name)) { results.push({ name: item.name, status: 'skipped' }); continue; }
    try {
      const fp = path.join(SCRIPT_DIR, item.name);
      fs.writeFileSync(fp, item.content, 'utf8');
      fs.chmodSync(fp, '755');
      results.push({ name: item.name, status: 'ok' });
    } catch (e) { results.push({ name: item.name, status: 'error', reason: e.message }); }
  }
  res.json({ success: true, synced: results.filter(r=>r.status==='ok').length, failed: results.filter(r=>r.status!=='ok').length, details: results });
});

app.get('/api/scripts', (req, res) => {
  if (!fs.existsSync(SCRIPT_DIR)) return res.json({ scripts: [] });
  const files = fs.readdirSync(SCRIPT_DIR).filter(f => fs.statSync(path.join(SCRIPT_DIR, f)).isFile());
  res.json({ scripts: files });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('[API] VPS Bot API running on port ' + PORT);
});
`.trim();

function generateInstallScript(apiToken, apiPort) {
  const b64 = Buffer.from(API_SERVER_CODE).toString('base64');
  return `
set -e
export DEBIAN_FRONTEND=noninteractive

echo ">>> Updating packages..."
apt-get update -y -qq

echo ">>> Installing dependencies..."
apt-get install -y -qq curl jq >/dev/null 2>&1

if ! command -v node >/dev/null 2>&1; then
  echo ">>> Installing Node.js v20..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null 2>&1
  apt-get install -y -qq nodejs >/dev/null 2>&1
fi

echo ">>> Node version: $(node -v 2>/dev/null || echo 'NOT FOUND')"

mkdir -p /root/vps-api/shell_script

cat > /root/vps-api/package.json << 'PKGJSON'
{
  "name": "vps-bot-api",
  "version": "1.0.0",
  "dependencies": { "express": "^4.21.0" }
}
PKGJSON

echo "${b64}" | base64 -d > /root/vps-api/server.js

cd /root/vps-api
echo ">>> Installing npm modules..."
npm install --production >/dev/null 2>&1

echo ">>> Creating systemd service..."
cat > /etc/systemd/system/vps-api.service << SVCEOF
[Unit]
Description=VPS Bot API Server
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/vps-api
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=5
Environment=API_TOKEN=${apiToken}
Environment=API_PORT=${apiPort}

[Install]
WantedBy=multi-user.target
SVCEOF

systemctl daemon-reload
systemctl enable vps-api >/dev/null 2>&1
systemctl restart vps-api

echo ">>> Waiting for service to start..."
sleep 3
if systemctl is-active vps-api >/dev/null 2>&1; then
  echo "API_INSTALL_OK"
else
  echo "API_INSTALL_FAIL"
  echo ">>> Service status:"
  systemctl status vps-api --no-pager 2>&1 || true
  echo ">>> Journal logs:"
  journalctl -u vps-api -n 10 --no-pager 2>&1 || true
fi
`.trim();
}

function installApiRemote(ip, password, apiToken, apiPort, progressCallback) {
  return new Promise((resolve, reject) => {
    if (!Client) return reject(new Error('SSH module tidak tersedia'));

    const conn = new Client();
    const script = generateInstallScript(apiToken, apiPort);

    let output = '';
    let settled = false;

    const timeout = setTimeout(() => {
      if (!settled) {
        settled = true;
        conn.end();
        reject(new Error('Timeout 120 detik — install terlalu lama'));
      }
    }, 120000);

    conn.on('ready', () => {
      if (progressCallback) progressCallback('SSH connected, mulai install...');
      conn.exec(script, (err, stream) => {
        if (err) {
          clearTimeout(timeout);
          settled = true;
          conn.end();
          return reject(err);
        }

        stream.on('data', (data) => {
          output += data.toString();
        });

        stream.stderr.on('data', (data) => {
          output += data.toString();
        });

        stream.on('close', () => {
          clearTimeout(timeout);
          if (!settled) {
            settled = true;
            conn.end();
            if (output.includes('API_INSTALL_OK')) {
              resolve({ success: true, output });
            } else {
              resolve({ success: false, output });
            }
          }
        });
      });
    });

    conn.on('error', (err) => {
      clearTimeout(timeout);
      if (!settled) {
        settled = true;
        reject(err);
      }
    });

    conn.connect({
      host: ip,
      port: 22,
      username: 'root',
      password: password,
      readyTimeout: 15000,
      algorithms: {
        kex: [
          'ecdh-sha2-nistp256', 'ecdh-sha2-nistp384', 'ecdh-sha2-nistp521',
          'diffie-hellman-group-exchange-sha256', 'diffie-hellman-group14-sha256',
          'diffie-hellman-group14-sha1'
        ]
      }
    });
  });
}

module.exports = { installApiRemote, generateInstallScript };
