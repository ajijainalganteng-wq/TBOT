module.exports = {
  members: {
    ssh:      { perDay: 300 },
    vmess:    { perDay: 300 },
    vless:    { perDay: 300 },
    trojan:   { perDay: 300 },
    udpzivpn: { perDay: 300 }
  },
  reseller: {
    ssh:      { perDay: 180 },
    vmess:    { perDay: 180 },
    vless:    { perDay: 180 },
    trojan:   { perDay: 180 },
    udpzivpn: { perDay: 180 }
  }
};
