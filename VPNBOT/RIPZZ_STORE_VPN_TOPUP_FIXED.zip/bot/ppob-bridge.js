'use strict';
const fs=require('fs');
const path=require('path');
const TelegramBot=require('node-telegram-bot-api');
const requiredJoin=require('./required-join');
const avarsPath=path.join(__dirname,'data','.avars.json');
let avars={};
try{avars=JSON.parse(fs.readFileSync(avarsPath,'utf8'))}catch{}
if(avars.token && !process.env.TELEGRAM_BOT_TOKEN)process.env.TELEGRAM_BOT_TOKEN=avars.token;
if(!process.env.BOT_TOKEN && process.env.TELEGRAM_BOT_TOKEN)process.env.BOT_TOKEN=process.env.TELEGRAM_BOT_TOKEN;
const ppob=require('./ppob');
const PREFIX='ppob:';
let attached=false;
function normalizeUpdateFromMessage(msg){return {update_id:Date.now(),message:msg}}
async function start(bot){
  if(attached)return;
  attached=true;
  await ppob.startPpobServices();
  bot.on('callback_query',async q=>{
    const data=String(q?.data||'');
    if(data==='required_join_check')return;
    const joinStatus=await requiredJoin.check(bot,q?.from?.id);
    if(!joinStatus.ok){
      if(q?.id)bot.answerCallbackQuery(q.id,{text:'Silakan bergabung ke channel dan grup terlebih dahulu.',show_alert:true}).catch(()=>{});
      return;
    }
    if(!data.startsWith(PREFIX))return;
    const clean=data.slice(PREFIX.length);
    if(clean==='vpn_home' || clean==='vpn_admin'){
      bot.answerCallbackQuery(q.id).catch(()=>{});
      try{
        // Kembali ke modul VPN melalui callback handler yang sudah aktif.
        // vpn_home  -> menu utama VPN
        // vpn_admin -> panel admin VPN
        bot.emit('callback_query',{
          ...q,
          data: clean==='vpn_admin' ? 'adm_vpn' : 'menu_back'
        });
      }catch(e){console.error('[PPOB bridge navigation]',e.message)}
      return;
    }
    if(clean==='ppob_admin'){
      bot.answerCallbackQuery(q.id).catch(()=>{});
      try{
        // Buka panel admin PPOB tanpa membuat bot/polling Telegram kedua.
        const adminIds = (ppob.config.admins || []);
        if(!adminIds.includes(String(q.from?.id))) return;
        await ppob.handleUpdate({
          update_id: Date.now(),
          callback_query: {...q, data:'admin'}
        });
      }catch(e){console.error('[PPOB bridge admin]',e.message)}
      return;
    }
    try{
      const update={...q};
      update.data=clean;
      await ppob.handleUpdate({update_id:Date.now(),callback_query:update});
    }catch(e){console.error('[PPOB bridge callback]',e.message)}
  });
  bot.on('message',async msg=>{
    const text=String(msg?.text||'');
    const chatId=msg?.chat?.id;
    if(!chatId)return;
    // Only /ppob and active PPOB sessions need bridge routing.
    const isPpobCommand=/^\/ppob(?:@\w+)?$/i.test(text);
    // Perintah deposit harus diteruskan ke modul PPOB; sebelumnya bridge hanya
    // meneruskan /ppob sehingga /depo tidak pernah mencapai handler Telegraf PPOB.
    const isPpobDepositCommand=/^\/depo(?:@\w+)?(?:\s|$)/i.test(text);
    const activeSession=ppob.isActiveSession(chatId);
    if(!isPpobCommand && !isPpobDepositCommand && !activeSession)return;
    const joinStatus=await requiredJoin.check(bot,msg?.from?.id||chatId);
    if(!joinStatus.ok){
      await requiredJoin.prompt(bot,chatId,joinStatus.missing).catch(e=>console.error('[REQUIRED JOIN]',e.message));
      return;
    }
    if(isPpobCommand){
      try{await ppob.openMenu(chatId,msg.from||{})}catch(e){console.error('[PPOB bridge open]',e.message)}
      return;
    }
    // Jalankan /depo melalui handler command PPOB yang sama dengan transaksi lain.
    if(isPpobDepositCommand){
      try{await ppob.handleUpdate(normalizeUpdateFromMessage(msg))}catch(e){
        console.error('[PPOB bridge /depo]',e.message);
        await bot.sendMessage(chatId,'❌ Perintah top up PPOB gagal diproses. Silakan coba lagi atau hubungi admin.').catch(()=>{});
      }
      return;
    }
    // Active PPOB sessions receive normal text input.
    if(activeSession){
      try{await ppob.handleUpdate(normalizeUpdateFromMessage(msg))}catch(e){console.error('[PPOB bridge message]',e.message)}
    }
  });
  console.log('[PPOB] ✅ Bridge aktif — satu polling dengan bot VPN');
}
module.exports={start,isActiveSession:ppob.isActiveSession,openMenu:ppob.openMenu};
