const axios=require('axios'),crypto=require('crypto'),config=require('./config'),db=require('./db');
const BASE='https://api.digiflazz.com/v1';
function enabled(){return !!(config.digiflazz.username&&config.digiflazz.apiKey)}
function sign(x){return crypto.createHash('md5').update(`${config.digiflazz.username}${config.digiflazz.apiKey}${x}`).digest('hex')}
async function post(path,body){const r=await axios.post(BASE+path,body,{timeout:30000});return r.data}
async function priceList(cmd){if(!enabled())throw new Error('DIGIFLAZZ_USERNAME/API_KEY belum diisi');const r=await post('/price-list',{cmd,username:config.digiflazz.username,sign:sign('pricelist')});if(Array.isArray(r.data))return r.data;throw new Error(r.data?.message||r.message||`Pricelist ${cmd} gagal`)}
async function sync(){const old=db.products();const out={...old,lastSync:Date.now()};const [a,b]=await Promise.allSettled([priceList('prepaid'),priceList('pasca')]);const errors=[];if(a.status==='fulfilled')out.list_prepaid=a.value;else errors.push(`Prabayar: ${a.reason.message}`);if(b.status==='fulfilled')out.list_pasca=b.value;else errors.push(`Pascabayar: ${b.reason.message}`);db.saveProducts(out);if(a.status==='rejected'&&b.status==='rejected')throw new Error(errors.join('\n'));return out}
async function balance(){const r=await post('/cek-saldo',{cmd:'deposit',username:config.digiflazz.username,sign:sign('depo')});return r.data}
async function transaction({sku,customerNo,refId,type='prepaid'}){
 if(!enabled())throw new Error('Digiflazz belum dikonfigurasi');
 try{
  const r=await post('/transaction',{username:config.digiflazz.username,buyer_sku_code:sku,customer_no:customerNo,ref_id:refId,sign:sign(refId)});
  // Digiflazz dapat mengirim objek transaksi langsung atau membungkusnya di data.
  return r?.data&&typeof r.data==='object'&&!Array.isArray(r.data)?r.data:r;
 }catch(e){
  // Jika server mengirim status transaksi pada HTTP error, teruskan status itu
  // agar status GAGAL yang definitif tetap dapat diproses sebagai refund.
  const body=e.response?.data;
  const payload=body?.data&&typeof body.data==='object'?body.data:body;
  if(payload&&typeof payload==='object'&&payload.status)return payload;
  throw e;
 }
}
function find(sku,type){const p=db.products();const pools=type==='prepaid'?[p.list_prepaid]:type==='pasca'?[p.list_pasca]:[p.list_prepaid,p.list_pasca];return pools.flat().find(x=>String(x.buyer_sku_code||'').toLowerCase()===String(sku||'').toLowerCase())||null}
function basePrice(p,type){if(type==='pasca')return Number(p.price??p.admin??0)+Number(p.commission??0);return Number(p.price||0)}
function sellPrice(p,role,type='prepaid'){const margin=Number(config.roles.margin[role]??config.roles.margin.bronze);return Math.ceil(basePrice(p,type)*(1+margin/100))}
function active(p){return p&&p.buyer_product_status===true}
function cats(type){const arr=type==='prepaid'?db.products().list_prepaid:db.products().list_pasca;const m=new Map();for(const p of arr){if(!active(p))continue;const c=String(p.category||'LAINNYA');m.set(c,(m.get(c)||0)+1)}return [...m.entries()].sort((a,b)=>a[0].localeCompare(b[0]))}
function brands(type,cat){const arr=type==='prepaid'?db.products().list_prepaid:db.products().list_pasca;const m=new Map();for(const p of arr){if(!active(p)||String(p.category).toLowerCase()!==String(cat).toLowerCase())continue;const b=String(p.brand||'LAINNYA');m.set(b,(m.get(b)||0)+1)}return [...m.entries()].sort((a,b)=>a[0].localeCompare(b[0]))}
function list(type,cat,brand){const arr=type==='prepaid'?db.products().list_prepaid:db.products().list_pasca;return arr.filter(p=>active(p)&&String(p.category).toLowerCase()===String(cat).toLowerCase()&&(!brand||String(p.brand).toLowerCase()===String(brand).toLowerCase())).sort((a,b)=>basePrice(a,type)-basePrice(b,type))}
function destinationSpec(category,brand){const c=String(category||'').toLowerCase(),b=String(brand||'').toUpperCase();if(c==='games'){if(/MOBILE\s*LEGEND/.test(b))return{tokens:2,placeholder:'ID ZoneID',label:'ID + ZoneID'};return{tokens:1,placeholder:'ID Game',label:'ID Game'}}if(c==='pln')return{tokens:1,placeholder:'No Meter / ID Pelanggan',label:'No Meter / ID Pelanggan'};if(['tv','gas'].includes(c))return{tokens:1,placeholder:'ID Pelanggan',label:'ID Pelanggan'};if(['pulsa','data','masa aktif','paket sms & telpon','aktivasi perdana','aktivasi voucher','e-money','voucher'].includes(c))return{tokens:1,placeholder:'08xxxxxxxxxx',label:'Nomor HP'};return{tokens:1,placeholder:'Nomor / ID Tujuan',label:'Nomor / ID Tujuan'}}
module.exports={enabled,sign,priceList,sync,balance,transaction,find,basePrice,sellPrice,cats,brands,list,destinationSpec,active};
