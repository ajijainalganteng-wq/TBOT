// services/paymentChecker.js - Outletku GoPay QRIS H2H — 5min expiry
'use strict';

const outletku = require('./outletku');
const db     = require('../data/db');
const { calculateBonus } = require('./promo');
const { doCreateAccountAfterPayment, doRenewAccountAfterPayment } = require('./ssh-exec');
const { notifyVpnTopup } = require('./vpn-notify');

const BOT_NAME       = process.env.BOT_NAME || 'RIPZZ STORE';
const OWNER_ID       = Number(process.env.OWNER_ID || 0);
const CHECK_INTERVAL = 8000;
const QRIS_TTL_MS    = 5 * 60 * 1000;

const gatewayConfig = outletku.settings();
if (!gatewayConfig.apiKey) {
  console.warn('[paymentChecker] ⚠️ OUTLETKU_API_KEY/P2P_API_KEY kosong — payment checker menunggu konfigurasi.');
}

const pendingOrders = new Map();

function addPendingOrder(orderId, info) {
  pendingOrders.set(orderId, { ...info, createdAt: Date.now(), status: 'pending' });
}

function removePendingOrder(orderId) {
  pendingOrders.delete(orderId);
}
async function removePendingOrderAndQr(orderId) {
  const info = pendingOrders.get(orderId);
  removePendingOrder(orderId);
  if (info) {
    try { const { clearQrisCountdown } = require('./qris'); clearQrisCountdown(orderId); } catch (_) {}
    await deleteQrMessage(info);
  }
}

async function deleteQrMessage(info) {
  if (!info?.chatId || !info?.qrMsgId) return;
  try { await botTelegramDelete(info.chatId, info.qrMsgId); } catch (_) {}
}
let activeBot = null;
function botTelegramDelete(chatId, messageId) {
  return activeBot?.deleteMessage(chatId, messageId) || Promise.resolve();
}

/* ══════════════════════════════════════════
   NOTIFIKASI REAL-TIME KE ADMIN
══════════════════════════════════════════ */
function notifyAdmin(bot, orderId, info, type) {
  if (!OWNER_ID) return;

  const typeLabels = {
    topup:   '💰 TOP UP SALDO',
    create:  '📦 BELI AKUN',
    renew:   '🔄 PERPANJANG AKUN'
  };

  const nominal = info.amount || 0;
  const waktu   = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false });

  const msg =
`🔔 <b>PEMBAYARAN MASUK!</b>

📌 Tipe     : <b>${typeLabels[type] || type}</b>
🆔 Chat ID  : <code>${info.chatId}</code>
🧾 Order ID : <code>${orderId}</code>
💵 Nominal  : <b>Rp ${nominal.toLocaleString('id-ID')}</b>
⏰ Waktu    : ${waktu} WIB`;

  bot.sendMessage(OWNER_ID, msg, { parse_mode: 'HTML' }).catch(() => {});
}

async function fetchPaymentStatus(orderId, info) {
  try {
    if (!info.qrisId) return { status: 'unknown' };
    const result = await outletku.checkQris(info.qrisId);
    return { status: result.status, data: result.data };
  } catch (e) {
    console.error('[paymentChecker] gagal cek Outletku:', e.message);
    return { status: 'error' };
  }
}

async function processCompletedPayment(bot, orderId, info) {
  removePendingOrder(orderId);
  await deleteQrMessage(info);

  /* cancel QRIS countdown */
  try {
    const { clearQrisCountdown } = require('./qris');
    clearQrisCountdown(orderId);
  } catch (e) {}

  if (info.accountCreate) {
    db.run("UPDATE transactions SET status='completed' WHERE order_id=?", [orderId]);
    notifyAdmin(bot, orderId, info, 'create');
    doCreateAccountAfterPayment(bot, info.chatId, info.accountCreate);
    return;
  }

  if (info.accountRenew) {
    db.run("UPDATE transactions SET status='completed' WHERE order_id=?", [orderId]);
    notifyAdmin(bot, orderId, info, 'renew');
    doRenewAccountAfterPayment(bot, info.chatId, info.accountRenew);
    return;
  }

  // Topup saldo
  const finalAmount = calculateBonus(info.amount);

  db.run(
    "INSERT OR IGNORE INTO users (chat_id, saldo, role, created_at) VALUES (?, 0, 'members', datetime('now','localtime'))",
    [info.chatId],
    () => {
      db.run('UPDATE users SET saldo = saldo + ? WHERE chat_id=?', [finalAmount, info.chatId], () => {
        db.get('SELECT saldo, role FROM users WHERE chat_id=?', [info.chatId], (err, row) => {
          if (!row) return;
          const newSaldo = row.saldo || 0;
          const effectiveRole = (newSaldo >= 20000 && row.role !== 'admin') ? 'reseller' : (row.role || 'members');
          if (newSaldo >= 20000 && row.role !== 'reseller' && row.role !== 'admin') {
            db.run("UPDATE users SET role='reseller' WHERE chat_id=?", [info.chatId]);
          }

          notifyVpnTopup(bot, {
            chatId: info.chatId,
            amount: info.amount,
            bonus: Math.max(0, finalAmount - info.amount),
            balance: newSaldo,
            role: effectiveRole,
            payment: 'Outletku GoPay QRIS',
            trxNo: String(Date.now()).slice(-6)
          }).catch(() => {});

          bot.sendMessage(info.chatId,
`✅ <b>PEMBAYARAN BERHASIL!</b>

🧾 Order ID    : <code>${orderId}</code>
💰 Nominal     : Rp ${info.amount.toLocaleString('id-ID')}${finalAmount > info.amount ? `\n🎁 Bonus       : +Rp ${(finalAmount - info.amount).toLocaleString('id-ID')}` : ''}
💳 Total Masuk : <b>Rp ${finalAmount.toLocaleString('id-ID')}</b>
💰 Saldo Baru  : <b>Rp ${newSaldo.toLocaleString('id-ID')}</b>

Ketik /menu untuk mulai order.`,
            { parse_mode: 'HTML' }
          ).catch(() => {});
        });
      });
    }
  );

  db.run("UPDATE transactions SET status='completed' WHERE order_id=?", [orderId]);
  notifyAdmin(bot, orderId, info, 'topup');
}

async function handleRefresh(bot, chatId, orderId) {
  const info = pendingOrders.get(orderId);
  if (!info) {
    return bot.sendMessage(chatId, '❌ Order tidak ditemukan atau sudah kadaluarsa.');
  }

  const tx = await fetchPaymentStatus(orderId, info);

  if (tx.status === 'completed') {
    await processCompletedPayment(bot, orderId, info);
  } else if (tx.status === 'canceled' || tx.status === 'expired') {
    removePendingOrder(orderId);
    db.run("UPDATE transactions SET status=? WHERE order_id=?", [tx.status, orderId]);
    try { const { clearQrisCountdown } = require('./qris'); clearQrisCountdown(orderId); } catch (_) {}
    await deleteQrMessage(info);
    bot.sendMessage(chatId, `❌ QRIS ${tx.status === 'canceled' ? 'dibatalkan' : 'kedaluwarsa'}.`, { parse_mode: 'HTML' }).catch(() => {});
  } else {
    const statusMap = {
      error:     'Gagal cek (coba lagi)',
      not_found: 'Belum terbayar',
      canceled:  'Dibatalkan',
      expired:   'Kadaluarsa'
    };
    bot.sendMessage(chatId,
      `⏳ <b>Status: ${statusMap[tx.status] || 'Pending'}</b>\n\nBelum ada pembayaran masuk.\nBayar dulu, lalu klik tombol cek lagi.`,
      { parse_mode: 'HTML' }
    );
  }
}

function startPaymentChecker(bot) {
  if (!gatewayConfig.apiKey) return;
  console.log(`[${BOT_NAME}] ✅ Payment checker aktif (interval ${CHECK_INTERVAL}ms)`);

  setInterval(async () => {
    if (pendingOrders.size === 0) return;

    const checks = [];
    for (const [orderId, info] of pendingOrders.entries()) {
      const expiredAt = Number(info.expiresAt || (info.createdAt + QRIS_TTL_MS));
      if (Date.now() > expiredAt) {
        // One final status lookup prevents a payment made near expiry from being missed.
        const finalCheck = await fetchPaymentStatus(orderId, info);
        if (finalCheck.status === 'completed') {
          await processCompletedPayment(bot, orderId, info);
          continue;
        }
        pendingOrders.delete(orderId);
        db.run("UPDATE transactions SET status='expired' WHERE order_id=?", [orderId]);
        try { const { clearQrisCountdown } = require('./qris'); clearQrisCountdown(orderId); } catch (e) {}
        await deleteQrMessage(info);
        bot.sendMessage(info.chatId,
          `❌ Order <code>${orderId}</code> kedaluwarsa (batas waktu QRIS 5 menit).`,
          { parse_mode: 'HTML' }
        ).catch(() => {});
        continue;
      }
      checks.push([orderId, info]);
    }

    for (const [orderId, info] of checks) {
      const tx = await fetchPaymentStatus(orderId, info);
      if (tx.status === 'completed') {
        await processCompletedPayment(bot, orderId, info);
      } else if (tx.status === 'canceled' || tx.status === 'expired') {
        removePendingOrder(orderId);
        db.run("UPDATE transactions SET status=? WHERE order_id=?", [tx.status, orderId]);
        try { const { clearQrisCountdown } = require('./qris'); clearQrisCountdown(orderId); } catch (e) {}
        await deleteQrMessage(info);
        bot.sendMessage(info.chatId,
          `❌ Order <code>${orderId}</code> dibatalkan/kadaluarsa.`,
          { parse_mode: 'HTML' }
        ).catch(() => {});
      }
    }
  }, CHECK_INTERVAL);
}

module.exports = { addPendingOrder, removePendingOrder, removePendingOrderAndQr, handleRefresh, startPaymentChecker };
