# RIPZZ STORE VPN + PPOB ALL-IN-ONE

Paket ini mempertahankan engine VPN dari `bot.zip` dan menambahkan layanan PPOB dari RIPZZ STORE:
- Pembelian game, kuota, pulsa, e-wallet, PLN.
- Saldo PPOB memakai saldo user Telegram pada database VPN.
- Top up QRIS menggunakan RamaShop.
- Pembelian otomatis menggunakan OkeConnect B2B.
- Jika saldo kurang, user dapat memilih Bayar via QR atau Top Up Dulu.
- QR pembayaran dihapus saat sukses, batal, atau expired.
- Notifikasi transaksi PPOB sukses/gagal ke grup jika NOTIFY_GROUP_ID diisi.

Konfigurasi tambahan ada di `.env.example`.
Isi `RAMASHOP_API_KEY`, `ORKUT_MEMBER_ID`, `ORKUT_PIN`, `ORKUT_PASSWORD`, dan `PROFIT_PERCENT`.
Token bot VPN tetap mengikuti konfigurasi asli `bot/data/.avars.json`.

Instal:
1. Upload ZIP ke VPS.
2. Extract.
3. Isi `bot/.env` berdasarkan `.env.example`.
4. `cd bot && npm install`
5. Jalankan bot sesuai service/installer bot asli.
