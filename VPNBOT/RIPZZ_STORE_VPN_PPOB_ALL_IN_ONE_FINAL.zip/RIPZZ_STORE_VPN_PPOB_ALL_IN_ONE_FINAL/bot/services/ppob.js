// services/ppob.js — RIPZZ STORE PPOB migrated into the VPN bot
'use strict';
const axios = require('axios');
const QRCode = require('qrcode');
const crypto = require('crypto');
const db = require('../data/db');

const states = new Map();
const pendingPayments = new Map();
const productCache = { at: 0, data: [] };
const CACHE_MS = 60 * 1000;
const POLL_MS = 8000;
const TTL_MS = 5 * 60 * 1000;

function env(key, fallback='') {
  if (process.env[key]) return process.env[key];
  try {
    const fs = require('fs'), path = require('path');
    const p = path.join(__dirname, '../.env');
    if (fs.existsSync(p)) {
      for (const line of fs.readFileSync(p,'utf8').split(/\r?\n/)) {
        const s=line.trim(); if(!s || s.startsWith('#')) continue;
        const i=s.indexOf('='); if(i<1) continue;
        if(s.slice(0,i).trim()===key) return s.slice(i+1).trim().replace(/^['"]|['"]$/g,'');
      }
    }
  } catch {}
  return fallback;
}
const RAMA_KEY = () => env('RAMASHOP_API_KEY');
const MEMBER = () => env('ORKUT_MEMBER_ID');
const PIN = () => env('ORKUT_PIN');
const PASSWORD = () => env('ORKUT_PASSWORD');
const PROFIT = () => Number(env('PROFIT_PERCENT','5')) || 0;

const http = axios.create({ timeout: 15000, validateStatus: s => s >= 200 && s < 500 });
const money = n => `Rp ${Number(n||0).toLocaleString('id-ID')}`;
const esc = s => String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const cleanNumber = v => Number(String(v??0).replace(/[^0-9.-]/g,'')) || 0;
const nameOf = p => String(p?.keterangan || p?.nama || p?.produk || p?.kode || 'Produk')
  .replace('Customer H2H ','').replace('Customer ','').trim();
const priceOf = p => { const b=cleanNumber(p?.harga); return b + Math.ceil(b*PROFIT()/100); };
const refId = () => crypto.randomBytes(5).toString('hex').toUpperCase();

async function products(force=false) {
  if (!force && productCache.data.length && Date.now()-productCache.at<CACHE_MS) return productCache.data;
  const r=await http.get('https://okeconnect.com/harga/json?id=905ccd028329b0a');
  if(!Array.isArray(r.data)) throw new Error('Data produk provider tidak valid.');
  productCache.at=Date.now(); productCache.data=r.data; return r.data;
}
function filter(category,p) {
  const k=String(p.kode||'').toUpperCase(), kat=String(p.kategori||'').toUpperCase(), prod=String(p.produk||'').toUpperCase(), ket=String(p.keterangan||'').toUpperCase();
  if(category==='game') return /^(DML|FF|SUS|AVL|UW|PUBG|COD|HOK)/.test(k) || /STUMBLE|SAUSAGE|ARENA BREAK|GENSHIN|POINT BLANK/.test(ket+' '+prod);
  if(category==='kuota') return kat.includes('KUOTA ');
  if(category==='ewallet') return kat.includes('DOMPET DIGITAL') || /^(GJK|ISAKU|OVO|SHOPE|LINK)/.test(k);
  if(category==='pulsa') return kat.includes('PULSA') && !kat.includes('TRANSFER');
  if(category==='pln') return k.startsWith('PLN');
  if(category==='xl') return kat.includes('KUOTA XL');
  if(category==='telkomsel') return kat.includes('KUOTA TELKOMSEL');
  if(category==='axis') return kat.includes('KUOTA AXIS');
  if(category==='indosat') return kat.includes('KUOTA INDOSAT');
  if(category==='three') return kat.includes('KUOTA TRI');
  if(category==='byu') return kat.includes('KUOTA BYU');
  if(category==='smartfren') return kat.includes('KUOTA SMARTFREN');
  return false;
}
function edit(bot,chatId,msgId,text,keyboard) {
  return bot.editMessageText(text,{chat_id:chatId,message_id:msgId,parse_mode:'HTML',reply_markup:{inline_keyboard:keyboard}})
    .catch(async e=>{
      if(/not modified/i.test(e.message||'')) return;
      try { return await bot.editMessageCaption(text,{chat_id:chatId,message_id:msgId,parse_mode:'HTML',reply_markup:{inline_keyboard:keyboard}}); } catch {}
    });
}
function back(){ return [[{text:'⬅️ Kembali',callback_data:'menu_back'}]]; }

function menu(bot,chatId,msgId) {
  const kb=[
    [{text:'🎮 GAME',callback_data:'ppob:cat:game'},{text:'🌐 KUOTA',callback_data:'ppob:cat:kuota'}],
    [{text:'💳 E-WALLET',callback_data:'ppob:cat:ewallet'},{text:'📱 PULSA',callback_data:'ppob:cat:pulsa'}],
    [{text:'💡 PLN',callback_data:'ppob:cat:pln'},{text:'💰 TOP UP',callback_data:'ppob:deposit'}],
    [{text:'⬅️ Kembali ke VPN',callback_data:'menu_back'}]
  ];
  return msgId ? edit(bot,chatId,msgId,'🛍️ <b>MENU PPOB</b>\n\nPilih layanan yang ingin kamu beli:',kb) : bot.sendMessage(chatId,'🛍️ <b>MENU PPOB</b>\n\nPilih layanan yang ingin kamu beli:',{parse_mode:'HTML',reply_markup:{inline_keyboard:kb}});
}
async function category(bot,chatId,msgId,cat,page=0) {
  try {
    const all=await products();
    let rows=all.filter(p=>filter(cat,p)).sort((a,b)=>priceOf(a)-priceOf(b));
    const per=8,total=Math.max(1,Math.ceil(rows.length/per));
    page=Math.max(0,Math.min(Number(page)||0,total-1));
    const slice=rows.slice(page*per,(page+1)*per);
    if(!slice.length) return edit(bot,chatId,msgId,'❌ Produk kategori ini tidak tersedia.',back());
    const kb=slice.map(p=>[{text:`${nameOf(p).slice(0,42)} — ${money(priceOf(p))}`,callback_data:`ppob:buy:${String(p.kode).slice(0,40)}`}]);
    const nav=[];
    if(page>0) nav.push({text:'⬅️',callback_data:`ppob:page:${cat}:${page-1}`});
    nav.push({text:`${page+1}/${total}`,callback_data:'ppob:noop'});
    if(page<total-1) nav.push({text:'➡️',callback_data:`ppob:page:${cat}:${page+1}`});
    kb.push(nav,[{text:'⬅️ PPOB',callback_data:'ppob:menu'}]);
    return edit(bot,chatId,msgId,`📦 <b>${cat.toUpperCase()}</b>\n\nPilih produk:`,kb);
  } catch(e) {
    console.error('[PPOB category]',e);
    return edit(bot,chatId,msgId,`❌ Gagal mengambil produk: ${esc(e.message)}`,back());
  }
}
async function buyPrompt(bot,chatId,msgId,code) {
  const all=await products(); const p=all.find(x=>String(x.kode)===String(code));
  if(!p) return edit(bot,chatId,msgId,'❌ Produk tidak ditemukan.',back());
  const price=priceOf(p), name=nameOf(p);
  states.set(chatId,{step:'target',code,price,name,msgId});
  return edit(bot,chatId,msgId,
    `🛒 <b>KONFIRMASI PRODUK</b>\n\n📦 <b>${esc(name)}</b>\n💰 Harga: <b>${money(price)}</b>\n\n📱 Masukkan nomor/ID tujuan produk:`,
    [[{text:'❌ Batal',callback_data:'ppob:cancel'}]]);
}
async function confirmBuy(bot,chatId,msgId,s) {
  const bal=new Promise(r=>db.get('SELECT saldo FROM users WHERE chat_id=?',[chatId],(e,row)=>r(Number(row?.saldo||0))));
  const saldo=await bal;
  if(saldo<s.price) {
    return edit(bot,chatId,msgId,
      `⚠️ <b>SALDO TIDAK MENCUKUPI</b>\n\n📦 ${esc(s.name)}\n💰 Harga: <b>${money(s.price)}</b>\n💳 Saldo: <b>${money(saldo)}</b>\n❌ Kurang: <b>${money(s.price-saldo)}</b>\n\nSilakan pilih cara melanjutkan:`,
      [[{text:'💳 Bayar via QR',callback_data:`ppob:pay:${s.price}:${s.code}`}],
       [{text:'➕ Top Up Dulu',callback_data:'ppob:deposit'}],
       [{text:'❌ Batal',callback_data:'ppob:cancel'}]]);
  }
  return edit(bot,chatId,msgId,
    `🔎 <b>PERIKSA PESANAN</b>\n\n📦 ${esc(s.name)}\n📱 Tujuan: <code>${esc(s.target)}</code>\n💰 Total: <b>${money(s.price)}</b>\n\nLanjutkan pembelian?`,
    [[{text:'✅ Lanjut',callback_data:'ppob:confirm'}],[{text:'❌ Batal',callback_data:'ppob:cancel'}]]);
}
async function order(bot,chatId,msgId,s) {
  if(s.busy) return; s.busy=true;
  const deducted = await new Promise(resolve=>db.get('SELECT saldo FROM users WHERE chat_id=?',[chatId],(e,row)=>{
    const bal=Number(row?.saldo||0); if(bal<s.price) return resolve(false);
    db.run('UPDATE users SET saldo=saldo-? WHERE chat_id=?',[s.price,chatId],()=>resolve(true));
  }));
  if(!deducted){ s.busy=false; return confirmBuy(bot,chatId,msgId,s); }
  await edit(bot,chatId,msgId,'⏳ <b>PROSES TRANSAKSI</b>\n\n🔄 Menghubungkan ke provider...\n\n░░░░░░░░░░ 0%',[[{text:'❌ Batalkan',callback_data:'ppob:cancel'}]]);
  const rid=refId();
  try {
    const r=await http.get('https://b2b.okeconnect.com/trx-v2',{params:{product:s.code,dest:s.target,refID:rid,memberID:MEMBER(),pin:PIN(),password:PASSWORD()}});
    const d=r.data;
    const raw=JSON.stringify(d).toUpperCase();
    if(/GAGAL|FAILED|ERROR|DENIED|SALAH|NOT FOUND/.test(raw)) throw new Error(d?.message||d?.status||'Provider menolak transaksi.');
    let final=d;
    let status=String(d?.status||'').toUpperCase();
    const deadline=Date.now()+120000;
    while(!['SUKSES','SUCCESS','GAGAL','FAILED'].includes(status) && Date.now()<deadline){
      await new Promise(r=>setTimeout(r,5000));
      const q=await http.get('https://b2b.okeconnect.com/trx-v2',{params:{product:s.code,dest:s.target,refID:rid,memberID:MEMBER(),pin:PIN(),password:PASSWORD()}});
      final=q.data; status=String(final?.status||'').toUpperCase();
      if(/GAGAL|FAILED|ERROR|DENIED/.test(JSON.stringify(final).toUpperCase())) status='GAGAL';
    }
    if(status!=='SUKSES' && status!=='SUCCESS') throw new Error(final?.message||'Provider belum memberikan status sukses.');
    const trxId=rid, sn=final?.sn||final?.serial_number||'-';
    db.run("INSERT INTO transactions (chat_id,order_id,amount,status,created_at,product_type,username) VALUES (?,?,?,'completed',datetime('now','localtime'),?,?)",
      [chatId,trxId,s.price,s.name,String(s.target)]);
    s.busy=false; states.delete(chatId);
    await edit(bot,chatId,msgId,`✅ <b>TRANSAKSI BERHASIL</b>\n\n📦 ${esc(s.name)}\n📱 Tujuan: <code>${esc(s.target)}</code>\n💰 Harga: <b>${money(s.price)}</b>\n🧾 Ref: <code>${trxId}</code>${sn&&sn!=='-'?`\n🔑 SN: <code>${esc(sn)}</code>`:''}\n\n🎉 Pesanan berhasil diproses.`,back());
    return notify(bot,chatId,'success',s,trxId);
  } catch(e) {
    db.run('UPDATE users SET saldo=saldo+? WHERE chat_id=?',[s.price,chatId]);
    s.busy=false;
    await edit(bot,chatId,msgId,`❌ <b>TRANSAKSI GAGAL</b>\n\n${esc(e.message||'Provider gagal memproses transaksi.')}\n\n💰 Saldo dikembalikan: <b>${money(s.price)}</b>`,back());
    return notify(bot,chatId,'failed',s,rid,e.message);
  }
}
async function notify(bot,chatId,status,s,ref,err='') {
  const id=env('NOTIFY_GROUP_ID')||env('REQUIRED_GROUP_ID')||env('OWNER_TELEGRAM_ID');
  if(!id) return;
  const label=status==='success'?'✅ TRANSAKSI PPOB BERHASIL':'❌ TRANSAKSI PPOB GAGAL';
  bot.sendMessage(id,`${label}\n\n👤 User: <code>${chatId}</code>\n📦 ${esc(s.name)}\n💰 ${money(s.price)}\n📱 <code>${esc(s.target)}</code>\n🧾 <code>${ref}</code>${err?`\n⚠️ ${esc(err)}`:''}`,{parse_mode:'HTML'}).catch(()=>{});
}
async function createRama(bot,chatId,msgId,amount,returnState=null) {
  const key=RAMA_KEY(); if(!key) return edit(bot,chatId,msgId,'❌ RAMASHOP_API_KEY belum diatur.',back());
  const orderId=`DEP_${chatId}_${Date.now()}`;
  try {
    const r=await http.post('https://ramashop.my.id/api/public/deposit/create',{amount:Number(amount),method:'qris'},{headers:{'X-API-Key':key}});
    if(!r.data?.success || !r.data?.data) throw new Error(r.data?.message||'Gagal membuat pembayaran.');
    const d=r.data.data, depId=d.deposit_id||d.id||d.order_id||orderId;
    const qr=d.qr_string||d.qris||d.qr_code||d.payment_number||d.qr;
    if(!qr) throw new Error('Provider pembayaran tidak mengembalikan QRIS.');
    const buf=await QRCode.toBuffer(qr,{width:380});
    const m=await bot.sendPhoto(chatId,buf,{caption:`💳 <b>PEMBAYARAN QRIS</b>\n\n💰 Nominal: <b>${money(amount)}</b>\n🧾 ID: <code>${esc(depId)}</code>\n\n⏳ Berlaku 5 menit.\n\n<i>Saldo akan otomatis masuk setelah pembayaran berhasil.</i>`,parse_mode:'HTML',reply_markup:{inline_keyboard:[[ {text:'🔄 Cek Pembayaran',callback_data:`ppob:status:${depId}`} ],[{text:'❌ Batalkan',callback_data:`ppob:cancelpay:${depId}`}]]}});
    pendingPayments.set(String(depId),{chatId,amount,msgId:m.message_id,createdAt:Date.now(),returnState});
    return m;
  } catch(e) {
    console.error('[PPOB Rama]',e);
    return edit(bot,chatId,msgId,`❌ <b>Gagal membuat QRIS</b>\n\n${esc(e.message)}`,back());
  }
}
async function paymentStatus(depId) {
  const key=RAMA_KEY(); if(!key) throw new Error('RAMASHOP_API_KEY belum diatur.');
  const r=await http.get(`https://ramashop.my.id/api/public/deposit/status/${encodeURIComponent(depId)}`,{headers:{'X-API-Key':key}});
  return r.data;
}
async function completeDeposit(bot,depId,info) {
  if(!pendingPayments.has(String(depId))) return;
  pendingPayments.delete(String(depId));
  try{await bot.deleteMessage(info.chatId,info.msgId);}catch{}
  db.run("INSERT OR IGNORE INTO users(chat_id,saldo,role,created_at) VALUES(?,0,'members',datetime('now','localtime'))",[info.chatId]);
  db.run('UPDATE users SET saldo=saldo+? WHERE chat_id=?',[info.amount,info.chatId],()=>{
    const resume = info.returnState;
    if (resume && resume.code && resume.target) {
      states.set(info.chatId, {...resume});
      bot.sendMessage(info.chatId,
        `✅ <b>TOP UP BERHASIL</b>\n\n💰 Saldo bertambah <b>${money(info.amount)}</b>.\n\n🛒 Pesanan ${esc(resume.name || '')} siap dilanjutkan.`,
        {parse_mode:'HTML',reply_markup:{inline_keyboard:[
          [{text:'🛒 Lanjutkan Pembelian',callback_data:'ppob:resume'}],
          [{text:'⬅️ Kembali',callback_data:'menu_back'}]
        ]}}
      ).catch(()=>{});
    } else {
      bot.sendMessage(info.chatId,`✅ <b>TOP UP BERHASIL</b>\n\n💰 Masuk: <b>${money(info.amount)}</b>\n💳 Saldo diperbarui.\n\nSilakan kembali ke menu.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:back()}}).catch(()=>{});
    }
  });
  const id=env('NOTIFY_GROUP_ID')||env('REQUIRED_GROUP_ID')||env('OWNER_TELEGRAM_ID');
  if(id) bot.sendMessage(id,`💰 <b>TOP UP BERHASIL</b>\n\n👤 User: <code>${info.chatId}</code>\n💵 Nominal: <b>${money(info.amount)}</b>\n🧾 <code>${esc(depId)}</code>`,{parse_mode:'HTML'}).catch(()=>{});
}
async function checkDeposit(bot,depId) {
  const info=pendingPayments.get(String(depId)); if(!info) return;
  try {
    const s=await paymentStatus(depId), raw=JSON.stringify(s).toLowerCase();
    if(/completed|success|paid|settled|berhasil|lunas/.test(raw)) return completeDeposit(bot,depId,info);
    if(/expired|cancelled|canceled/.test(raw) || Date.now()-info.createdAt>TTL_MS) {
      pendingPayments.delete(String(depId)); try{await bot.deleteMessage(info.chatId,info.msgId);}catch{}
      return bot.sendMessage(info.chatId,'❌ <b>QRIS kadaluarsa/dibatalkan.</b>\n\nSilakan buat top up baru.',{parse_mode:'HTML',reply_markup:{inline_keyboard:back()}}).catch(()=>{});
    }
  } catch(e) { console.error('[PPOB payment check]',e.message); }
}
setInterval(()=>{ for(const id of pendingPayments.keys()) checkDeposit(globalBot,id); },POLL_MS);
let globalBot=null;

async function handleMessage(bot,msg) {
  const chatId=msg.chat.id, text=String(msg.text||'').trim();
  const st=states.get(chatId); if(!st) return false;
  if(st.step==='target') {
    if(!text || text.startsWith('/')) return false;
    st.target=text; return confirmBuy(bot,chatId,st.msgId,st);
  }
  if(st.step==='deposit_amount') {
    if(!/^\d+$/.test(text)) return true;
    const amount=Number(text); if(amount<2000 || amount>5000000){bot.sendMessage(chatId,'❌ Nominal harus Rp2.000–Rp5.000.000.');return true;}
    states.delete(chatId); await createRama(bot,chatId,st.msgId,amount); return true;
  }
  return false;
}
async function handleCallback(bot,query) {
  const chatId=query.message.chat.id,msgId=query.message.message_id,data=query.data||'';
  if(!data.startsWith('ppob:')) return false;
  if(data==='ppob:menu'){await menu(bot,chatId,msgId);return true;}
  if(data==='ppob:deposit'){states.set(chatId,{step:'deposit_amount',msgId});return edit(bot,chatId,msgId,'💳 <b>TOP UP SALDO PPOB</b>\n\nMasukkan nominal top up (Rp2.000–Rp5.000.000):',[[{text:'❌ Batal',callback_data:'ppob:menu'}]]);}
  if(data==='ppob:cancel'){states.delete(chatId);return edit(bot,chatId,msgId,'❌ <b>Proses dibatalkan.</b>',back());}
  if(data==='ppob:resume'){const st=states.get(chatId);if(!st)return true;return confirmBuy(bot,chatId,msgId,st);}
  if(data==='ppob:confirm'){const st=states.get(chatId);if(!st)return true;return order(bot,chatId,msgId,st);}
  if(data.startsWith('ppob:cat:')) return category(bot,chatId,msgId,data.split(':')[2],0);
  if(data.startsWith('ppob:page:')){const [, ,cat,p]=data.split(':');return category(bot,chatId,msgId,cat,Number(p));}
  if(data.startsWith('ppob:buy:')) return buyPrompt(bot,chatId,msgId,data.slice(9));
  if(data.startsWith('ppob:pay:')){const [, ,amount,code]=data.split(':');const st=states.get(chatId);if(st){return createRama(bot,chatId,msgId,Number(amount),st);}return createRama(bot,chatId,msgId,Number(amount));}
  if(data.startsWith('ppob:status:')){await checkDeposit(bot,data.slice(12));return true;}
  if(data.startsWith('ppob:cancelpay:')){const id=data.slice(15),info=pendingPayments.get(id);if(info){pendingPayments.delete(id);try{await bot.deleteMessage(chatId,info.msgId)}catch{}}return bot.sendMessage(chatId,'❌ <b>Pembayaran dibatalkan.</b>',{parse_mode:'HTML',reply_markup:{inline_keyboard:back()}}).then(()=>true);}
  return true;
}
function init(bot){globalBot=bot;}
module.exports={init,menu,handleMessage,handleCallback,beginDeposit};
