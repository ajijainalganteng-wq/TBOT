// services/paymentChecker.js — RamaShop QRIS checker for VPN payments
'use strict';
const axios=require('axios');
const fs=require('fs');
const path=require('path');
const db=require('../data/db');
const {calculateBonus}=require('./promo');
const {doCreateAccountAfterPayment,doRenewAccountAfterPayment}=require('./ssh-exec');

function env(key,fallback=''){
  if(process.env[key])return process.env[key];
  try{const p=path.join(__dirname,'../.env');if(fs.existsSync(p))for(const line of fs.readFileSync(p,'utf8').split(/\r?\n/)){const s=line.trim();if(!s||s.startsWith('#'))continue;const i=s.indexOf('=');if(i>0&&s.slice(0,i).trim()===key)return s.slice(i+1).trim().replace(/^['"]|['"]$/g,'');}}catch{}
  return fallback;
}
const KEY=()=>env('RAMASHOP_API_KEY'), OWNER_ID=Number(env('OWNER_TELEGRAM_ID',env('OWNER_ID','0')))||0;
const INTERVAL=8000,TTL=5*60*1000;
const pendingOrders=new Map();
function addPendingOrder(id,info){pendingOrders.set(String(id),{...info,createdAt:Date.now(),status:'pending'});}
function removePendingOrder(id){pendingOrders.delete(String(id));}
function notifyAdmin(bot,id,info,type){
  if(!OWNER_ID)return;
  const labels={topup:'💰 TOP UP SALDO',create:'📦 BELI AKUN',renew:'🔄 PERPANJANG AKUN'};
  bot.sendMessage(OWNER_ID,`🔔 <b>PEMBAYARAN BERHASIL</b>\n\n📌 Tipe: <b>${labels[type]||type}</b>\n🆔 User: <code>${info.chatId}</code>\n🧾 Order: <code>${id}</code>\n💵 Nominal: <b>Rp ${Number(info.amount).toLocaleString('id-ID')}</b>`,{parse_mode:'HTML'}).catch(()=>{});
}
async function fetchPaymentStatus(id){
  if(!KEY())return {status:'error'};
  try{const r=await axios.get(`https://ramashop.my.id/api/public/deposit/status/${encodeURIComponent(id)}`,{headers:{'X-API-Key':KEY()},timeout:8000});return r.data||{};}catch{return {status:'error'};}
}
function normalized(s){
  const raw=JSON.stringify(s||{}).toLowerCase();
  if(/completed|success|paid|settled|berhasil|lunas/.test(raw))return 'completed';
  if(/expired/.test(raw))return 'expired';
  if(/cancelled|canceled|batal/.test(raw))return 'canceled';
  return 'pending';
}
async function processCompletedPayment(bot,id,info){
  removePendingOrder(id);
  try{require('./qris').clearQrisCountdown(id);}catch{}
  try{if(info.qrMsgId)await bot.deleteMessage(info.chatId,info.qrMsgId);}catch{}
  if(info.accountCreate){db.run("UPDATE transactions SET status='completed' WHERE order_id=?",[id]);notifyAdmin(bot,id,info,'create');return doCreateAccountAfterPayment(bot,info.chatId,info.accountCreate);}
  if(info.accountRenew){db.run("UPDATE transactions SET status='completed' WHERE order_id=?",[id]);notifyAdmin(bot,id,info,'renew');return doRenewAccountAfterPayment(bot,info.chatId,info.accountRenew);}
  const finalAmount=calculateBonus(info.amount);
  db.run("INSERT OR IGNORE INTO users(chat_id,saldo,role,created_at) VALUES(?,0,'members',datetime('now','localtime'))",[info.chatId],()=>{
    db.run("UPDATE users SET saldo=saldo+? WHERE chat_id=?",[finalAmount,info.chatId],()=>{
      db.get("SELECT saldo FROM users WHERE chat_id=?",[info.chatId],(e,row)=>{
        bot.sendMessage(info.chatId,`✅ <b>TOP UP BERHASIL</b>\n\n💰 Nominal: <b>Rp ${Number(info.amount).toLocaleString('id-ID')}</b>\n🎁 Bonus: <b>Rp ${Number(finalAmount-info.amount).toLocaleString('id-ID')}</b>\n💳 Saldo baru: <b>Rp ${Number(row?.saldo||0).toLocaleString('id-ID')}</b>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[ {text:'🔃 Kembali ke Menu',callback_data:'menu_back'} ]]}}).catch(()=>{});
      });
    });
  });
  db.run("UPDATE transactions SET status='completed' WHERE order_id=?",[id]);
  notifyAdmin(bot,id,info,'topup');
}
async function handleRefresh(bot,chatId,id){
  const info=pendingOrders.get(String(id));if(!info)return bot.sendMessage(chatId,'❌ Order tidak ditemukan atau sudah selesai.');
  const st=normalized(await fetchPaymentStatus(id));
  if(st==='completed')return processCompletedPayment(bot,id,info);
  if(st==='expired'||st==='canceled'){removePendingOrder(id);try{require('./qris').clearQrisCountdown(id);}catch{};try{await bot.deleteMessage(info.chatId,info.qrMsgId);}catch{};db.run("UPDATE transactions SET status=? WHERE order_id=?",[st,id]);return bot.sendMessage(chatId,'❌ <b>Pembayaran kadaluarsa/dibatalkan.</b>',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[ {text:'🔃 Kembali ke Menu',callback_data:'menu_back'} ]]}});}
  return bot.sendMessage(chatId,'⏳ <b>Pembayaran belum terdeteksi.</b>\n\nSilakan selesaikan pembayaran lalu cek kembali.',{parse_mode:'HTML'});
}
function startPaymentChecker(bot){
  if(!KEY()){console.warn('[paymentChecker] RAMASHOP_API_KEY belum diatur.');return;}
  console.log('[paymentChecker] RamaShop checker aktif');
  setInterval(async()=>{
    for(const [id,info] of pendingOrders.entries()){
      if(Date.now()-info.createdAt>TTL){removePendingOrder(id);try{require('./qris').clearQrisCountdown(id);}catch{};try{await bot.deleteMessage(info.chatId,info.qrMsgId);}catch{};db.run("UPDATE transactions SET status='expired' WHERE order_id=?",[id]);bot.sendMessage(info.chatId,'❌ <b>QRIS kadaluarsa.</b>\n\nSilakan buat pembayaran baru.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[ {text:'🔃 Kembali ke Menu',callback_data:'menu_back'} ]]}}).catch(()=>{});continue;}
      const st=normalized(await fetchPaymentStatus(id));if(st==='completed')await processCompletedPayment(bot,id,info);else if(st==='expired'||st==='canceled'){removePendingOrder(id);try{require('./qris').clearQrisCountdown(id);}catch{};try{await bot.deleteMessage(info.chatId,info.qrMsgId);}catch{};db.run("UPDATE transactions SET status=? WHERE order_id=?",[st,id]);}
    }
  },INTERVAL);
}
module.exports={addPendingOrder,removePendingOrder,handleRefresh,startPaymentChecker};
