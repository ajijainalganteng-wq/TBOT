// services/qris.js — RamaShop QRIS payment for VPN account creation/renewal
'use strict';
const axios = require('axios');
const QRCode = require('qrcode');
const fs = require('fs');
const path = require('path');
const db = require('../data/db');

function env(key, fallback='') {
  if (process.env[key]) return process.env[key];
  try {
    const p=path.join(__dirname,'../.env');
    if(fs.existsSync(p)) for(const line of fs.readFileSync(p,'utf8').split(/\r?\n/)){
      const s=line.trim(); if(!s||s.startsWith('#')) continue; const i=s.indexOf('=');
      if(i>0&&s.slice(0,i).trim()===key) return s.slice(i+1).trim().replace(/^['"]|['"]$/g,'');
    }
  } catch {}
  return fallback;
}
const TTL=5*60*1000, UPDATE=10000;
const intervals=new Map();
function clearCountdown(id){const x=intervals.get(String(id));if(x)clearInterval(x);intervals.delete(String(id));}
module.exports.clearQrisCountdown=clearCountdown;

async function generateQRIS(bot,chatId,amount,pendingInfo={}) {
  const key=env('RAMASHOP_API_KEY');
  if(!key) return bot.sendMessage(chatId,'❌ RAMASHOP_API_KEY belum diatur.');
  const localId=`VPN_${chatId}_${Date.now()}`;
  try{
    const r=await axios.post('https://ramashop.my.id/api/public/deposit/create',{amount:Number(amount),method:'qris'},{headers:{'X-API-Key':key},timeout:15000});
    if(!r.data?.success||!r.data?.data) throw new Error(r.data?.message||'Gagal membuat QRIS.');
    const d=r.data.data;
    const orderId=String(d.deposit_id||d.id||d.order_id||localId);
    const qr=d.qr_string||d.qris||d.qr_code||d.payment_number||d.qr;
    if(!qr) throw new Error('Provider pembayaran tidak mengembalikan QRIS.');
    const buf=await QRCode.toBuffer(qr,{width:380});
    const isCreate=!!pendingInfo.accountCreate, isRenew=!!pendingInfo.accountRenew;
    const label=isCreate?`💳 <b>PEMBAYARAN AKUN ${pendingInfo.productName||''}</b>`:isRenew?`💳 <b>PEMBAYARAN EXTEND ${pendingInfo.productName||''}</b>`:'💳 <b>TOP UP SALDO</b>';
    const msg=await bot.sendPhoto(chatId,buf,{caption:`${label}\n\n💰 Nominal: <b>Rp ${Number(amount).toLocaleString('id-ID')}</b>\n🧾 ID: <code>${orderId}</code>\n⏰ Berlaku: <b>05:00</b>\n\n⚡ Setelah pembayaran berhasil, proses dilanjutkan otomatis.`,parse_mode:'HTML',
      reply_markup:{inline_keyboard:[[ {text:'🔄 Cek Status',callback_data:`refresh_${orderId}`} ],[{text:'❌ Batalkan QRIS',callback_data:`cancel_qris_${orderId}`} ]] }});
    db.run("INSERT INTO transactions(chat_id,order_id,amount,status,created_at,product_type) VALUES(?,?,?,'pending',datetime('now','localtime'),?)",[chatId,orderId,amount,pendingInfo.productType||'']);
    const {addPendingOrder}=require('./paymentChecker');
    addPendingOrder(orderId,{chatId,amount,qrMsgId:msg.message_id,productName:pendingInfo.productName||'VPN',productType:pendingInfo.productType||'',accountCreate:pendingInfo.accountCreate||null,accountRenew:pendingInfo.accountRenew||null});
    const start=Date.now();
    const iv=setInterval(()=>{
      const rem=TTL-(Date.now()-start); if(rem<=0){clearCountdown(orderId);bot.editMessageCaption(`❌ <b>QRIS KADALUARSA</b>\n\nOrder <code>${orderId}</code> sudah melewati 5 menit.`,{chat_id:chatId,message_id:msg.message_id,parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔃 Kembali ke Menu',callback_data:'menu_back'}]]}}).catch(()=>{});return;}
      const sec=Math.floor(rem/1000),mm=String(Math.floor(sec/60)).padStart(2,'0'),ss=String(sec%60).padStart(2,'0');
      bot.editMessageCaption(`${label}\n\n💰 Nominal: <b>Rp ${Number(amount).toLocaleString('id-ID')}</b>\n🧾 ID: <code>${orderId}</code>\n⏰ Sisa waktu: <b>${mm}:${ss}</b>\n\n⚡ Proses otomatis setelah pembayaran berhasil.`,{chat_id:chatId,message_id:msg.message_id,parse_mode:'HTML',reply_markup:{inline_keyboard:[[ {text:'🔄 Cek Status',callback_data:`refresh_${orderId}`} ],[{text:'❌ Batalkan QRIS',callback_data:`cancel_qris_${orderId}`} ]]}}).catch(()=>{});
    },UPDATE);
    intervals.set(orderId,iv);
  }catch(e){console.error('[Rama QRIS]',e.message);bot.sendMessage(chatId,`❌ Gagal membuat QRIS: ${e.message}`);}
}
module.exports={generateQRIS};
